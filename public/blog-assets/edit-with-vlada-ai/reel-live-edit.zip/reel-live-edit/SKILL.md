---
name: reel-live-edit
description: Turn a talking-head take where the creator speaks editing commands ("put the ChatGPT logo on my right hand", "make them float and fly off", "put subtitles using these two fonts", "overlay a Tarantino clip when I say movie", "clear the background", "put a clone of me next to me") into a finished 16:9 edit where every command visibly happens on its word — live-editor UI with AI cursors, glass 3D logo cubes tracked to the palms, punch-ins, two-font captions, a movie card behind her hair, background wipe, a clone two-shot — plus the 9:16 "who edited it better" head-to-head stack of two AIs' edits. Use when someone wants the "ChatGPT vs Claude live edit" / "AI edits my video in real time" reel, voice-command edits, logos on hands, a clone of themselves, or two edits stacked for comparison.
---

# Live Edit — the voice-command "who edits better" reel

You (Claude) are the editor. The creator films one take speaking commands; you make each command happen **on the
word**, with nothing generated: every pixel comes from her footage, code-drawn graphics and synthesised sound.
The finished example and the 9:16 head-to-head are linked in README.md. The script she reads is in SCRIPT.md.

## What happens on screen (command → effect)

| she says | effect (edit.json beat) |
|---|---|
| "Who's better at video editing, ChatGPT or Claude?" | hook title from frame 0, slow push-in; name tags pop onto her palms on each name, VS badge on "or" (`hook`, `tags`) |
| "Let's make them edit this video in real time" | the take shrinks into a dark live-editor window: two AI panels, LIVE timecode on "real time", filmstrip + waveform timeline, two labelled cursors (`editor`) |
| "Put ChatGPT logo on my right hand" / "…Claude logo on my left hand" | the window expands; each cursor flies to the palm and clicks a glass 3D app-icon cube in, tracked to the hand (`logos.left/right`) |
| "Make them float and fly off to the sides" | cubes rise, sway, then fling off with motion blur (`logos.float/fly`) |
| "Let's make it harder" / "even harder" | snap punch-in + shake + difficulty meter (`difficulty`) |
| "Put subtitles using these two fonts" | captions start on that word: Anton caps + Instrument Serif italic (`captions`) |
| "Overlay a clip from any Tarantino movie when I say movie" | frameless 3D movie card slides out from behind her head, floats behind her hair, pulses on each "movie", whips out (`clip`) |
| "Clear everything on the background" | light-band wipe to a clean sky behind her (`clear`) |
| "…and put a clone of me next to me" | a duplicate of her own matte slides out of her into a two-shot (`clone`) |
| "So who won?" | the cubes fly back to flank the caption (`recall`) |
| "Want to edit videos like this too? Comment EDIT…" | back to her untouched footage, captions only — no clone, no gimmicks (`end`) |

Anything she doesn't say is skipped. Brands: chatgpt, claude, gemini, grok, perplexity, meta, mistral, deepseek,
copilot (stage/brands.js — add more by dropping a simple-icons SVG in stage/logos).

## Requirements (check before you start)

- **Claude Code** with shell access, on a Mac with Apple Silicon (best) or a PC/Linux box with an NVIDIA GPU. CPU-only works but matting is ~1 s/frame.
- `ffmpeg` on PATH, Google Chrome (or Playwright's Chromium), Python 3.12 available (`uv` makes setup fastest), ~6 GB free disk.
- A **landscape 16:9** take, 30 fps, ≤ 60 s. Optional: a movie clip file for the clip command (the creator is responsible for the rights).

**Sandboxed Claude Code:** render_gfx.py, render.py and stack.py start a local web server + headless Chrome — run those with the sandbox disabled.

Run once: `python3 engine/setup.py --install` (creates `~/.liveedit`, downloads RobustVideoMatting + MediaPipe models;
~3–6 min). Then `python3 engine/setup.py` must print **READY**. Every engine script re-launches itself in that venv.

## Workflow — do these in order, and LOOK at the output of each step

`E=<this skill>/engine`, `P=<project dir>` (anything, e.g. `~/live-edit/my-take`). Each script prints its next step.

1. **Project** — `python3 $E/new_project.py $P <take.mov> --brands chatgpt,claude [--clip movie.mp4 --clip-start 3:16.8]`
   `--brands` = viewer-LEFT hand first. Her right hand shows on the viewer's left (plan.py swaps them if her words say otherwise).
2. **Transcribe** — `python3 $E/transcribe.py $P` → words.json + cleaned voice. Read the printed transcript.
3. **Cuts** — `python3 $E/cuts.py $P` → the jump cuts already in the take + `out/cuts.jpg` (before | after frame of each). **View it.** A hand sweeping past the lens can fake a cut; delete those from edit.json.
4. **Plan** — `python3 $E/plan.py $P` → beats + caption chunks. **Read the table.** Each line shows the words around
   the beat. Whisper mishears brands ("chat gbt", "cloud") — aliases cover the usual ones; if a beat is missing or
   wrong, edit `edit.json` by hand (times in seconds). `beats.clip.src_start` comes from `--clip-start` (where in the
   movie file the moment starts — if the creator didn't say, look at the clip and pick its most iconic 2–3 s).
   Then **show the creator the plan** (one line per beat) before the long steps.
5. **Matte** — `python3 $E/matte.py $P` (~1 min per 30 s of take on Apple Silicon).
   `matte.cleanup` starts as `"auto"`: layout.py switches it to `"window"` when the background behind her is bright
   (a window / sky / city: removes sky and buildings caught in arm gaps and flyaway hair), else `"none"`.
6. **Track** — `python3 $E/track.py $P` → palm anchors. Warns if a palm wasn't raised long enough.
7. **Layout** — `python3 $E/layout.py $P` → where her head is per shot, two-shot sizes, which side the clip card goes, and a side for every caption chunk (the emptier side at that moment, never the clip card's side).
8. **Camera** — `python3 $E/camera.py $P` (must print `uncovered-edge frames: 0`).
9. **Quick look** — `python3 $E/render_gfx.py $P --at <8–12 frames at the beats>` then
   `python3 $E/composite.py $P --stills <same frames> /tmp/look.jpg --gfx-test` and **view the image**. Check: tags on the
   palms, cursor lands on the palm, cubes sit above (not inside) the palms, captions clear of her face/hands, clip card
   behind her hair, clone heads level. Fix in edit.json / layout and repeat this step — it costs seconds, the render costs minutes.
10. **Render** — `python3 $E/render.py $P --name <name>.mp4` (graphics → mix → composite → MP4; ~5 min for 35 s on an M-series Mac, longer on CPU). Run it in the background and wait.
11. **QA** — `python3 $E/qa.py $P --video $P/out/<name>.mp4` → out/qa.jpg, one tile per beat. **View it.** Report frame count, duration, loudness (−14 LUFS).
12. **Head-to-head (optional)** — when the creator also has another AI's edit of the same take:
    `python3 $E/stack.py --top claude.mp4 --bottom other.mp4 --top-label "CLAUDE" --bottom-label "CHATGPT" --top-brand claude --bottom-brand chatgpt --switch <beats.editor.in or first cut> --audio $P/<take> --out h2h.mp4`
    Title cuts from "EDITING" to "WHO'S better?" at `--switch` (end of her first sentence). Neutral audio (the original take) is the fair default.

## Defaults that matter (from the creator's real feedback)

- **No music.** Voice + synthesised SFX only. Add a bed only if asked (`render.py --music bed.wav`).
- **Edited from frame 0.** The hook title + push-in cover the opening; never leave the first seconds bare.
- **The ending is clean**: her real footage + captions only. No clone, no comment-box widgets.
- **Inserts land on the word that names them** ("Tarantino", not the second "movie"), frameless, big (~900 px), 3D motion.
- **Logos are glass app-icon cubes** with subtle hover/sway — not flat stickers.
- **No generated footage** (no AI video, no AI clone, no AI music) unless the creator asks — the clone is her own matte.

## When the creator asks for changes

Most notes map to one field — change it, re-run from the step that reads it (quick look first, then render):
- timing ("X happens too late") → that beat in edit.json (1 frame = 0.033 s); re-run camera.py if it's editor/difficulty.
- captions text/split → `captions[]` (A = caps words, B = italic accent words; `pos` side/top/end, or force `left`/`right`). Then `plan.py --keep` keeps your captions and beats.
- clip size/placement → clip.py `CW/CH` (card size) and `home`; which part of the movie → `beats.clip.src_start`.
- "remove X" → delete that beat. "different AIs" → `brands` (+ re-run render_gfx).
- two-shot spacing → composite.py `CLONE_X/HER_X/TW`; wrong person placement → layout.py output (`two_shot`).
After re-running plan.py, always re-run layout.py (it assigns each caption chunk its side). Never re-render the whole thing to test a change — use step 9.

## Troubleshooting

See REFERENCE.md §Troubleshooting (black edges, cubes on the wrong hand, matte holes, Chrome GPU, whisper backends).
Never invent timings: every beat must come from words.json or the creator.
