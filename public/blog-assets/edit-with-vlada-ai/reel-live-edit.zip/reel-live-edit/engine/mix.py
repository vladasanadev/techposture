"""Sound: her cleaned voice + code-synthesised SFX on every beat (no music) → audio/mix.wav, −14 LUFS, true peak −1.5.

usage:  python3 mix.py <project_dir> [--music path.wav --music-db -12]
Every cue is derived from edit.json beats, panned toward where the thing happens on screen.
--music adds a bed under the voice (ducked while she talks) — leave it out for the clean, voice-first version.
"""
import json, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, P, beat, FF
ensure_venv()
import numpy as np
import sfx as SFXK

proj = project_dir(); cfg = load(proj)
SR, DUR = 48000, cfg['duration']
N = int(DUR * SR) + 1
db = lambda d: 10 ** (d / 20)


def load_wav(path, ch=2):
    raw = subprocess.run([FF, '-v', 'error', '-i', path, '-ac', str(ch), '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True).stdout
    return np.frombuffer(raw, np.float32).reshape(-1, ch).astype(np.float64)


sdir = SFXK.render(P(proj, 'work', 'sfx'))
cache = {}
def S(n):
    if n not in cache: cache[n] = load_wav(os.path.join(sdir, n + '.wav'))
    return cache[n]
bus = np.zeros((N, 2))
def place(name, t, g=0.0, pan=0.0):
    if t is None: return
    x = S(name); i0 = int(round(t * SR))
    l = np.cos((pan + 1) * np.pi / 4) * np.sqrt(2); r = np.sin((pan + 1) * np.pi / 4) * np.sqrt(2)
    x = x * db(g) * np.array([min(1, l), min(1, r)])
    j0 = max(0, i0); s0 = j0 - i0; n = min(len(x) - s0, N - j0)
    if n > 0: bus[j0:j0 + n] += x[s0:s0 + n]

b = lambda *k: beat(cfg, *k)
place('swish-soft', 0.0, -16, -0.3)
if b('tags'):
    place('pop', b('tags', 'left') and b('tags', 'left') - 0.02, -8, -0.45); place('pop', b('tags', 'right') and b('tags', 'right') - 0.02, -8, 0.45)
    if b('tags', 'vs') is not None: place('impact', b('tags', 'vs'), -14, 0); place('pop', b('tags', 'vs') + 0.02, -10, 0)
if b('editor'):
    e0, lv, e1 = b('editor', 'in'), b('editor', 'live'), b('editor', 'out')
    place('whoosh', e0 - 0.07, -10, 0); place('click-soft', e0 + 0.18, -4, -0.6); place('click-soft', e0 + 0.25, -4, 0.6)
    place('tick', e0 + 0.68, -10, -0.6); place('tick', e0 + 0.78, -10, 0.6); place('ping', lv, -2, 0); place('whoosh-short', e1 - 0.03, -10, 0)
if b('logos'):
    for side, pan in (('left', -0.45), ('right', 0.45)):
        t = b('logos', side)
        if t is None: continue
        place('click', t - 0.02, -2, pan); place('pop', t, -6, pan); place('shimmer', t + 0.04, -15, pan)
        place('glass-tink', b('logos', side + '_settle'), -17, pan)
    place('pluck-up', b('logos', 'float') and b('logos', 'float') - 0.04, -14, 0)
    if b('logos', 'fly') is not None: place('whoosh-short', b('logos', 'fly') + 0.06, -8, -0.75); place('whoosh-short', b('logos', 'fly') + 0.18, -8, 0.75)
for k, d in enumerate(b('difficulty') or []):
    place('impact', d['t'], -9, 0); place('chip-select', d['t'] + 0.14, -14, -0.5)
    place('chip-powerup' if k else 'chip-select', d['t'] + 0.26, -16, -0.5)
if b('captions'): place('click-soft', b('captions', 'from'), -6, 0.3)
if b('clip'):
    side = -0.5 if cfg.get('layout', {}).get('clip_side', {}).get('side', 'left') == 'left' else 0.5
    place('whoosh', b('clip', 'in') - 0.07, -12, side * 0.4); place('swish-soft', b('clip', 'in') + 0.13, -18, side)
    place('impact', b('clip', 'in') + 0.23, -20, side * 0.6)
    for t in b('clip', 'pulses') or []: place('click-soft', t, -12, side)
    place('whoosh-short', b('clip', 'out') - 0.215, -10, side * 1.4)
if b('clear'): place('whoosh-long', b('clear', 't') - 0.08, -12, 0)
if b('clone'):
    t = b('clone', 't'); r = S('riser'); place('riser', t - len(r) / SR, -18, 0)
    place('impact', t, -7, 0); place('shimmer', t + 0.04, -14, -0.4)
if b('recall'):
    place('whoosh-short', b('recall', 'in') - 0.04, -14, -0.7); place('whoosh-short', b('recall', 'in') - 0.02, -14, 0.7)
    place('glass-tink', b('recall', 'in') + 0.40, -18, 0); place('swish-soft', b('recall', 'out'), -17, 0)

voice = load_wav(P(proj, 'audio', 'voice.wav'), 1)[:, 0]
voice = np.pad(voice, (0, max(0, N - len(voice))))[:N]
out = voice[:, None] * np.array([1.0, 1.0]) + bus
if '--music' in sys.argv:
    m = load_wav(sys.argv[sys.argv.index('--music') + 1])[:N]; m = np.pad(m, ((0, N - len(m)), (0, 0)))
    g = float(sys.argv[sys.argv.index('--music-db') + 1]) if '--music-db' in sys.argv else -12.0
    env = np.sqrt(np.convolve(voice ** 2, np.ones(2400) / 2400, 'same'))
    duck = 1 - 0.3 * np.convolve(np.clip((20 * np.log10(env + 1e-9) + 42) / 10, 0, 1), np.ones(9600) / 9600, 'same')
    out += m * db(g) * duck[:, None]
tmp = P(proj, 'audio', 'mix_pre.wav')
subprocess.run([FF, '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', '-', '-c:a', 'pcm_f32le', tmp],
               input=np.clip(out, -1, 1).astype(np.float32).tobytes(), check=True)
r = subprocess.run([FF, '-hide_banner', '-nostats', '-i', tmp, '-af', 'loudnorm=I=-14:TP=-1.5:LRA=9:print_format=json', '-f', 'null', '-'], capture_output=True, text=True)
j = json.loads(r.stderr[r.stderr.rindex('{'):r.stderr.rindex('}') + 1])
af = (f"loudnorm=I=-14:TP=-1.5:LRA=9:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:"
      f"measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true,aresample=48000")
subprocess.run([FF, '-v', 'error', '-y', '-i', tmp, '-af', af, '-c:a', 'pcm_s24le', P(proj, 'audio', 'mix.wav')], check=True)
print(f'mix.wav: {j["input_i"]} → −14 LUFS\nnext: python3 render.py {proj}')
