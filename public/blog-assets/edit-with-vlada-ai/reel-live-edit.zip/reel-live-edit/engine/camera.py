"""Per-frame virtual camera over the take, shared by the compositor and the graphics layer.

usage:  python3 camera.py <project_dir>
out = (p − c)·s + o  in 1920×1080 space (p = a point of the take). → work/stage/data/camera.json [[s, cx, cy, ox, oy] …]
  · hook: slow push on her face until the editor window opens
  · editor window: the take shrinks into the live-editor UI (s = 0.70), drifts, then expands back to full frame
  · difficulty: a snap punch-in (+13 %, +15 % for the second) on her face with a damped shake, easing back out
Whenever s ≥ 1 the take always covers the frame (no black edges).
"""
import json, math, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, P, beat, W, H, nframes
ensure_venv()

proj = project_dir(); cfg = load(proj); fps = cfg['fps']; NF = nframes(cfg)
clamp = lambda x, a=0.0, b=1.0: max(a, min(b, x))
lerp = lambda a, b, u: a + (b - a) * u
def io_cubic(x): x = clamp(x); return 4 * x ** 3 if x < .5 else 1 - (-2 * x + 2) ** 3 / 2
def out_quint(x): x = clamp(x); return 1 - (1 - x) ** 5
def out_expo(x): x = clamp(x); return 1 if x >= 1 else 1 - 2 ** (-10 * x)

FACES = cfg.get('layout', {}).get('face', [])
def face(t):
    for d in FACES:
        if d['t0'] <= t < d['t1']: return d['x'], d['face_y']
    return W / 2, 430

EIN, EOUT = beat(cfg, 'editor', 'in'), beat(cfg, 'editor', 'out')
EDIT = dict(s=0.70, o=(960, 452))
DIFF = beat(cfg, 'difficulty', default=[])
hook_end = EIN if EIN is not None else min([d['t'] for d in DIFF] + [3.5])
hx, hy = face(0.05)


def cam(t):
    s, cx, cy, ox, oy = 1.0, W / 2, H / 2, W / 2, H / 2
    if t < hook_end:                                            # hook: slow push on the face
        u = io_cubic(t / max(0.5, hook_end - 0.45))
        s = lerp(1.0, 1.085, u); cx, cy = hx, hy; ox, oy = hx, hy
    elif EIN is not None and t < EOUT:                          # into the editor window
        u = out_quint((t - EIN) / 0.55)
        s = lerp(1.085, EDIT['s'], u)
        cx, cy = lerp(hx, W / 2, u), lerp(hy, H / 2, u)
        ox, oy = lerp(hx, EDIT['o'][0], u), lerp(hy, EDIT['o'][1], u)
        s *= 1 + 0.012 * clamp((t - EIN - 0.55) / 2.0)
    elif EIN is not None and t < EOUT + 0.5:                    # back to full frame
        u = io_cubic((t - EOUT) / 0.5)
        s0 = EDIT['s'] * (1 + 0.012 * clamp((EOUT - EIN - 0.55) / 2.0))
        s = lerp(s0, 1.0, u); ox, oy = lerp(EDIT['o'][0], W / 2, u), lerp(EDIT['o'][1], H / 2, u)
    for k, d in enumerate(DIFF):                                # punch-ins
        if d['t'] <= t < d['out'] + 0.4:
            amp = 1.13 if k == 0 else 1.15
            u = out_expo((t - d['t']) / 0.16)
            back = io_cubic((t - (d['out'] - 0.45)) / 0.45)
            s = lerp(1.0, amp, u) * (1 - back) + 1.0 * back
            fx, fy = face(d['t'] + 0.05)
            cx, cy, ox, oy = fx, fy, fx, fy
    for k, d in enumerate(DIFF):                                # damped shake on each punch
        if d['t'] <= t < d['t'] + 0.45:
            q = t - d['t']; dd = math.exp(-q * 9.0); amp = 16.0 if k == 0 else 20.0
            ox += amp * dd * math.sin(q * 2 * math.pi * 11.0)
            oy += amp * 0.7 * dd * math.sin(q * 2 * math.pi * 13.0 + 1.3)
    if s >= 1:                                                  # keep the take covering the frame
        ox = min(cx * s, max(W - (W - cx) * s, ox))
        oy = min(cy * s, max(H - (H - cy) * s, oy))
    return [round(s, 5), round(cx, 2), round(cy, 2), round(ox, 2), round(oy, 2)]


data = [cam(f / fps) for f in range(NF + 1)]
json.dump(data, open(P(proj, 'work', 'stage', 'data', 'camera.json'), 'w'))
bad = 0
for s, cx, cy, ox, oy in data:
    if s >= 1:
        x0 = cx - ox / s; x1 = cx + (W - ox) / s; y0 = cy - oy / s; y1 = cy + (H - oy) / s
        bad += x0 < -0.5 or y0 < -0.5 or x1 > W + 0.5 or y1 > H + 0.5
print(f'camera.json: {len(data)} frames, uncovered-edge frames: {bad}\nnext: python3 render_gfx.py {proj}')
