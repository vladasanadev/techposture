"""Create a live-edit project from a landscape (16:9) take.

usage:  python3 new_project.py <project_dir> <take.mov|mp4> [--brands chatgpt,claude] [--clip movie.mp4 --clip-start 3:16.8]
Copies (hard-links when possible) the take to <project>/take.<ext>, probes it and writes a fresh edit.json skeleton.
--brands  the two AIs as they will appear on her hands: first = viewer-LEFT hand, second = viewer-RIGHT hand.
          Known brands: chatgpt, claude, gemini, grok, perplexity, meta, mistral, deepseek, copilot.
--clip    optional movie clip for the "overlay a clip" command (you need the rights to use it).
--clip-start  where in that file the moment starts (seconds or m:ss) — the most iconic 2–3 s.
"""
import os, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, probe, save, cfg_path
ensure_venv()

def arg(name, default=None):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default

if len(sys.argv) < 3: raise SystemExit(__doc__)
proj, take = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
os.makedirs(proj, exist_ok=True)
dst = os.path.join(proj, 'take' + os.path.splitext(take)[1].lower())
if not os.path.exists(dst):
    try: os.link(take, dst)
    except OSError: shutil.copy2(take, dst)
info = probe(dst)
if info['h'] > info['w']:
    raise SystemExit(f'✗ the take is {info["w"]}×{info["h"]} (portrait). This edit is designed for a landscape 16:9 take — '
                     'film horizontally (the head-to-head stack later turns two landscape edits into a 9:16 reel).')
ar = info['w'] / info['h']
if abs(ar - 16 / 9) > 0.02: print(f'! aspect {ar:.3f} is not 16:9 — it will be scaled to 1920×1080 (expect slight stretch)')
if round(info['fps']) not in (24, 25, 30, 60): print(f'! frame rate {info["fps"]:.3f} — 30 fps is the tested rate')
brands = (arg('--brands') or 'chatgpt,claude').lower().split(',')
cfg = {
    'source': os.path.basename(dst), 'fps': round(info['fps'], 3), 'duration': round(info['duration'], 4),
    'src_size': [info['w'], info['h']], 'brands': {'left': brands[0], 'right': brands[1]},
    'cuts': [], 'beats': {}, 'captions': [], 'layout': {}, 'matte': {'cleanup': 'auto'},   # auto → layout.py decides
}
if arg('--clip'):
    c = os.path.abspath(arg('--clip')); cd = os.path.join(proj, 'clip' + os.path.splitext(c)[1].lower())
    if not os.path.exists(cd): shutil.copy2(c, cd)
    cfg['clip_file'] = os.path.basename(cd)
    cs = arg('--clip-start')
    if cs:
        parts = [float(x) for x in cs.split(':')]
        cfg['clip_start'] = round(sum(v * 60 ** i for i, v in enumerate(reversed(parts))), 3)
    else:
        print('! no --clip-start: the clip will start at 0:00 of that file (set beats.clip.src_start in edit.json later)')
if os.path.exists(cfg_path(proj)) and '--force' not in sys.argv:
    raise SystemExit(f'✗ {cfg_path(proj)} exists (use --force to start over)')
save(proj, cfg)
print(f'project {proj}\n  take {info["w"]}×{info["h"]} @ {info["fps"]:.3f} fps, {info["duration"]:.2f} s\n  brands left={brands[0]} right={brands[1]}')
print('next: python3 transcribe.py', proj)
