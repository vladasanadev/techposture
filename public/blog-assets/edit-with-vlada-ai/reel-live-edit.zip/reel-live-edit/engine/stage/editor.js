// Opening graphics: hook title, palm name tags + VS, the live-editor window (the camera pulls the take into it),
// two AI cursors that fly onto her palms and "click" the 3D logos in, and the difficulty meter.
// Every time comes from edit.json "beats"; anything she didn't say is skipped.
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, t) => a + (b - a) * t;
const prog = (t, t0, d) => clamp((t - t0) / d);
const E = {
  outCubic: t => 1 - Math.pow(1 - t, 3), inCubic: t => t * t * t, outQuint: t => 1 - Math.pow(1 - t, 5),
  inOut: t => (t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  outBack: (t, s = 1.70158) => 1 + (s + 1) * Math.pow(t - 1, 3) + s * Math.pow(t - 1, 2),
};
const $ = id => document.getElementById(id);
const NONE = 1e9;
let CAM, anchorAt, FPS = 30, BR;
export const T = {};

export function camAt(t) {
  const f = clamp(t * FPS, 0, CAM.length - 1), f0 = Math.floor(f), fr = f - f0;
  const a = CAM[f0], b = CAM[Math.min(CAM.length - 1, f0 + 1)];
  return a.map((v, i) => lerp(v, b[i], fr));
}
export function mapPt(t, x, y) { const c = camAt(t); return [(x - c[1]) * c[0] + c[3], (y - c[2]) * c[0] + c[4], c[0]]; }

// ---------------------------------------------------------------- build
export async function initEditor(cfg, camera, anchorFn, brands, paths) {
  CAM = camera; anchorAt = anchorFn; FPS = cfg.fps; BR = brands;
  const b = cfg.beats || {}, n = (v, d = NONE) => (v === undefined || v === null ? d : v);
  Object.assign(T, {
    hook: b.hook ? b.hook.text : null, hookOut: n(b.hook && b.hook.out, -1),
    tagG: n(b.tags && b.tags.left), vs: n(b.tags && b.tags.vs), tagC: n(b.tags && b.tags.right),
    cut: n(b.editor && b.editor.in), live: n(b.editor && b.editor.live), expand: n(b.editor && b.editor.out),
    gClick: n(b.logos && b.logos.left), cClick: n(b.logos && b.logos.right),
    diff: (b.difficulty || []).slice(0, 2), dur: cfg.duration, editor: !!b.editor,
  });
  // the first two tags dock into the editor's avatar stack; without an editor they leave when the next beat starts
  T.tagsOut = T.editor ? T.cut : Math.min(n(b.logos && b.logos.left, T.tagC + 2.0), T.tagC + 2.0);
  if (T.hook) { $('hook1').textContent = T.hook[0] || ''; $('hook2').innerHTML = (T.hook[1] || '').replace(/\?$/, '<span class="q">?</span>'); }
  $('fname').textContent = (b.editor && b.editor.filename) || 'my_take_01.mov';
  // brand slots
  const svg = (d, fill) => `<svg viewBox="0 0 24 24"><path fill="${fill}" d="${d}"/></svg>`;
  for (const el of document.querySelectorAll('[data-side]')) {
    const side = el.dataset.side, br = BR[side], d = paths[side];
    if (el.classList.contains('av')) { el.style.background = br.ui; el.innerHTML = svg(d, '#fff'); }
    else if (el.classList.contains('ic')) { el.style.background = br.ui; el.style.border = '1px solid #333'; el.innerHTML = svg(d, '#fff'); }
    else if (el.classList.contains('nm')) el.textContent = br.label;
    else if (el.tagName === 'B') el.style.background = br.bar;
    else if (el.classList.contains('tag')) { el.style.background = br.ui; el.style.borderColor = br.ui; el.innerHTML = svg(d, '#fff') + br.label; }
    else if (el.classList.contains('cur')) {
      el.querySelector('.nm').textContent = br.label; el.querySelector('.nm').style.background = br.ui;
      el.querySelector('path').setAttribute('stroke', br.ui);
    }
  }
  const film = $('film');
  for (let i = 0; i < 16; i++) { const im = document.createElement('img'); im.src = `editor/th_${String(i).padStart(2, '0')}.jpg`; film.appendChild(im); }
  await Promise.all([...film.querySelectorAll('img')].map(im => im.complete ? 1 : new Promise(r => { im.onload = r; im.onerror = r; })));
  const wave = await (await fetch('data/wave.json')).json();
  const wc = $('wave'), g = wc.getContext('2d');
  g.fillStyle = '#16202a'; g.fillRect(0, 0, wc.width, wc.height);
  const bw = wc.width / wave.length;
  g.fillStyle = '#4fb3a5';
  wave.forEach((v, i) => { const h = Math.max(1.5, v * 38); g.fillRect(i * bw, 22 - h / 2, Math.max(1, bw - 0.6), h); });
  const ru = $('ruler');
  for (let s = 0; s <= T.dur; s += 5) { const sp = document.createElement('span'); sp.textContent = `0:${String(s).padStart(2, '0')}`; sp.style.left = (s / T.dur * 100) + '%'; ru.appendChild(sp); }
}

function tcode(t) {
  const f = Math.floor(t * FPS + 1e-6), s = Math.floor(f / FPS), fr = f % Math.round(FPS);
  return `00:00:${String(s).padStart(2, '0')}:${String(fr).padStart(2, '0')}`;
}
function winRect(c) { const [s, cx, cy, ox, oy] = c; return [(0 - cx) * s + ox, (0 - cy) * s + oy, (1920 - cx) * s + ox, (1080 - cy) * s + oy]; }
function rrect(g, x0, y0, x1, y1, r) {
  g.beginPath(); g.moveTo(x0 + r, y0); g.lineTo(x1 - r, y0); g.quadraticCurveTo(x1, y0, x1, y0 + r); g.lineTo(x1, y1 - r);
  g.quadraticCurveTo(x1, y1, x1 - r, y1); g.lineTo(x0 + r, y1); g.quadraticCurveTo(x0, y1, x0, y1 - r); g.lineTo(x0, y0 + r); g.quadraticCurveTo(x0, y0, x0 + r, y0); g.closePath();
}
function path(t, keys) {
  if (t <= keys[0][0]) return [keys[0][1], keys[0][2]];
  for (let i = 0; i < keys.length - 1; i++) {
    const [t0, x0, y0] = keys[i], [t1, x1, y1] = keys[i + 1];
    if (t <= t1) {
      const u = E.inOut((t - t0) / Math.max(1e-3, t1 - t0));
      const arc = Math.sin(Math.PI * u) * Math.min(80, Math.hypot(x1 - x0, y1 - y0) * 0.12);
      return [lerp(x0, x1, u) + arc * 0.3, lerp(y0, y1, u) - arc];
    }
  }
  const k = keys[keys.length - 1]; return [k[1], k[2]];
}
// where a logo cube will sit above the palm, in output px (mirrors cubeSize / cubeLift in main.js)
function palmSpot(hand, t) {
  const a = anchorAt(hand, t);
  if (!a) return [hand === 'L' ? 480 : 1440, 640];
  const S = clamp(a.size * 0.98, 150, 192), lift = 0.2 * a.size + 0.58 * S;
  const [X, Y] = mapPt(t, a.x + a.nx * lift, a.y + a.ny * lift);
  return [X, Y];
}
const ripEls = [];
function ripple(i, x, y, p, color) {
  if (!ripEls[i]) { const d = document.createElement('div'); d.className = 'rip'; $('rips').appendChild(d); ripEls[i] = d; }
  const d = ripEls[i];
  if (p <= 0 || p >= 1) { d.style.opacity = 0; return; }
  const r = 18 + 70 * E.outCubic(p);
  d.style.left = (x - r) + 'px'; d.style.top = (y - r) + 'px'; d.style.width = d.style.height = 2 * r + 'px';
  d.style.opacity = 0.9 * (1 - p); d.style.borderColor = color;
}

// ---------------------------------------------------------------- per-frame
export function renderEditor(t) {
  const c = camAt(t);
  const hook = $('hook');
  if (!T.hook || t > T.hookOut + 0.25) hook.style.display = 'none'; else {
    const ho = prog(t, T.hookOut, 0.22);
    hook.style.display = 'block'; hook.style.opacity = 1 - ho;
    hook.style.transform = `translateY(${-30 * E.inCubic(ho)}px) scale(${1.03 - 0.03 * E.outCubic(prog(t, 0, 0.6))})`;
    hook.style.filter = ho > 0 ? `blur(${ho * 10}px)` : 'none';
  }
  // name tags on her palms, then into the editor's avatar stack
  const tags = [['tagG', 'L', T.tagG, [1780, 52]], ['tagC', 'R', T.tagC, [1806, 52]]];
  for (const [id, hand, t0, dock] of tags) {
    const el = $(id);
    if (t0 >= NONE || t < t0 - 0.01 || t > T.tagsOut + 0.62) { el.style.opacity = 0; continue; }
    const tAnchor = Math.min(t, T.tagsOut - 0.04);
    const a = anchorAt(hand, tAnchor);
    if (!a) { el.style.opacity = 0; continue; }
    let [x, y, s] = mapPt(tAnchor, a.x, a.y - 0.55 * a.size);
    const pe = prog(t, t0, 0.42);
    let sc = (pe > 0 ? E.outBack(pe, 2.4) : 0) * Math.max(0.9, s);
    let rot = (1 - E.outCubic(pe)) * (hand === 'L' ? -14 : 14);
    let op = clamp(pe * 4);
    const pd = prog(t, T.tagsOut, 0.55);
    if (pd > 0) {
      if (T.editor) { const u = E.outQuint(pd); x = lerp(x, dock[0], u); y = lerp(y, dock[1], u); sc = lerp(sc, 0.22, u); rot = 0; op = 1 - prog(t, T.tagsOut + 0.3, 0.22); }
      else { sc *= 1 - 0.3 * E.inCubic(pd); op = 1 - prog(t, T.tagsOut, 0.25); }
    }
    const w = el.offsetWidth, h = el.offsetHeight;
    el.style.left = (x - w / 2) + 'px'; el.style.top = (y - h) + 'px';
    el.style.transform = `rotate(${rot}deg) scale(${sc})`; el.style.opacity = op;
  }
  const vs = $('vs');
  if (T.vs >= NONE || t < T.vs - 0.01 || t > T.tagsOut + 0.2) vs.style.opacity = 0; else {
    const p = prog(t, T.vs, 0.32), q = prog(t, T.tagsOut - 0.12, 0.16);
    vs.style.left = (960 - 56) + 'px'; vs.style.top = (912 - 56) + 'px';
    vs.style.opacity = clamp(p * 5) * (1 - q);
    vs.style.transform = `scale(${(p > 0 ? E.outBack(p, 3) : 0) * (1 - 0.6 * q)}) rotate(${(1 - E.outCubic(p)) * -30}deg)`;
  }

  // editor window: opaque UI wherever the take isn't
  const bg = $('edbg'), g = bg.getContext('2d');
  g.clearRect(0, 0, 1920, 1080);
  const inEd = T.editor && t >= T.cut && c[0] < 0.999;
  $('ed').style.display = inEd ? 'block' : 'none';
  if (inEd) {
    const [x0, y0, x1, y1] = winRect(c);
    g.fillStyle = '#0B0D11'; g.fillRect(0, 0, 1920, 1080);
    g.fillStyle = 'rgba(255,255,255,0.035)';
    for (let yy = 12; yy < 1080; yy += 28) for (let xx = 12; xx < 1920; xx += 28) g.fillRect(xx, yy, 2, 2);
    const r = 16 * clamp((1.085 - c[0]) / 0.3);
    g.save(); g.globalCompositeOperation = 'destination-out'; g.fillStyle = '#000'; rrect(g, x0, y0, x1, y1, r); g.fill(); g.restore();
    const win = $('win');
    win.style.left = x0 + 'px'; win.style.top = y0 + 'px'; win.style.width = (x1 - x0) + 'px'; win.style.height = (y1 - y0) + 'px';
    win.style.borderRadius = r + 'px';
    const D = T.expand - T.cut;
    const pin = E.outCubic(prog(t, T.cut + 0.12, 0.45)), pout = E.inCubic(prog(t, T.expand - 0.02, 0.32));
    const v = pin * (1 - pout);
    $('pl').style.transform = `translateX(${(1 - v) * -300}px)`; $('pr').style.transform = `translateX(${(1 - v) * 300}px)`;
    $('tlw').style.transform = `translateY(${(1 - v) * 260}px)`;
    $('ed').querySelector('.bar').style.transform = `translateY(${(1 - v) * -80}px)`;
    for (const id of ['pl', 'pr', 'tlw']) $(id).style.opacity = clamp(v * 1.5);
    $('ed').querySelector('.bar').style.opacity = clamp(v * 1.5);
    const live = t >= T.live;
    $('livep').classList.toggle('on', live);
    $('livep').querySelector('i').style.opacity = live ? (0.55 + 0.45 * Math.cos(t * 6)) : 1;
    $('tc').textContent = tcode(t);
    $('tc').style.color = live ? '#ffffff' : '#7d8693';
    for (const [id, tt] of [['stl', T.cut + 0.30 * D], ['str', T.cut + 0.34 * D]]) {
      const el = $(id); el.classList.toggle('on', live);
      el.querySelector('span').textContent = live ? 'editing live' : (t >= tt ? 'listening…' : 'waiting…');
    }
    const rowsL = $('pl').querySelectorAll('.rows b'), rowsR = $('pr').querySelectorAll('.rows b');
    rowsL.forEach((b, i) => b.style.width = (100 * E.outCubic(prog(t, T.cut + (0.41 + i * 0.11) * D, 0.9)) * (0.55 + 0.15 * i)) + '%');
    rowsR.forEach((b, i) => b.style.width = (100 * E.outCubic(prog(t, T.cut + (0.45 + i * 0.12) * D, 0.9)) * (0.7 - 0.12 * i)) + '%');
    $('head').style.left = (110 + (1872 - 110 - 16) * (t / T.dur)) + 'px';
  }

  // cursors: wander the editor (or fly in from the edges), then each one clicks its cube onto a palm
  const D = T.editor ? T.expand - T.cut : 0;
  const gStart = T.editor ? [[T.cut + 0.27 * D, 150, 470], [T.cut + 0.59 * D, 690, 972], [T.cut + 0.83 * D, 880, 972], [T.expand + 0.05, 880, 940]]
    : [[T.gClick - 1.1, -120, 760]];
  const cStart = T.editor ? [[T.cut + 0.31 * D, 1770, 470], [T.cut + 0.63 * D, 1330, 430], [T.cut + 0.85 * D, 1230, 520], [T.expand + 0.05, 1260, 520]]
    : [[T.cClick - 1.1, 2050, 760]];
  const gSpot = palmSpot('L', T.gClick), cSpot = palmSpot('R', T.cClick);
  const gKeys = [...gStart, [T.gClick - 0.12, gSpot[0] - 6, gSpot[1] - 8], [T.gClick + 0.06, gSpot[0] - 6, gSpot[1] - 8], [T.gClick + 0.72, gSpot[0] - 260, gSpot[1] - 260]];
  const park = T.editor ? T.expand + 0.58 : T.cClick - 1.1;
  const cKeys1 = [...cStart, [park, 2050, 640]];
  const cKeys2 = [[T.cClick - 0.83, 2050, 760], [T.cClick - 0.12, cSpot[0] - 6, cSpot[1] - 8], [T.cClick + 0.06, cSpot[0] - 6, cSpot[1] - 8], [T.cClick + 0.72, cSpot[0] + 280, cSpot[1] - 260]];
  const curs = [['curG', T.gClick, gStart[0][0], T.gClick + 0.72, '#ffffff'], ['curC', T.cClick, cStart[0][0], T.cClick + 0.72, '#ffd2bf']];
  for (const [id, tClick, tIn, tOut, rc] of curs) {
    const el = $(id);
    let keys = id === 'curG' ? gKeys : (t < (park + T.cClick - 0.83) / 2 ? cKeys1 : cKeys2);
    let vis = tClick < NONE && t >= tIn && t <= tOut;
    let fin = tIn;
    if (id === 'curC' && T.editor) { if (t > park && t < T.cClick - 0.83) vis = false; if (t >= T.cClick - 0.83) fin = T.cClick - 0.83; }
    if (!vis) { el.style.opacity = 0; ripple(id === 'curG' ? 0 : 1, 0, 0, 0, rc); continue; }
    const [x, y] = path(t, keys);
    const fadeIn = prog(t, fin, 0.18), fadeOut = 1 - prog(t, tOut - 0.35, 0.35);
    const press = Math.sin(Math.PI * prog(t, tClick - 0.04, 0.16));
    el.style.left = x + 'px'; el.style.top = y + 'px';
    el.style.transform = `scale(${1 - 0.14 * press})`; el.style.opacity = clamp(fadeIn) * fadeOut;
    ripple(id === 'curG' ? 0 : 1, x + 4, y + 4, prog(t, tClick, 0.45), rc);
  }

  // difficulty meter
  const m = $('meter');
  const cur = T.diff.filter(d => t >= d.t - 0.02 && t <= d.out + 0.25).pop();
  if (!cur) m.style.opacity = 0; else {
    const lv = cur.level || 2, t0 = cur.t, t1 = cur.out;
    const pi = prog(t, t0, 0.3), po = prog(t, t1, 0.22);
    m.style.opacity = clamp(pi * 4) * (1 - po);
    m.style.transform = `translateX(${(1 - E.outBack(pi, 1.6)) * -60 - 40 * E.inCubic(po)}px) scale(${0.92 + 0.08 * E.outCubic(pi)})`;
    $('mlv').textContent = cur.label || (lv === 3 ? 'EVEN HARDER' : 'HARDER');
    const col = lv >= 3 ? '#ff6b4a' : '#ffc95c';
    $('mlv').style.color = col;
    m.querySelectorAll('.bars i').forEach((b, i) => {
      const filledBefore = lv - 1;
      const fillT = i < filledBefore ? -1 : t0 + 0.12 + (i - filledBefore) * 0.12;
      const on = i < lv && (fillT < 0 || t >= fillT);
      const pop = fillT > 0 ? Math.sin(Math.PI * prog(t, fillT, 0.22)) : 0;
      b.style.background = on ? col : '#2b313d';
      b.style.transform = `scaleY(${1 + 0.35 * pop})`;
      b.style.boxShadow = on && lv >= 3 ? '0 0 14px rgba(255,107,74,.8)' : 'none';
    });
  }
}
