// The AIs that can go head to head. ui = name-tag / cursor colour, bar = editor-panel progress bars,
// cube / glow / rim = the glass app-icon cube (body colour, inner glow, edge highlight), logo = logo width on the cube face.
// Logos are simple-icons SVGs (CC0). Add a brand: drop <slug>.svg into logos/ and add a row here.
export const BRANDS = {
  chatgpt:    { label: 'ChatGPT',    ui: '#0d0d0e', bar: '#e8ecf2', cube: 0x07805a, glow: 0x1fd49a, rim: 0xd8fff2, svg: 'openai.svg',        logo: 12.6 },
  claude:     { label: 'Claude',     ui: '#D97757', bar: '#D97757', cube: 0xc24a17, glow: 0xff8a40, rim: 0xfff0e4, svg: 'claude.svg',        logo: 13.6 },
  gemini:     { label: 'Gemini',     ui: '#3b6fe0', bar: '#7aa2ff', cube: 0x2a50c4, glow: 0x7aa2ff, rim: 0xe6eeff, svg: 'googlegemini.svg',  logo: 13.6 },
  grok:       { label: 'Grok',       ui: '#111214', bar: '#e8ecf2', cube: 0x1b1c20, glow: 0x6a6f7a, rim: 0xffffff, svg: 'grok.svg',          logo: 11.5 },
  perplexity: { label: 'Perplexity', ui: '#1f8a8a', bar: '#3fd0cc', cube: 0x126b6d, glow: 0x3fd0cc, rim: 0xe0ffff, svg: 'perplexity.svg',    logo: 13.0 },
  meta:       { label: 'Meta AI',    ui: '#0866ff', bar: '#5c9dff', cube: 0x0a55d6, glow: 0x5c9dff, rim: 0xe6f0ff, svg: 'meta.svg',          logo: 14.0 },
  mistral:    { label: 'Le Chat',    ui: '#fa520f', bar: '#ffa060', cube: 0xd8460c, glow: 0xffa060, rim: 0xfff0e4, svg: 'mistralai.svg',     logo: 12.6 },
  deepseek:   { label: 'DeepSeek',   ui: '#4d6bfe', bar: '#8aa0ff', cube: 0x3550d8, glow: 0x8aa0ff, rim: 0xe6ecff, svg: 'deepseek.svg',      logo: 13.6 },
  copilot:    { label: 'Copilot',    ui: '#24292f', bar: '#e8ecf2', cube: 0x24292f, glow: 0x7a8696, rim: 0xffffff, svg: 'githubcopilot.svg', logo: 13.0 },
};
export async function brandSvgPath(b) {
  const t = await (await fetch('logos/' + b.svg)).text();
  return t.match(/ d="([^"]+)"/)[1];
}
