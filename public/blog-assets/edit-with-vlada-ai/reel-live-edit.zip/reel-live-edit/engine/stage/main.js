import * as THREE from 'three';
import { SVGLoader } from './vendor/SVGLoader.js';
import { RoomEnvironment } from './vendor/RoomEnvironment.js';
import { initEditor, renderEditor, mapPt } from './editor.js';
import { BRANDS, brandSvgPath } from './brands.js';

// filled from data/edit.json in init()
let CFG, FPS = 30, LOGO = { gpt: null, claude: null, recall: null }, CAPS = [], WIPE = null, END = { t0: 1e9 }, BR = {};
// internal names: 'gpt' = the cube on the viewer-LEFT hand, 'claude' = the viewer-RIGHT hand (any brands)

const W = 1920, H = 1080;
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, t) => a + (b - a) * t;
const prog = (t, t0, d) => clamp((t - t0) / d);
const E = {
  outCubic: t => 1 - Math.pow(1 - t, 3),
  outQuint: t => 1 - Math.pow(1 - t, 5),
  inCubic: t => t * t * t,
  inQuad: t => t * t,
  inOutCubic: t => (t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  inOutSine: t => -(Math.cos(Math.PI * t) - 1) / 2,
  outBack: (t, s = 1.70158) => 1 + (s + 1) * Math.pow(t - 1, 3) + s * Math.pow(t - 1, 2),
};
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };

// ---------------------------------------------------------------- three.js logos
const glc = document.createElement('canvas'); glc.width = W; glc.height = H;
const renderer = new THREE.WebGLRenderer({ canvas: glc, alpha: true, antialias: true, preserveDrawingBuffer: true, premultipliedAlpha: true });
renderer.setPixelRatio(1); renderer.setSize(W, H, false); renderer.setClearColor(0x000000, 0);
renderer.toneMapping = THREE.NeutralToneMapping; renderer.toneMappingExposure = 1.0;
renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene();
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.03).texture;
const FOV = 18, DIST = (H / 2) / Math.tan(THREE.MathUtils.degToRad(FOV / 2));
const camera = new THREE.PerspectiveCamera(FOV, W / H, 50, 20000); camera.position.set(0, 0, DIST); camera.lookAt(0, 0, 0);
const key = new THREE.DirectionalLight(0xfff0e0, 2.0); key.position.set(-700, 900, 1400); scene.add(key);
const rim = new THREE.DirectionalLight(0xd6e8ff, 3.2); rim.position.set(500, 700, -1300); scene.add(rim);
const fill = new THREE.DirectionalLight(0xbcd6ff, 0.7); fill.position.set(900, -300, 900); scene.add(fill);
scene.add(new THREE.AmbientLight(0xffffff, 0.2));
const top = new THREE.DirectionalLight(0xffffff, 1.1); top.position.set(-200, 1400, 600); scene.add(top);     // bright bevel highlights on top edges

// ---- glass app-icon cubes (like the reference): squircle body with rounded edges, inner glow, glassy rim, inlaid white logo
function squircle(size, n = 4.4, seg = 192) {
  const sh = new THREE.Shape(), r = size / 2;
  for (let i = 0; i <= seg; i++) {
    const th = (i / seg) * Math.PI * 2, c = Math.cos(th), s = Math.sin(th);
    const x = r * Math.sign(c) * Math.pow(Math.abs(c), 2 / n), y = r * Math.sign(s) * Math.pow(Math.abs(s), 2 / n);
    if (i === 0) sh.moveTo(x, y); else if (i < seg) sh.lineTo(x, y);
  }
  sh.closePath();
  return sh;
}
function weld(geo) {                       // non-indexed extrude → indexed, so normals come out smooth
  const pos = geo.attributes.position, map = new Map(), idx = [], out = [];
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const k = `${x.toFixed(3)},${y.toFixed(3)},${z.toFixed(3)}`;
    let j = map.get(k);
    if (j === undefined) { j = out.length / 3; out.push(x, y, z); map.set(k, j); }
    idx.push(j);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(out, 3)); g.setIndex(idx); g.computeVertexNormals();
  return g;
}
const RIM_VS = `varying vec3 vN; varying vec3 vV;
void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`;
const RIM_FS = `uniform vec3 uC; uniform float uK; uniform float uP; varying vec3 vN; varying vec3 vV;
void main(){ float f = pow(1.0 - clamp(abs(dot(normalize(vN), normalize(vV))), 0.0, 1.0), uP) * uK; gl_FragColor = vec4(uC * f, f); }`;
function glassMat(hex, glowHex) {
  const m = new THREE.MeshPhysicalMaterial({ color: hex, roughness: 0.14, metalness: 0, clearcoat: 1, clearcoatRoughness: 0.03,
    envMapIntensity: 1.15, emissive: glowHex, emissiveIntensity: 0.46, specularIntensity: 1, ior: 1.55,
    sheen: 0.12, sheenColor: new THREE.Color(0xffffff), sheenRoughness: 0.3 });
  m.onBeforeCompile = sh => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vOP;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvOP = position;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vOP;')
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
      { float rr = length(vOP.xy) / 12.0; float zz = abs(vOP.z) / 6.3;
        totalEmissiveRadiance *= mix(1.0, 0.05, smoothstep(0.15, 1.0, rr)) * (0.75 + 0.25 * zz); }`);
  };
  return m;
}
const whiteMat = new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.28, metalness: 0, clearcoat: 0.7, clearcoatRoughness: 0.08,
  emissive: 0xffffff, emissiveIntensity: 0.3, envMapIntensity: 0.8 });
async function logoGeo(url, size, depth) {
  const data = await new SVGLoader().loadAsync(url);
  const shapes = data.paths.flatMap(p => SVGLoader.createShapes(p));
  const geo = new THREE.ExtrudeGeometry(shapes, { depth, bevelEnabled: true, bevelThickness: 0.1, bevelSize: 0.06, bevelSegments: 3, curveSegments: 28 });
  geo.center(); geo.rotateX(Math.PI);
  geo.computeBoundingBox();
  const bb = geo.boundingBox, k = size / Math.max(bb.max.x - bb.min.x, bb.max.y - bb.min.y);
  geo.scale(k, k, 1);
  geo.computeVertexNormals();
  return geo;
}
const CUBE = { B: 3.0, D: 6.6 };
async function buildCube(url, bodyHex, glowHex, rimHex, logoSize) {
  const { B, D } = CUBE;
  const body = weld(new THREE.ExtrudeGeometry(squircle(24 - 2 * B), { depth: D, bevelEnabled: true, bevelThickness: B, bevelSize: B, bevelSegments: 14, curveSegments: 12 }).center());
  const zf = D / 2 + B;
  const g = new THREE.Group();
  g.add(new THREE.Mesh(body, glassMat(bodyHex, glowHex)));
  const rim = new THREE.Mesh(body, new THREE.ShaderMaterial({ vertexShader: RIM_VS, fragmentShader: RIM_FS, transparent: true, depthWrite: false,
    blending: THREE.AdditiveBlending, premultipliedAlpha: true,
    uniforms: { uC: { value: new THREE.Color(rimHex) }, uK: { value: 1.15 }, uP: { value: 3.4 } } }));
  rim.scale.setScalar(1.004); g.add(rim);
  const lg = await logoGeo(url, logoSize, 0.5);
  const front = new THREE.Mesh(lg, whiteMat); front.position.z = zf - 0.12; g.add(front);
  const back = new THREE.Mesh(lg, whiteMat); back.rotation.y = Math.PI; back.position.z = -(zf - 0.12); g.add(back);
  g.visible = false; scene.add(g);
  return g;
}

let anchors, gpt, cld;
const logos = {};

function anchorAt(hand, t) {
  const A = anchors[hand];
  if (!A) return null;
  const f = clamp(t * FPS, A.first, A.last);
  const f0 = Math.floor(f), fr = f - f0;
  const a = A.frames[f0], b = A.frames[Math.min(f0 + 1, A.last)];
  const v = a.map((x, i) => lerp(x, b[i], fr));
  return { x: v[0], y: v[1], size: v[2], nx: v[3], ny: v[4], top: v[5] };
}

// returns {x,y,S,rx,ry,rz,scale, fx:{...}} in screen px, or null
export const cubeSize = a => clamp(a.size * 0.98, 150, 192);
export const cubeLift = (a, S) => 0.2 * a.size + 0.58 * S;
function logoState(name, t) {
  const c = LOGO[name];
  if (!c || t < c.tIn - 0.01) return null;
  const tHand = Math.min(t, c.tFly + 0.08);
  const a = anchorAt(c.hand, tHand);
  if (!a) return null;
  const S = cubeSize(a);
  const side = c.dir;                                   // -1 = left of frame (GPT), +1 = right (Claude)
  const ph = name === 'gpt' ? 0 : 1.7;
  const n = { x: a.nx, y: a.ny };
  let x = a.x + n.x * cubeLift(a, S);
  let y = a.y + n.y * cubeLift(a, S);
  // entry: pops out of the click with one decelerating turn
  const pe = prog(t, c.tIn, 0.55);
  let scale = pe <= 0 ? 0 : E.outBack(pe, 2.0);
  y -= (1 - E.outCubic(pe)) * 70;
  let ry = side * 0.36 + (1 - E.outCubic(prog(t, c.tIn, 0.95))) * Math.PI * 2 * side;   // turned a little toward her
  let rx = 0.26;                                        // top face just visible (it sits below the lens)
  let rz = 0;
  // settle hop when she names the hand
  const ps = prog(t, c.tSettle, 0.5);
  if (ps > 0 && ps < 1) { y -= Math.sin(Math.PI * ps) * 20 * (1 - ps * 0.5); ry += Math.sin(Math.PI * ps) * 0.35 * side; }
  // idle hover: slow, small, never the same on both
  const ti = t - c.tIn;
  ry += 0.2 * Math.sin(2 * Math.PI * ti / 3.6 + ph);
  rx += 0.08 * Math.sin(2 * Math.PI * ti / 2.9 + ph + 0.8);
  rz += -Math.atan2(n.x, -n.y) * 0.3 + 0.05 * Math.sin(2 * Math.PI * ti / 3.3 + ph);
  y += 6 * Math.sin(2 * Math.PI * ti / 2.2 + ph);
  // float
  const pf = E.outCubic(prog(t, c.tFloat, 0.8));
  y -= 112 * pf;
  y += 5 * pf * Math.sin(2 * Math.PI * (t - c.tFloat) / 1.3 + ph);
  ry += pf * 0.32 * Math.sin(2 * Math.PI * (t - c.tFloat) / 2.4);
  rx -= pf * 0.08;
  // fly off to the side
  const g = prog(t, c.tFly, 0.66);
  let fly = 0;
  if (g > 0) {
    const ant = smooth(0, 0.2, g) * (1 - smooth(0.2, 0.34, g));      // anticipation dip
    y += 16 * ant; scale *= 1 - 0.06 * ant;
    const e = E.inCubic(clamp((g - 0.16) / 0.84));
    fly = e;
    x += c.dir * 1450 * e;
    y -= 230 * e - 40 * e * e;
    ry += c.dir * Math.PI * 2.2 * e;
    rx += 0.5 * e;
    rz += -c.dir * 0.45 * e;
    scale *= 1 + 0.25 * e;
  }
  if (g >= 1) return null;
  const [mx, my, ms] = mapPt(t, x, y);
  return { x: mx, y: my, S: S * ms, rx, ry, rz, scale, pe, pf, fly, a, ms };
}

function recallState(name, t) {
  const r = LOGO.recall;
  if (!r || !LOGO[name] || t < r.tIn - 0.01 || t > r.tOut + 0.32) return null;
  const dir = name === 'gpt' ? -1 : 1;
  const S = 112, ph = name === 'gpt' ? 0 : 1.3;
  let x = 960 + dir * 300, y = 126;
  const pi = E.outCubic(prog(t, r.tIn, 0.42));
  const po = E.inCubic(prog(t, r.tOut, 0.3));
  x += dir * (1 - pi) * 900 + dir * po * 900;
  y += -(1 - pi) * 60 - po * 60;
  const ti = t - r.tIn;
  let ry = dir * 0.34 + dir * (1 - pi) * Math.PI * 2 + 0.2 * Math.sin(2 * Math.PI * ti / 2.4 + ph) + dir * po * Math.PI * 2;
  y += 5 * Math.sin(2 * Math.PI * ti / 1.6 + ph);
  return { x, y, S, rx: 0.12, ry, rz: dir * 0.06, scale: 1, fly: Math.max(1 - pi, po) };
}

function applyMesh(g, st) {
  if (!st || st.scale <= 0.001) { g.visible = false; return; }
  g.visible = true;
  g.position.set(st.x - W / 2, H / 2 - st.y, 0);
  const s = st.S / 24 * st.scale;
  g.scale.set(s, s, s);
  g.rotation.set(st.rx, st.ry, st.rz);
}

const acc = document.getElementById('acc');
const actx = acc.getContext('2d');
function renderLogos(t) {
  const states = ts => ({ g: logoState('gpt', ts) || recallState('gpt', ts), c: logoState('claude', ts) || recallState('claude', ts) });
  const s0 = states(t);
  actx.clearRect(0, 0, W, H);
  if (!s0.g && !s0.c) return s0;
  const speed = Math.max(s0.g?.fly || 0, s0.c?.fly || 0, (s0.g && s0.g.pe < 1) ? 0.5 : 0, (s0.c && s0.c.pe < 1) ? 0.5 : 0);
  const N = speed > 0.02 ? 12 : 1;
  const shutter = 0.55;                              // fraction of a frame
  actx.globalCompositeOperation = N > 1 ? 'lighter' : 'source-over';
  actx.globalAlpha = 1 / N;
  for (let i = 0; i < N; i++) {
    const ts = N > 1 ? t + shutter * ((i + 0.5) / N - 0.5) / FPS : t;
    const s = N > 1 ? states(ts) : s0;
    applyMesh(gpt, s.g); applyMesh(cld, s.c);
    renderer.render(scene, camera);
    actx.drawImage(glc, 0, 0);
  }
  actx.globalAlpha = 1; actx.globalCompositeOperation = 'source-over';
  return s0;
}

// palm shadow, colour bounce, entry ring + burst
const fx = document.getElementById('fx');
const mk = (cls) => { const d = document.createElement('div'); d.className = cls; fx.appendChild(d); return d; };
const FX = {};
for (const n of ['gpt', 'claude']) FX[n] = { sh: mk('shadow'), bo: mk('bounce'), ring: mk('ring'), burst: mk('burst'), ring2: mk('ring') };
const rgb = h => [(h >> 16) & 255, (h >> 8) & 255, h & 255].join(',');
function fxColours() {
  for (const [n, side] of [['gpt', 'left'], ['claude', 'right']]) {
    const b = BR[side];
    FX[n].bo.style.background = `radial-gradient(closest-side, rgba(${rgb(b.glow)},.5), rgba(${rgb(b.glow)},0))`;
    FX[n].ring.style.borderColor = `rgba(${rgb(b.rim)},.95)`;
  }
}
function place(el, cx, cy, w, h, op, extra = '') {
  if (op <= 0.002) { el.style.opacity = 0; return; }
  el.style.left = (cx - w / 2) + 'px'; el.style.top = (cy - h / 2) + 'px';
  el.style.width = w + 'px'; el.style.height = h + 'px'; el.style.opacity = op; el.style.transform = extra;
}
function renderFX(t, s0) {
  for (const n of ['gpt', 'claude']) {
    const c = LOGO[n], f = FX[n], st = c ? logoState(n, t) : null;
    if (!st) { for (const k in f) f[k].style.opacity = 0; continue; }
    const a = st.a;
    const gp = mapPt(t, a.x + a.nx * 0.12 * a.size, a.y + a.ny * 0.12 * a.size);
    const ground = { x: gp[0], y: gp[1] };
    const lift = st.pf;
    const vis = clamp(st.pe * 1.4) * (1 - clamp(st.fly * 3));
    place(f.sh, ground.x, ground.y, st.S * (0.95 + 0.5 * lift), st.S * (0.26 + 0.12 * lift), 0.34 * vis * (1 - 0.65 * lift));
    place(f.bo, ground.x, ground.y - 6, st.S * 1.05, st.S * 0.45, 0.55 * vis * (1 - 0.7 * lift));
    const pr = prog(t, c.tIn + 0.04, 0.5);
    place(f.ring, st.x, st.y + 6, st.S * (0.5 + 1.0 * E.outCubic(pr)), st.S * (0.5 + 1.0 * E.outCubic(pr)), pr > 0 && pr < 1 ? 0.85 * (1 - pr) : 0);
    const pr2 = prog(t, c.tSettle + 0.02, 0.45);
    place(f.ring2, st.x, st.y, st.S * (0.7 + 0.8 * E.outCubic(pr2)), st.S * (0.7 + 0.8 * E.outCubic(pr2)), pr2 > 0 && pr2 < 1 ? 0.45 * (1 - pr2) : 0);
    const pb = prog(t, c.tIn, 0.36);
    place(f.burst, st.x, st.y, st.S * 1.7, st.S * 1.7, pb > 0 && pb < 1 ? 0.75 * (1 - E.outCubic(pb)) : 0);
  }
}

// ---------------------------------------------------------------- captions
const capsEl = document.getElementById('caps');
const capObjs = [];
function buildCaps() {
  for (const c of CAPS) {
    const el = document.createElement('div'); el.className = 'cap' + (c.pos === 'top' ? ' top' : '');
    const mkTheme = th => {
      const d = document.createElement('div'); d.className = 'th ' + th;
      const la = document.createElement('div'); la.className = 'la';
      const lb = document.createElement('div'); lb.className = 'lb';
      const words = [];
      for (const [txt, on] of c.A || []) { const s = document.createElement('span'); s.className = 'w'; s.textContent = txt; la.appendChild(s); words.push({ s, on, kind: 'A' }); }
      for (const [txt, on] of c.B || []) { const s = document.createElement('span'); s.className = 'w'; s.textContent = txt; lb.appendChild(s); words.push({ s, on, kind: 'B' }); }
      d.appendChild(la); if (c.B) d.appendChild(lb);
      el.appendChild(d);
      return { d, words };
    };
    const lite = mkTheme('lite'), dark = mkTheme('dark');
    capsEl.appendChild(el);
    capObjs.push({ c, el, lite, dark });
  }
}
function layoutCaps() {
  for (const o of capObjs) {
    // measure natural size (themes are absolutely positioned → measure the inner block)
    o.lite.d.style.width = 'max-content';
    const r = o.lite.d.getBoundingClientRect();
    o.w = Math.ceil(r.width) + 4; o.h = Math.ceil(r.height);
    o.el.style.width = o.w + 'px'; o.el.style.height = o.h + 'px';
    o.lite.d.style.width = o.dark.d.style.width = o.w + 'px';
    const mw = o.c.maxw || 590;                                          // long lines beside her shrink instead of reaching her
    o.k = ((o.c.pos === 'right' || o.c.pos === 'left') && o.w > mw) ? mw / o.w : 1;
    if (o.c.pos === 'right') { o.cx = Math.min(1566, 1868 - o.w * o.k / 2); o.cy = 548; }
    else if (o.c.pos === 'left') { o.cx = Math.max(52 + o.w * o.k / 2, 390); o.cy = 520; }
    else if (o.c.pos === 'top') { o.cx = 960; o.cy = 22 + o.h / 2; }
    else { o.cx = 960; o.cy = 925 - o.h / 2; }
    o.el.style.left = (o.cx - o.w / 2) + 'px'; o.el.style.top = (o.cy - o.h / 2) + 'px';
  }
}
function wipeX(t) { return WIPE ? lerp(WIPE.x0, WIPE.x1, E.inOutCubic(prog(t, WIPE.t0, WIPE.t1 - WIPE.t0))) : -1e4; }
function renderCaps(t) {
  const wx = wipeX(t);
  for (const o of capObjs) {
    const { c } = o;
    if (t < c.t0 - 0.06 || t > c.t1 + 0.02) { o.el.style.display = 'none'; continue; }
    o.el.style.display = 'block';
    const pe = prog(t, c.t1 - 0.1, 0.1);
    o.el.style.opacity = 1 - pe;
    o.el.style.transform = `translateY(${-12 * E.inCubic(pe)}px) scale(${o.k})`;
    o.el.style.filter = pe > 0 ? `blur(${pe * 7}px)` : 'none';
    // theme split at the wipe front (left of the front = cleared sky → dark ink)
    const left = o.cx - o.w * o.k / 2;
    const darkW = (!WIPE || c.t0 >= END.t0 - 0.02) ? 0 : clamp((wx + 110 - left) / o.k, 0, o.w);   // dark ink only on the cleared background
    o.dark.d.style.clipPath = `inset(-60px ${o.w - darkW}px -60px -60px)`;
    o.lite.d.style.clipPath = `inset(-60px -60px -60px ${darkW}px)`;
    o.dark.d.style.visibility = darkW > 0 ? 'visible' : 'hidden';
    o.lite.d.style.visibility = darkW < o.w ? 'visible' : 'hidden';
    for (const th of [o.lite, o.dark]) for (const w of th.words) {
      if (w.kind === 'A') {
        const p = prog(t, w.on - 0.05, 0.22);
        w.s.style.opacity = clamp(p * 1.8);
        w.s.style.transform = `translateY(${(1 - E.outBack(p, 1.6)) * 34}px) scale(${0.9 + 0.1 * E.outCubic(p)})`;
        w.s.style.filter = p < 1 ? `blur(${(1 - p) * 9}px)` : 'none';
      } else {
        const p = prog(t, w.on - 0.05, 0.34);
        const q = E.outCubic(p);
        w.s.style.opacity = clamp(p * 3);
        w.s.style.clipPath = `inset(-30% ${(1 - q) * 100}% -40% -12%)`;
        w.s.style.transform = `translateY(${(1 - q) * 16}px)`;
      }
    }
  }
}

// ---------------------------------------------------------------- init + frame API
async function init() {
  CFG = await (await fetch('data/edit.json')).json();
  FPS = CFG.fps;
  const b = CFG.beats || {}, lg = b.logos || {}, L = CFG.layout || {}, cs = L.caption_side || {};
  BR = { left: BRANDS[CFG.brands.left] || BRANDS.chatgpt, right: BRANDS[CFG.brands.right] || BRANDS.claude };
  const fl = lg.float ?? 1e9, fy = lg.fly ?? 1e9;
  if (lg.left != null) LOGO.gpt = { hand: 'L', tIn: lg.left + 0.04, tSettle: lg.left_settle ?? lg.left + 1.0, tFloat: fl, tFly: fy, dir: -1 };
  if (lg.right != null) LOGO.claude = { hand: 'R', tIn: lg.right + 0.04, tSettle: lg.right_settle ?? lg.right + 0.86, tFloat: fl + 0.06, tFly: fy + 0.10, dir: +1 };
  if (b.recall) LOGO.recall = { tIn: b.recall.in, tOut: b.recall.out };
  if (b.clear) WIPE = { t0: b.clear.t, t1: b.clear.t + 0.6, x0: -260, x1: 2180 };
  if (b.end) END.t0 = b.end.t;
  const side = cs.side || 'right', endSide = cs.end || side;
  CAPS = (CFG.captions || []).map(c => ({ ...c, pos: c.pos === 'side' ? (c.side || side) : c.pos === 'end' ? (c.side || endSide) : c.pos }));
  anchors = await (await fetch('data/anchors.json')).json();
  const camera = await (await fetch('data/camera.json')).json();
  const paths = { left: await brandSvgPath(BR.left), right: await brandSvgPath(BR.right) };
  await initEditor(CFG, camera, anchorAt, BR, paths);
  fxColours();
  gpt = await buildCube('logos/' + BR.left.svg, BR.left.cube, BR.left.glow, BR.left.rim, BR.left.logo);
  cld = await buildCube('logos/' + BR.right.svg, BR.right.cube, BR.right.glow, BR.right.rim, BR.right.logo);
  buildCaps();
  await document.fonts.load('98px Anton'); await document.fonts.load('118px ISerif'); await document.fonts.ready;
  layoutCaps();
}
window.ready = init().then(() => true);
window.renderFrame = async (f) => {
  const t = f / FPS;
  renderEditor(t);
  const s0 = renderLogos(t);
  renderFX(t, s0);
  renderCaps(t);
  await new Promise(r => requestAnimationFrame(() => r()));
  return true;
};
