"""Contact sheet of every beat of the finished edit — look at it before you call the edit done.

usage:  python3 qa.py <project_dir> [--video out/live_edit.mp4]
→ <project>/out/qa.jpg: one labelled tile per beat (the moment just after each command lands), in time order;
  prints frame count, duration and loudness (target −14 LUFS).
"""
import json, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, P, FF, FP, beat
ensure_venv()
from PIL import Image, ImageDraw

proj = project_dir(); cfg = load(proj)
video = sys.argv[sys.argv.index('--video') + 1] if '--video' in sys.argv else P(proj, 'out', 'live_edit.mp4')
B = lambda *k: beat(cfg, *k)
marks = [(0.3, 'hook')]
if B('tags'): marks += [(B('tags', 'left') + 0.5, 'tag left'), (B('tags', 'right') + 0.45 if B('tags', 'right') else None, 'tags + VS')]
if B('editor'): marks += [(B('editor', 'in') + 0.9, 'editor window'), (B('editor', 'live') + 0.3, 'LIVE')]
if B('logos'):
    marks += [(B('logos', 'left') + 0.6, 'left cube'), (B('logos', 'right') and B('logos', 'right') + 0.6, 'right cube'),
              (B('logos', 'float') and B('logos', 'float') + 0.6, 'float'), (B('logos', 'fly') and B('logos', 'fly') + 0.5, 'fly off')]
for d in B('difficulty') or []: marks.append((d['t'] + 0.3, d['label']))
if B('captions'): marks.append((B('captions', 'from') + 0.5, 'subtitles'))
if B('clip'): marks += [(B('clip', 'in') + 0.25, 'clip in'), (B('clip', 'in') + 1.2, 'clip'), (B('clip', 'out') - 0.1, 'clip out')]
if B('clear'): marks += [(B('clear', 't') + 0.3, 'clear (wipe)'), (B('clear', 't') + 1.0, 'cleared')]
if B('clone'): marks += [(B('clone', 't') + 0.25, 'clone slides out'), (B('clone', 't') + 1.2, 'two-shot')]
if B('recall'): marks.append((B('recall', 'in') + 0.5, 'who won?'))
if B('end'): marks += [(B('end', 't') + 0.6, 'ending'), (cfg['duration'] - 0.3, 'last frame')]
marks = sorted((t, l) for t, l in marks if t is not None and 0 <= t < cfg['duration'])
tiles = []
for t, label in marks:
    raw = subprocess.run([FF, '-v', 'error', '-ss', f'{t:.3f}', '-i', video, '-frames:v', '1', '-vf', 'scale=640:360', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'],
                         capture_output=True).stdout
    if len(raw) < 640 * 360 * 3: continue
    im = Image.new('RGB', (640, 384), (0, 0, 0)); im.paste(Image.frombytes('RGB', (640, 360), raw), (0, 0))
    ImageDraw.Draw(im).text((8, 368), f'{t:6.2f}s  {label}', fill=(255, 255, 255))     # label under the frame, not over it
    tiles.append(im)
cols = 3
S = Image.new('RGB', (640 * cols, 384 * ((len(tiles) + cols - 1) // cols)), 'black')
for i, im in enumerate(tiles): S.paste(im, ((i % cols) * 640, (i // cols) * 384))
S.save(P(proj, 'out', 'qa.jpg'), quality=86)
pr = json.loads(subprocess.run([FP, '-v', 'error', '-count_frames', '-show_entries', 'stream=nb_read_frames:format=duration', '-of', 'json', video],
                               capture_output=True, text=True).stdout)
lo = subprocess.run([FF, '-hide_banner', '-nostats', '-i', video, '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True).stderr
I = [l.strip() for l in lo.splitlines() if l.strip().startswith('I:')][-1:]
print(f'✓ out/qa.jpg ({len(tiles)} tiles)  video: {pr["streams"][0].get("nb_read_frames")} frames, {float(pr["format"]["duration"]):.2f} s, {I[0] if I else ""}')
