"""Palm tracking for the name tags and the 3D logo cubes (MediaPipe hands + pose) → work/stage/data/anchors.json

usage:  python3 track.py <project_dir>
Tracks the window from the first name tag to just after the logos fly off. L = the hand on the viewer's LEFT,
R = the hand on the viewer's RIGHT. Each anchor frame = [x, y, size, nx, ny, top]: palm centre, wrist→middle-knuckle
length, the palm's 'up' direction and the hand's highest point — smoothed (Savitzky–Golay) inside each shot only.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, P, src_frames, beat, MODELS, W, H
ensure_venv()
import numpy as np, mediapipe as mp
from mediapipe.tasks import python as mpt
from mediapipe.tasks.python import vision
from scipy.signal import savgol_filter

proj = project_dir(); cfg = load(proj); fps = cfg['fps']
starts = [x for x in (beat(cfg, 'tags', 'left'), beat(cfg, 'tags', 'right'), beat(cfg, 'logos', 'left'), beat(cfg, 'logos', 'right')) if x is not None]
if not starts:
    json.dump({}, open(P(proj, 'work', 'stage', 'data', 'anchors.json'), 'w')); raise SystemExit('no hand beats — nothing to track')
t0 = max(0.0, min(starts) - 0.4)
t1 = (beat(cfg, 'logos', 'fly') or max(starts) + 3) + 1.0
f0, f1 = round(t0 * fps), round(t1 * fps)
hl = vision.HandLandmarker.create_from_options(vision.HandLandmarkerOptions(
    base_options=mpt.BaseOptions(model_asset_path=os.path.join(MODELS, 'hand_landmarker.task')),
    running_mode=vision.RunningMode.VIDEO, num_hands=2, min_hand_detection_confidence=0.3,
    min_hand_presence_confidence=0.3, min_tracking_confidence=0.3))
rows = {'L': {}, 'R': {}}
for f, img in src_frames(proj, cfg, f0, (W, H)):
    if f > f1: break
    r = hl.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB, data=img.astype(np.uint8)), int(f * 1000 / fps))
    for lm in r.hand_landmarks:
        a = np.array([[q.x * W, q.y * H] for q in lm])
        side = 'L' if a[:, 0].mean() < W / 2 else 'R'
        palm = a[[0, 5, 9, 13, 17]].mean(0); size = float(np.linalg.norm(a[0] - a[9]))
        v = a[9] - a[0]; n = np.array([v[1], -v[0]]) if side == 'R' else np.array([-v[1], v[0]])
        if n[1] > 0: n = -n
        n = n / (np.linalg.norm(n) + 1e-6)
        rows[side][f] = [palm[0], palm[1], size, n[0], n[1], min(a[:, 1].min(), palm[1])]
cut_f = sorted(round(c * fps) for c in cfg.get('cuts', []))
out = {}
for side, R in rows.items():
    if len(R) < 5: print(f'! hardly any {side} hand found — is that palm raised and in frame?'); continue
    fr = np.arange(f0, f1 + 1); a = np.full((len(fr), 6), np.nan)
    for f, v in R.items(): a[f - f0] = v
    ok = ~np.isnan(a[:, 0]); idx = np.arange(len(a))
    for c in range(6): a[:, c] = np.interp(idx, idx[ok], a[ok, c])
    first, last = idx[ok][0], idx[ok][-1]
    sm = a.copy()
    bounds = [first] + [c - f0 for c in cut_f if first < c - f0 < last] + [last + 1]
    for s0, s1 in zip(bounds[:-1], bounds[1:]):
        for c in range(6):
            seg = a[s0:s1, c]
            if len(seg) > 9: sm[s0:s1, c] = savgol_filter(seg, 9, 2)
    out[side] = {'first': int(f0 + first), 'last': int(f0 + last),
                 'frames': {int(f0 + i): [round(float(x), 2) for x in sm[i]] for i in range(first, last + 1)}}
    print(f'{side}: {len(R)} tracked frames, {(f0 + first) / fps:.2f}s → {(f0 + last) / fps:.2f}s')
json.dump(out, open(P(proj, 'work', 'stage', 'data', 'anchors.json'), 'w'))
print('next: python3 layout.py', proj)
