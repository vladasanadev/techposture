"""Render the finished edit: graphics layer (if stale) → mix (if stale) → compositor → H.264 + AAC MP4.

usage:  python3 render.py <project_dir> [--name my_edit.mp4] [--gfx] [--mix] [--music bed.wav --music-db -14]
        --gfx / --mix force those steps to re-run (they also re-run automatically when edit.json is newer)
→ <project>/out/<name> (1920×1080, CRF 15, BT.709 tagged, AAC 256k). ~0.4–0.8 s per frame on an M-series Mac.
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, P, FF, HERE, nframes, cfg_path
ensure_venv()

proj = project_dir(); cfg = load(proj); NF = nframes(cfg)
name = sys.argv[sys.argv.index('--name') + 1] if '--name' in sys.argv else 'live_edit.mp4'
py = sys.executable
stamp = os.path.getmtime(cfg_path(proj))
last_gfx = P(proj, 'work', 'gfx', f'{NF - 1:05d}.png')
if '--gfx' in sys.argv or not os.path.exists(last_gfx) or os.path.getmtime(last_gfx) < stamp:
    subprocess.run([py, os.path.join(HERE, 'render_gfx.py'), proj], check=True)
mix = P(proj, 'audio', 'mix.wav')
if '--mix' in sys.argv or '--music' in sys.argv or not os.path.exists(mix) or os.path.getmtime(mix) < stamp:
    extra = ['--music', sys.argv[sys.argv.index('--music') + 1]] if '--music' in sys.argv else []
    if '--music-db' in sys.argv: extra += ['--music-db', sys.argv[sys.argv.index('--music-db') + 1]]
    subprocess.run([py, os.path.join(HERE, 'mix.py'), proj] + extra, check=True)
out = P(proj, 'out', name)
comp = subprocess.Popen([py, os.path.join(HERE, 'composite.py'), proj, '--pipe'], stdout=subprocess.PIPE)
enc = subprocess.run([FF, '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1920x1080', '-r', str(cfg['fps']), '-i', '-',
                      '-i', mix, '-map', '0:v', '-map', '1:a', '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p',
                      '-c:v', 'libx264', '-preset', 'slow', '-crf', '15', '-tune', 'film', '-colorspace', 'bt709', '-color_primaries', 'bt709',
                      '-color_trc', 'bt709', '-color_range', 'tv', '-movflags', '+faststart', '-c:a', 'aac', '-b:a', '256k', '-shortest', out],
                     stdin=comp.stdout)
comp.wait()
if enc.returncode or comp.returncode: raise SystemExit('✗ render failed')
print(f'✓ {out}\nnext: python3 qa.py {proj} --video {out}')
