"""Shared helpers for the live-edit engine: project config (edit.json), paths, ffmpeg, frame IO.

Every engine script takes the project directory as its first argument and reads/writes <project>/edit.json.
Times in edit.json are seconds on the take's own timeline. Output is always 1920×1080 @ the take's fps (30 recommended).
"""
import json, os, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
W, H = 1920, 1080


def _which(name):
    p = shutil.which(name)
    if p: return p
    for c in (os.path.expanduser(f'~/.local/bin/{name}'), f'/opt/homebrew/bin/{name}', f'/usr/local/bin/{name}'):
        if os.path.exists(c): return c
    return None


FF, FP = _which('ffmpeg'), _which('ffprobe')
VENV = os.environ.get('LIVEEDIT_VENV') or os.path.join(os.path.expanduser('~'), '.liveedit')
MODELS = os.path.join(VENV, 'models')


def venv_python():
    return os.path.join(VENV, 'Scripts', 'python.exe') if os.name == 'nt' else os.path.join(VENV, 'bin', 'python')


def ensure_venv():
    """Re-exec the current script inside the engine venv when it exists and we're not already in it."""
    py = venv_python()
    if os.path.exists(py) and os.path.realpath(sys.prefix) != os.path.realpath(VENV) and not os.environ.get('LIVEEDIT_NO_REEXEC'):
        os.environ['LIVEEDIT_NO_REEXEC'] = '1'
        os.execv(py, [py] + sys.argv)


def project_dir():
    if len(sys.argv) < 2:
        raise SystemExit(f'usage: {os.path.basename(sys.argv[0])} <project_dir> …')
    return os.path.abspath(sys.argv[1])


def cfg_path(proj): return os.path.join(proj, 'edit.json')


def load(proj):
    with open(cfg_path(proj)) as f: return json.load(f)


def save(proj, cfg):
    tmp = cfg_path(proj) + '.tmp'
    with open(tmp, 'w') as f: json.dump(cfg, f, indent=1, ensure_ascii=False)
    os.replace(tmp, cfg_path(proj))


def P(proj, *parts):
    p = os.path.join(proj, *parts)
    os.makedirs(os.path.dirname(p) if os.path.splitext(p)[1] else p, exist_ok=True)
    return p


def beat(cfg, *keys, default=None):
    """cfg['beats'][k1][k2]… or default when any level is missing/None."""
    v = cfg.get('beats', {})
    for k in keys:
        if not isinstance(v, dict) or v.get(k) is None: return default
        v = v[k]
    return v


def probe(path):
    out = subprocess.run([FP, '-v', 'error', '-select_streams', 'v:0', '-show_entries',
                          'stream=width,height,r_frame_rate,nb_frames:stream_tags=rotate:format=duration', '-of', 'json', path],
                         capture_output=True, text=True, check=True).stdout
    j = json.loads(out); s = j['streams'][0]
    num, den = s['r_frame_rate'].split('/')
    return {'w': int(s['width']), 'h': int(s['height']), 'fps': float(num) / float(den), 'duration': float(j['format']['duration'])}


def src_frames(proj, cfg, f0=0, size=None):
    """Yield (frame_index, float32 RGB array) of the take from frame f0, scaled to size (default: native source size)."""
    import numpy as np
    sw, sh = size or cfg['src_size']
    fps = cfg['fps']
    cmd = [FF, '-v', 'error', '-ss', f'{f0 / fps:.4f}', '-i', os.path.join(proj, cfg['source'])]
    if size: cmd += ['-vf', f'scale={sw}:{sh}:flags=lanczos']
    cmd += ['-f', 'rawvideo', '-pix_fmt', 'rgb24', '-']
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    f = f0
    try:
        while True:
            b = p.stdout.read(sw * sh * 3)
            if len(b) < sw * sh * 3: break
            yield f, np.frombuffer(b, np.uint8).reshape(sh, sw, 3).astype(np.float32)
            f += 1
    finally:
        p.kill()


def one_frame(proj, cfg, f, size=(W, H)):
    for _, img in src_frames(proj, cfg, f, size): return img


def nframes(cfg): return int(round(cfg['duration'] * cfg['fps']))
