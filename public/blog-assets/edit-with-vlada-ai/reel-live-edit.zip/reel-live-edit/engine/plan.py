"""Turn the transcript into the edit plan: which command lands on which word → edit.json "beats" + "captions".

usage:  python3 plan.py <project_dir> [--keep] [--clip-word tarantino] [--hook "WHO EDITS|BETTER?"]
Reads words.json + cuts. Every beat is optional: a command she didn't say is simply left out and the engine skips it.
--keep        keep beats AND captions already in edit.json (only fill what's missing) — use after hand-tuning
--clip-word   the word the movie clip lands on (default: tarantino, else the first "movie")
Prints the plan as a table with the words around each beat. ALWAYS read it: whisper mishears brand names
("chat gbt", "cloud"), and a beat in the wrong place is the most common mistake. Fix times by editing edit.json.
"""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, save, P
import json
ensure_venv()

def arg(name, default=None):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default

proj = project_dir(); cfg = load(proj)
WORDS = json.load(open(P(proj, 'words.json')))
norm = lambda w: re.sub(r'[^a-z0-9]', '', w.lower())
N = [norm(w[0]) for w in WORDS]
S = [w[1] for w in WORDS]
CUTS = cfg.get('cuts', [])
ALIAS = {'chatgpt': {'chatgpt', 'chat', 'gpt', 'gbt', 'chatgbt', 'chatgpts', 'chad'}, 'claude': {'claude', 'cloud', 'claud', 'clod', 'clode', 'klod', 'clawed'},
         'gemini': {'gemini', 'jemini'}, 'grok': {'grok', 'groq', 'grog', 'grock'}, 'perplexity': {'perplexity'}, 'meta': {'meta', 'llama'},
         'mistral': {'mistral'}, 'deepseek': {'deepseek', 'deep'}, 'copilot': {'copilot', 'pilot'}}


def find(keys, after=-1.0, before=1e9):
    keys = {keys} if isinstance(keys, str) else set(keys)
    for i, n in enumerate(N):
        if n in keys and after <= S[i] < before: return i
    return None


def find_all(keys, after=-1.0, before=1e9):
    keys = {keys} if isinstance(keys, str) else set(keys)
    return [i for i, n in enumerate(N) if n in keys and after <= S[i] < before]


def sent_start(i):
    """start time of the sentence containing word i (previous word ends with . ? ! or a pause > 0.35 s)"""
    j = i
    while j > 0 and not WORDS[j - 1][0].endswith(('.', '?', '!')) and S[j] - WORDS[j - 1][2] < 0.35: j -= 1
    return S[j]


VERBS = {'put', 'place', 'add', 'now', 'lets', 'let', 'make', 'try', 'overlay', 'clear', 'and', 'so', 'want', 'comment'}


def clause_start(i, verbs=VERBS, maxback=3.0):
    """start of the spoken command containing word i: the last command verb before it (whisper rarely punctuates)"""
    j = i
    while j > 0 and S[i] - S[j - 1] <= maxback:
        j -= 1
        if N[j] in verbs or WORDS[j][0].endswith(('.', '?', '!')): return S[j] if N[j] in verbs else S[j + 1]
    return max(0.0, S[i] - 1.0)


def cut_in(a, b):
    c = [x for x in CUTS if a <= x <= b]
    return c[0] if c else None


def r(x): return None if x is None else round(x, 3)


old = cfg.get('beats', {}) if '--keep' in sys.argv else {}
B = {}
bl, br = cfg['brands']['left'], cfg['brands']['right']
# ---- hook + names + VS (first ~10 s)
iL, iR = find(ALIAS.get(bl, {bl}), before=10), find(ALIAS.get(br, {br}), before=10)
if iL is not None and iR is not None:
    first = min(S[iL], S[iR])
    hook = arg('--hook')
    B['hook'] = {'text': hook.split('|') if hook else ['WHO EDITS', 'BETTER?'], 'out': r(first - 0.10)}
    tags = {'left': r(S[iL] - 0.02), 'right': r(S[iR] - 0.04)}
    io = find({'or', 'vs', 'versus'}, after=first, before=max(S[iL], S[iR]) + 0.01)
    if io is not None: tags['vs'] = r(S[io] - 0.04)
    B['tags'] = tags
    names_end = max(S[iL], S[iR])
else:
    names_end = 0.0
# ---- live editor window ("… edit this video in real time")
ireal = find({'real', 'live', 'realtime'}, after=names_end)
if ireal is not None and S[ireal] < names_end + 8:
    cin = cut_in(names_end + 0.15, S[ireal]) or sent_start(ireal) - 0.05
    nxt = find({'put', 'now', 'first', 'okay', 'ok'}, after=S[ireal] + 0.2)
    cout = cut_in(S[ireal] + 0.1, S[ireal] + 2.5) or (S[nxt] - 0.05 if nxt is not None else S[ireal] + 1.0)
    B['editor'] = {'in': r(cin), 'live': r(S[ireal] - 0.02), 'out': r(cout), 'filename': 'my_take_01.mov'}
# ---- logos on the hands ("put <brand> logo on my right hand")
logos = {}
for ih in find_all({'hand', 'palm'}):
    st = clause_start(ih, {'put', 'place', 'add', 'now'})
    side_word = find({'right', 'left'}, after=st - 0.01, before=S[ih] + 0.01)
    if side_word is None: continue
    sb = None
    for b, al in ALIAS.items():
        if find(al, after=st - 0.01, before=S[ih]) is not None: sb = b
    # her RIGHT hand appears on the viewer's LEFT (unless the take is mirrored)
    viewer = ('left' if N[side_word] == 'right' else 'right') if not cfg.get('mirrored') else N[side_word]
    il = find({'logo', 'logos', 'icon'}, after=st - 0.01, before=S[ih])
    click = (S[il] - 0.12) if il is not None else st + 0.6
    if viewer in logos: continue
    logos[viewer] = {'click': r(click), 'settle': r(S[side_word] - 0.03)}
    if sb and cfg['brands'][viewer] != sb:
        other = 'right' if viewer == 'left' else 'left'
        print(f'! she puts {sb} on the viewer-{viewer} hand → brands swapped')
        cfg['brands'][other], cfg['brands'][viewer] = cfg['brands'][viewer], sb
if logos:
    L = {'left': logos.get('left', {}).get('click'), 'right': logos.get('right', {}).get('click'),
         'left_settle': logos.get('left', {}).get('settle'), 'right_settle': logos.get('right', {}).get('settle')}
    last = max(v['click'] for v in logos.values())
    ifl, ify = find({'float', 'hover', 'levitate'}, after=last), find({'fly', 'flying', 'fly-off'}, after=last)
    if ifl is not None: L['float'] = r(S[ifl] - 0.06)
    if ify is not None: L['fly'] = r(S[ify] - 0.04)
    if L.get('fly') is None: L['fly'] = r((L.get('float') or last + 2.5) + 1.0)
    B['logos'] = {k: v for k, v in L.items() if v is not None}
# ---- difficulty punch-ins ("let's make it harder", "even harder")
diff = []
for ih in find_all({'harder', 'difficult', 'tougher'}):
    st = clause_start(ih, {'lets', 'let', 'make', 'try', 'now'})
    t = cut_in(st - 0.35, S[ih]) or st - 0.03
    even = ih > 0 and N[ih - 1] in ('even', 'much', 'way')
    diff.append({'t': r(t), 'label': 'EVEN HARDER' if (even or diff) else 'HARDER', 'level': 3 if (even or diff) else 2})
for k, d in enumerate(diff):
    nxt = [x for x in CUTS if x > d['t'] + 0.6]
    cap = diff[k + 1]['t'] - 0.2 if k + 1 < len(diff) else 1e9
    icl_ = find({'clear', 'remove', 'erase', 'delete'}, after=d['t'])
    cap = min(cap, S[icl_] - 0.10 if icl_ is not None else 1e9)
    d['out'] = r(min(nxt[0] - 0.08 if nxt else d['t'] + 1.2, d['t'] + 1.3, cap))
if diff: B['difficulty'] = diff[:2]
# ---- subtitles
isub = find({'subtitles', 'captions', 'subtitle', 'caption'})
if isub is not None: B['captions'] = {'from': r(S[isub] - 0.06)}
# ---- background clear + clone + who won + CTA
icl = find({'clear', 'remove', 'erase', 'delete'}, after=(S[isub] if isub is not None else 0))
if icl is not None: B['clear'] = {'t': r(S[icl] + 0.04)}
icn = find({'clone', 'copy', 'twin', 'duplicate'}, after=(S[icl] if icl is not None else 0))
if icn is not None: B['clone'] = {'t': r(S[icn] - 0.02)}
iwon = find({'won', 'win', 'wins'}, after=(S[icn] if icn is not None else 0))
if iwon is not None:
    iso = find({'so', 'now', 'okay', 'ok', 'well'}, after=S[iwon] - 1.2, before=S[iwon])
    iwho = find({'who', 'which', 'whose'}, after=S[iwon] - 1.0, before=S[iwon])
    t_in = S[iso] if iso is not None else (S[iwho] if iwho is not None else S[iwon] - 0.4)
    B['recall'] = {'in': r(t_in - 0.06), 'out': r(S[iwon] + 0.18)}
iwant = find({'want', 'wanna', 'if', 'comment'}, after=(WORDS[iwon][2] if iwon is not None else (S[icn] + 1.5 if icn is not None else 1e9)))
if iwant is not None:
    B['end'] = {'t': r(cut_in(S[iwant] - 0.4, S[iwant] + 0.1) or S[iwant] - 0.05)}
# ---- movie clip ("overlay a clip from any Tarantino movie when I say movie")
if cfg.get('clip_file'):
    cw = (arg('--clip-word') or 'tarantino').lower()
    ic = find({cw}) if find({cw}) is not None else find({'movie', 'film'})
    if ic is not None:
        stop = [d['t'] for d in diff if d['t'] > S[ic]] + ([B['clear']['t']] if 'clear' in B else []) + [S[ic] + 3.2]
        out = min(stop) - 0.012
        B['clip'] = {'in': r(S[ic] - 0.07), 'out': r(out), 'src_start': cfg.get('beats', {}).get('clip', {}).get('src_start') or cfg.get('clip_start', 0.0),
                     'pulses': [r(S[i]) for i in find_all({'movie', 'film'}, after=S[ic] + 0.05, before=out)]}
for k, v in old.items(): B[k] = v
cfg['beats'] = B

# ---- caption chunks (from "subtitles" to the end)
caps = []
if 'captions' in B:
    bounds = sorted([x for x in [B.get('clear', {}).get('t'), B.get('clone', {}).get('t'), B.get('recall', {}).get('in'),
                                 B.get('end', {}).get('t')] + [d['t'] for d in diff] if x])
    i0 = find({'subtitles', 'captions', 'subtitle', 'caption'})
    chunk = []
    def flush():
        if not chunk: return
        ws = [WORDS[i] for i in chunk]
        STOP = {'a', 'an', 'the', 'of', 'to', 'me', 'my', 'i', 'it', 'and', 'put', 'on', 'in', 'you', 'ill', 'your', 'is', 'this', 'at', 'so'}
        if len(ws) >= 2 and norm(ws[-1][0]) not in STOP:    # the accent (italic) word is the last content word
            nb = 2 if (len(ws) >= 3 and norm(ws[-2][0]) not in STOP and len(norm(ws[-2][0])) <= 4 and len(norm(ws[-1][0])) <= 4) else 1
        else:
            nb = 0
        A = [[re.sub(r'[,.!]', '', w[0]).upper().replace("'", '’'), r(w[1])] for w in ws[:len(ws) - nb]]
        Bw = []
        for k, w in enumerate(ws[len(ws) - nb:]):
            txt = re.sub(r'[,.!]', '', w[0]).lower().replace("'", '’')
            prev = norm(ws[len(ws) - nb + k - 1][0]) if len(ws) - nb + k - 1 >= 0 else ''
            if prev in ('say', 'comment', 'type', 'write'): txt = f'“{txt}”'
            Bw.append([txt, r(w[1])])
        if not A: A, Bw = [[Bw[0][0].upper().strip('“”'), Bw[0][1]]], []
        caps.append({'t0': r(ws[0][1] - 0.06), 'A': A, **({'B': Bw} if Bw else {})})
        chunk.clear()
    BREAK = {'using', 'from', 'when', 'lets', 'clear', 'on', 'and', 'next', 'so', 'want', 'like', 'comment', 'my', 'overlay', 'put', 'with', 'if'}
    for i in range(i0, len(WORDS)):
        w = WORDS[i]
        if chunk:
            prev = WORDS[chunk[-1]]
            gap = w[1] - prev[2]
            crossed = any(prev[1] + 0.12 < b <= w[1] + 0.12 for b in bounds)
            if (prev[0].endswith(('.', '?', '!', ',')) or gap > 0.3 or len(chunk) >= 4 or crossed or chunk[0] == i0
                    or (N[i] in BREAK and not (len(chunk) == 1 and N[chunk[0]] in ('and', 'so', 'if', 'to', 'a', 'the', 'but')))):
                flush()
        chunk.append(i)
    flush()
    tend = cfg['duration'] + 0.15
    for k, c in enumerate(caps):
        c['t1'] = caps[k + 1]['t0'] if k + 1 < len(caps) else round(tend, 3)
        t = c['t0'] + 0.07
        c['pos'] = 'top' if ('clone' in B and B['clone']['t'] - 0.1 <= t < B.get('end', {}).get('t', 1e9)) else ('end' if 'end' in B and t >= B['end']['t'] - 0.05 else 'side')
if '--keep' in sys.argv and cfg.get('captions'):
    print('captions kept from edit.json (--keep)')
else:
    cfg['captions'] = caps
save(proj, cfg)

# ---- report
def ctx(t):
    i = min(range(len(WORDS)), key=lambda k: abs(S[k] - t))
    return ' '.join(w[0] for w in WORDS[max(0, i - 2):i + 3])
print(f'brands: left hand on screen = {cfg["brands"]["left"]}, right = {cfg["brands"]["right"]}')
rows = []
for k, v in B.items():
    if isinstance(v, dict):
        for kk, vv in v.items():
            if isinstance(vv, (int, float)) and kk not in ('level', 'src_start'): rows.append((vv, f'{k}.{kk}'))
    elif isinstance(v, list):
        for j, d in enumerate(v): rows += [(d['t'], f'{k}[{j}].t {d["label"]}'), (d['out'], f'{k}[{j}].out')]
for t, name in sorted(rows): print(f'{t:7.2f}  {name:<22} …{ctx(t)}…')
missing = [k for k in ('hook', 'tags', 'editor', 'logos', 'difficulty', 'captions', 'clip', 'clear', 'clone', 'recall', 'end') if k not in B]
if 'clip' not in B and not cfg.get('clip_file'): missing = [m for m in missing if m != 'clip']
print('not found (skipped unless you add them):', ', '.join(missing) or 'none')
print(f'{len(caps)} caption chunks')
print('next: python3 matte.py', proj)
