"""Measure her in the frame (from the matte) and lay out everything that depends on where she stands.

usage:  python3 layout.py <project_dir>
Writes edit.json "layout":
  face        per shot: head centre x, head width, head top, face centre y (camera push / punch-ins aim here)
  two_shot    per shot inside the clone section: head x / width / top (both copies are scaled to the same head size)
  clip_side   which side of her the movie card floats on (the emptier side), and her head x at that moment
  caption_side  where side captions go for the subtitles section ('side') and for the ending ('end')
Re-run after changing cuts or beats. Everything here can be overridden by hand.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, save, P, beat, W, H, nframes, one_frame
ensure_venv()
import numpy as np
from PIL import Image

proj = project_dir(); cfg = load(proj); fps = cfg['fps']; NF = nframes(cfg)


def alpha(f):
    p = P(proj, 'work', 'alpha', f'{f:05d}.png')
    return np.asarray(Image.open(p), np.float32) / 255 if os.path.exists(p) else None


def head(a):
    rows = np.where((a > 0.5).sum(1) > 6)[0]
    if not len(rows): return None
    top = int(rows[0])
    band = a[top + 40:top + 160] > 0.5
    xs = [np.where(r)[0] for r in band if r.any()]
    if not xs: return None
    lo = float(np.median([x[0] for x in xs])); hi = float(np.median([x[-1] for x in xs]))
    hw = hi - lo
    return {'x': round((lo + hi) / 2, 1), 'w': round(hw, 1), 'top': top, 'face_y': round(float(np.clip(top + 0.9 * hw, 300, 620)), 1)}


def shot_bounds():
    c = [0.0] + sorted(cfg.get('cuts', [])) + [cfg['duration']]
    return [(c[i], c[i + 1]) for i in range(len(c) - 1) if c[i + 1] - c[i] > 0.05]


def med_head(t0, t1):
    fs = np.linspace(round(t0 * fps) + 1, min(NF - 1, round(t1 * fps) - 1), 7).astype(int)
    hs = [h for h in (head(alpha(f)) for f in fs if alpha(f) is not None) if h]
    if not hs: return None
    return {k: round(float(np.median([h[k] for h in hs])), 1) for k in hs[0]}


def extents(t0, t1, y0=380, y1=720):
    lo, hi = [], []
    for f in np.linspace(round(t0 * fps), min(NF - 1, round(t1 * fps)), 9).astype(int):
        a = alpha(f)
        if a is None: continue
        cols = np.where((a[y0:y1] > 0.5).any(0))[0]
        if len(cols): lo.append(cols[0]); hi.append(cols[-1])
    return (float(np.percentile(lo, 10)), float(np.percentile(hi, 90))) if lo else (W * 0.3, W * 0.7)


L = cfg.get('layout', {})
L['face'] = [{'t0': round(a, 3), 't1': round(b, 3), **(med_head(a, b) or {'x': W / 2, 'w': 330, 'top': 100, 'face_y': 430})} for a, b in shot_bounds()]
ct, et = beat(cfg, 'clone', 't'), beat(cfg, 'end', 't') or cfg['duration']
if ct is not None:
    L['two_shot'] = [{'t0': round(a, 3), 't1': round(b, 3), **med_head(max(a, ct), min(b, et))}
                     for a, b in shot_bounds() if b > ct + 0.05 and a < et - 0.05]
if beat(cfg, 'clip', 'in') is not None:
    t0, t1 = beat(cfg, 'clip', 'in'), beat(cfg, 'clip', 'out')
    lo, hi = extents(t0, t1, 120, 640)
    h = med_head(t0, t1) or {'x': W / 2, 'top': 100}
    L['clip_side'] = {'side': 'left' if lo > W - hi else 'right', 'head_x': h['x'], 'head_top': h['top'], 'free_left': round(lo), 'free_right': round(W - hi)}
cs = {}
c0 = beat(cfg, 'captions', 'from')
if c0 is not None:
    lo, hi = extents(c0, beat(cfg, 'clear', 't') or ct or et)
    cs['side'] = 'right' if W - hi >= lo else 'left'
    if 'clip_side' in L:                       # never on the same side as the movie card
        cs['side'] = 'right' if L['clip_side']['side'] == 'left' else 'left'
if beat(cfg, 'end', 't') is not None:
    lo, hi = extents(et, cfg['duration'] - 0.1)
    cs['end'] = 'right' if W - hi > lo + 60 else 'left'
L['caption_side'] = cs
# per-chunk side: the section default unless she reaches into it during that chunk (a raised hand, a lean)
clip_t = (beat(cfg, 'clip', 'in'), beat(cfg, 'clip', 'out')) if 'clip_side' in L else None
for c in cfg.get('captions', []):
    if c.get('pos') not in ('side', 'end'): c.pop('side', None); continue
    default = cs.get('side' if c['pos'] == 'side' else 'end', 'right')
    lo, hi = extents(c['t0'], max(c['t0'] + 0.1, c['t1'] - 0.05))
    for k, d in enumerate(beat(cfg, 'difficulty', default=[])):          # a punch-in scales her up around her face
        if c['t0'] < d['out'] and c['t1'] > d['t']:
            amp = 1.13 if k == 0 else 1.15
            fx = next((f['x'] for f in L['face'] if f['t0'] <= d['t'] + 0.05 < f['t1']), W / 2)
            lo, hi = fx - (fx - lo) * amp, fx + (hi - fx) * amp
    free = {'left': max(0, lo), 'right': max(0, W - hi)}
    other = 'left' if default == 'right' else 'right'
    if not (clip_t and c['t0'] < clip_t[1] and c['t1'] > clip_t[0]) and free[default] < 560 and free[other] > free[default] + 80:
        default = other
    c['side'] = default
    c['maxw'] = int(max(380, min(620, free[default] - 70)))             # captions shrink instead of touching her
# matte clean-up: "auto" → "window" when the background behind her is bright (a window / sky / city)
if cfg.get('matte', {}).get('cleanup', 'auto') == 'auto':
    lum = []
    for f in np.linspace(5, NF - 5, 6).astype(int):
        a = alpha(f)
        if a is None: continue
        img = one_frame(proj, cfg, int(f))
        bgm = a[:int(H * 0.6)] < 0.05
        if bgm.sum() > 1000: lum.append(float((img[:int(H * 0.6)] @ np.array([0.299, 0.587, 0.114]))[bgm].mean()))
    cfg.setdefault('matte', {})['cleanup'] = 'window' if lum and np.median(lum) > 170 else 'none'
    print('matte cleanup →', cfg['matte']['cleanup'], f'(background brightness {np.median(lum):.0f})' if lum else '')
cfg['layout'] = L
save(proj, cfg)
for k, v in L.items():
    if isinstance(v, list): print(k, *[f"\n   {d['t0']:6.2f}–{d['t1']:6.2f}  x {d['x']:.0f}  w {d['w']:.0f}  top {d['top']:.0f}" for d in v])
    else: print(k, v)
print('next: python3 camera.py', proj)
