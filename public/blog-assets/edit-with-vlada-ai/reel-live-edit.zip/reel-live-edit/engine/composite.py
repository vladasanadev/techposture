"""Final picture: the take through the virtual camera → movie card behind her → background clear (wipe to a clean
sky) → the clone two-shot (a duplicate of her own matte slides out of her) → back to the untouched take for the
ending → graphics layer on top.

usage:  python3 composite.py <project_dir> --pipe [f0 f1]           raw rgb24 frames to stdout (render.py uses this)
        python3 composite.py <project_dir> --stills f1,f2,… out.jpg [--nogfx | --gfx-test]   contact sheet for checking
        (--gfx-test uses the frames from render_gfx.py --at; default uses the full work/gfx render)
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, load, P, src_frames, beat, W, H, nframes
ensure_venv()
import numpy as np, cv2
from PIL import Image
from bg import sky_bg, clean_alpha, despill_gaps, kill_bright_hair_gaps
from clip import Clip

proj = os.path.abspath(sys.argv[1]); cfg = load(proj); fps = cfg['fps']; NF = nframes(cfg)
GFX = os.environ.get('GFX', P(proj, 'work', 'gfx'))
CAM = json.load(open(P(proj, 'work', 'stage', 'data', 'camera.json')))
SKY = sky_bg()
UI_BG = np.array([11, 13, 17], np.float32)
K_SRC = W / cfg['src_size'][0]                               # take px → 1920 px
WIPE_T0 = beat(cfg, 'clear', 't', default=1e9); WIPE_T1 = WIPE_T0 + 0.6; WX0, WX1 = -260, 2180
CLONE_T0 = beat(cfg, 'clone', 't', default=1e9); SLIDE = 0.52
END_T0 = beat(cfg, 'end', 't', default=1e9)
CLEAN = cfg.get('matte', {}).get('cleanup', 'none') == 'window'
CLIP = Clip(proj, cfg) if beat(cfg, 'clip', 'in') is not None and cfg.get('clip_file') else None
SEGS = cfg.get('layout', {}).get('two_shot', [])
TW = 0.122 * W                                               # both heads this wide in the two-shot
side = cfg.get('clone_side', 'left')
CLONE_X, HER_X = (0.307 * W, 0.696 * W) if side == 'left' else (0.696 * W, 0.307 * W)


def ease_io(x): x = min(1, max(0, x)); return 4 * x ** 3 if x < .5 else 1 - (-2 * x + 2) ** 3 / 2
def smoothstep(a, b, x): t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)


def cam_warp(src, f):
    s, cx, cy, ox, oy = CAM[min(f, len(CAM) - 1)]
    k = K_SRC * s; tx, ty = ox - cx * s, oy - cy * s
    if abs(s - 1) < 1e-6 and abs(tx) < 1e-6 and abs(ty) < 1e-6: return cv2.resize(src, (W, H), interpolation=cv2.INTER_AREA)
    if k < 0.98:
        img = cv2.resize(src, None, fx=k, fy=k, interpolation=cv2.INTER_AREA); M = np.float32([[1, 0, tx], [0, 1, ty]])
    else:
        img = src; M = np.float32([[k, 0, tx], [0, k, ty]])
    out = cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR if k < 0.98 else cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=(-1, -1, -1))
    hole = out[..., 0] < -0.5
    if hole.any(): out[hole] = UI_BG
    return out


def her_layer(f, src):
    a = np.asarray(Image.open(P(proj, 'work', 'alpha', f'{f:05d}.png')), np.float32) / 255
    a = clean_alpha(a)
    if CLEAN: a = kill_bright_hair_gaps(despill_gaps(a, src), src)
    p = P(proj, 'work', 'fgr', f'{f:05d}.png')
    fg = np.asarray(Image.open(p), np.float32) if os.path.exists(p) else src
    core = np.clip((a - 0.92) / 0.08, 0, 1)[..., None]      # keep true pixels inside, fgr only at soft edges
    return fg * (1 - core) + src * core, a


def over(dst, fg, a): a3 = a[..., None]; return fg * a3 + dst * (1 - a3)


def with_clip(f, t, base):
    L = CLIP.layer(t, fps) if CLIP else None
    if L is None: return base
    c, ca, sh = L
    bg = base * (1 - sh[..., None]); bg = c + bg * (1 - ca[..., None])
    fg, a = her_layer(f, base)
    a = cv2.GaussianBlur(a, (0, 0), 1.3)
    comp = over(bg, fg, a)
    M = np.clip(cv2.GaussianBlur(cv2.dilate(((ca + sh) > 0.002).astype(np.float32), np.ones((41, 41), np.uint8)), (0, 0), 8), 0, 1)[..., None]
    return base + (comp - base) * M


def seg_at(t):
    for s in SEGS:
        if s['t0'] <= t < s['t1']: return s
    return SEGS[-1] if SEGS else {'t0': CLONE_T0, 't1': END_T0, 'x': W / 2, 'w': 300, 'top': 100}


def xform(t, target_x):
    s = seg_at(t); sc = TW / max(60, s['w'])
    tx_end, ty_end = target_x - s['x'] * sc, H - H * sc       # bottom-anchored
    if t < CLONE_T0: return 1.0, 0.0, 0.0
    first = s['t0'] <= CLONE_T0 + 1e-6
    p = ease_io((t - CLONE_T0) / SLIDE) if first else 1.0
    return 1 + (sc - 1) * p, tx_end * p, ty_end * p


def warp(img, sc, tx, ty):
    M = np.float32([[sc, 0, tx], [0, sc, ty]])
    return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_AREA if sc < 1 else cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)


def blur_layer(out, fg, a, t, target_x, shutter, fade=1.0):
    acc_f = np.zeros_like(out); acc_a = np.zeros((H, W), np.float32); n = 8
    for i in range(n):
        sc, tx, ty = xform(t + shutter * ((i + 0.5) / n - 0.5) / fps, target_x)
        wa = warp(a, sc, tx, ty); acc_f += warp(fg, sc, tx, ty) * wa[..., None]; acc_a += wa
    acc_a /= n
    return over(out, acc_f / np.maximum(acc_a[..., None] * n, 1e-4), acc_a * fade)


def frame(f, src_full):
    t = f / fps
    if t < WIPE_T0 - 1e-6 or t >= END_T0 - 1e-6:
        base = cam_warp(src_full, f)
        if CLIP and CLIP.t_in <= t < CLIP.t_end: base = with_clip(f, t, base)
        return base
    src = cv2.resize(src_full, (W, H), interpolation=cv2.INTER_AREA)
    fg, a = her_layer(f, src)
    if t < CLONE_T0:
        clean = over(SKY, fg, a)
        if t >= WIPE_T1: return clean
        wx = WX0 + (WX1 - WX0) * ease_io((t - WIPE_T0) / (WIPE_T1 - WIPE_T0))
        xs = np.arange(W, dtype=np.float32)[None, :]
        m = smoothstep(wx + 70, wx - 70, xs)[..., None]
        band = np.exp(-((xs - wx) / 46.0) ** 2)[..., None] * (1 - a[..., None])
        bg = SKY * m + src * (1 - m) + band * np.array([54, 54, 50], np.float32)
        return np.clip(over(bg, fg, a), 0, 255)
    out = SKY.copy()
    sliding = t < CLONE_T0 + SLIDE + 0.05
    if sliding:
        out = blur_layer(out, fg, a, t, CLONE_X, 1.0, float(np.clip((t - CLONE_T0) / SLIDE / 0.28, 0, 1)))
        out = blur_layer(out, fg, a, t, HER_X, 0.8)
    else:
        for x in (CLONE_X, HER_X):
            sc, tx, ty = xform(t, x); out = over(out, warp(fg, sc, tx, ty), warp(a, sc, tx, ty))
    return np.clip(out, 0, 255)


def gfx_over(f, img):
    p = os.path.join(GFX, f'{f:05d}.png')
    if not os.path.exists(p): return img
    g = np.asarray(Image.open(p).convert('RGBA'), np.float32); ga = g[..., 3:4] / 255
    return g[..., :3] * ga + img * (1 - ga)


if __name__ == '__main__':
    if sys.argv[2] == '--pipe':
        f0 = int(sys.argv[3]) if len(sys.argv) > 3 else 0
        f1 = int(sys.argv[4]) if len(sys.argv) > 4 else NF - 1
        out = sys.stdout.buffer
        for f, src in src_frames(proj, cfg, f0):
            if f > f1: break
            out.write(np.clip(gfx_over(f, frame(f, src)) + 0.5, 0, 255).astype(np.uint8).tobytes())
            if f % 90 == 0: print('frame', f, file=sys.stderr, flush=True)
    elif sys.argv[2] == '--stills':
        fr = [int(x) for x in sys.argv[3].split(',')]
        if '--gfx-test' in sys.argv: GFX = P(proj, 'work', 'gfx_test')
        tiles = []
        for f in fr:
            for _, src in src_frames(proj, cfg, f):
                img = frame(f, src) if '--nogfx' in sys.argv else gfx_over(f, frame(f, src)); break
            tiles.append(Image.fromarray(np.clip(img + .5, 0, 255).astype(np.uint8)).resize((960, 540), Image.LANCZOS))
        cols = 2
        S = Image.new('RGB', (960 * cols, 540 * ((len(tiles) + cols - 1) // cols)))
        for i, im in enumerate(tiles): S.paste(im, ((i % cols) * 960, (i // cols) * 540))
        S.save(sys.argv[4], quality=88); print('→', sys.argv[4])
