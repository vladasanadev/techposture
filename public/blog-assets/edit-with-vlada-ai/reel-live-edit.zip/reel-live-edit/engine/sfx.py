"""Code-synthesised sound effects for the live edit (no samples, nothing to license). 48 kHz mono float32.

usage:  python3 sfx.py <out_dir> [name …]      writes <name>.wav (default: every effect the mix uses)
Uses bedkit.py (the reel kit's synth) for pops/clicks/shimmers and adds whooshes, a riser and a deep impact.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv
ensure_venv()
import numpy as np
import bedkit as K

SR = K.SR
rng = np.random.default_rng(11)


def _sweep_noise(dur, f0, f1, att, rel, q=1.6, steps=24, curve=1.0):
    n = int(dur * SR)
    x = rng.standard_normal(n)
    out = np.zeros(n)
    for i in range(steps):
        a, b = int(i * n / steps), int((i + 1) * n / steps)
        u = ((i + 0.5) / steps) ** curve
        f = f0 * (f1 / f0) ** u
        seg = K.bp(x[max(0, a - 2000):b], f / q, min(f * q, SR / 2 - 200))[-(b - a):]
        out[a:b] = seg
    t = np.arange(n) / SR
    env = np.minimum(1, t / att) * np.clip((dur - t) / rel, 0, 1) ** 1.5
    return out * env


def whoosh():           # short air whoosh, rising then falling band
    n1 = _sweep_noise(0.42, 260, 3200, 0.16, 0.26, curve=0.8)
    return n1 + 0.4 * _sweep_noise(0.42, 520, 6000, 0.18, 0.24, q=2.2)


def whoosh_short():
    return _sweep_noise(0.24, 500, 4200, 0.07, 0.17, curve=0.7)


def whoosh_long():      # the background-clear sweep
    a = _sweep_noise(0.95, 180, 5200, 0.45, 0.45, curve=1.1)
    return a + 0.35 * _sweep_noise(0.95, 900, 9000, 0.5, 0.4, q=2.4)


def riser():
    n = int(1.15 * SR); t = np.arange(n) / SR
    x = _sweep_noise(1.15, 300, 7000, 1.0, 0.05, curve=1.6)
    tone = np.sin(2 * np.pi * np.cumsum(220 * (2 ** (t / 1.15 * 1.5))) / SR) * 0.15 * (t / 1.15) ** 2
    return x * (t / 1.15) ** 1.5 + tone


def impact():           # deep thump for punch-ins / the clone drop
    n = int(0.9 * SR); t = np.arange(n) / SR
    f = 38 + 80 * np.exp(-t / 0.05)
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.32)
    click = K.hp(rng.standard_normal(n), 1200) * np.exp(-t / 0.012) * 0.35
    return np.tanh((body + click) * 1.6)


EXTRA = {'whoosh': whoosh, 'whoosh-short': whoosh_short, 'whoosh-long': whoosh_long, 'riser': riser, 'impact': impact}
USED = ['pop', 'click', 'click-soft', 'tick', 'ping', 'shimmer', 'glass-tink', 'chip-select', 'chip-powerup', 'pluck-up', 'swish-soft',
        'impact-bass-1'] + list(EXTRA)


def render(out_dir, names=None):
    os.makedirs(out_dir, exist_ok=True)
    names = names or USED
    for nm in names:
        p = os.path.join(out_dir, nm + '.wav')
        if os.path.exists(p): continue
        if nm in EXTRA: K.write(p, K.sfx_finish(EXTRA[nm](), 30.0, -3.0))
        else: K.render_sfx([nm], out_dir)
    return out_dir


if __name__ == '__main__':
    render(sys.argv[1], sys.argv[2:] or None)
