"""Render the graphics layer (hook, tags, editor UI, cursors, 3D glass logo cubes, captions, difficulty meter)
to transparent PNGs, one per frame, with headless Chrome.

usage:  python3 render_gfx.py <project_dir> [f0 f1]          all frames (or a range) → work/gfx/%05d.png
        python3 render_gfx.py <project_dir> --at 210,330,…   just these frames → work/gfx_test/ (quick look)
Builds work/stage/ from engine/stage + the project's data (edit.json, anchors, camera, editor filmstrip + waveform).
~0.06 s/frame with Chrome's GPU path. Re-run after any change to edit.json beats/captions or brands.
"""
import json, os, shutil, socket, subprocess, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, P, HERE, FF, nframes, src_frames
ensure_venv()
import numpy as np
from PIL import Image

proj = project_dir(); cfg = load(proj); NF = nframes(cfg)
st = P(proj, 'work', 'stage')
for name in os.listdir(os.path.join(HERE, 'stage')):                    # fresh copy of the engine stage
    s, d = os.path.join(HERE, 'stage', name), os.path.join(st, name)
    if os.path.isdir(s): shutil.copytree(s, d, dirs_exist_ok=True)
    else: shutil.copy2(s, d)
json.dump(cfg, open(P(proj, 'work', 'stage', 'data', 'edit.json'), 'w'))
for need in ('anchors.json', 'camera.json'):
    if not os.path.exists(P(proj, 'work', 'stage', 'data', need)):
        raise SystemExit(f'✗ work/stage/data/{need} missing — run {"track.py" if need == "anchors.json" else "camera.py"} first')
# editor filmstrip (16 thumbnails) + waveform (420 bins) of the take
ed = P(proj, 'work', 'stage', 'editor')
if not os.path.exists(os.path.join(ed, 'th_15.jpg')):
    for i, f in enumerate(np.linspace(3, NF - 4, 16).astype(int)):
        for _, img in src_frames(proj, cfg, int(f), (192, 108)):
            Image.fromarray(img.astype(np.uint8)).save(os.path.join(ed, f'th_{i:02d}.jpg'), quality=82); break
wv = P(proj, 'work', 'stage', 'data', 'wave.json')
if not os.path.exists(wv):
    raw = subprocess.run([FF, '-v', 'error', '-i', os.path.join(proj, cfg['source']), '-vn', '-ac', '1', '-ar', '8000', '-f', 'f32le', '-'],
                         capture_output=True).stdout
    a = np.abs(np.frombuffer(raw, np.float32)); bins = np.array_split(a, 420)
    v = np.array([np.sqrt(np.mean(b ** 2)) if len(b) else 0 for b in bins]); v = (v / (np.percentile(v, 98) + 1e-6)).clip(0, 1)
    json.dump([round(float(x), 3) for x in v], open(wv, 'w'))

if len(sys.argv) > 2 and sys.argv[2] == '--at':
    frames = [int(x) for x in sys.argv[3].split(',')]; out = P(proj, 'work', 'gfx_test')
else:
    f0 = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    f1 = int(sys.argv[3]) if len(sys.argv) > 3 else NF - 1
    frames = list(range(f0, f1 + 1)); out = P(proj, 'work', 'gfx')
s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
# plain TCPServer: http.server's HTTPServer calls socket.getfqdn() on bind, which can hang on a slow resolver
SRV = ('import http.server, socketserver, sys\n'
       'class S(socketserver.ThreadingMixIn, socketserver.TCPServer): allow_reuse_address = True; daemon_threads = True\n'
       'class Q(http.server.SimpleHTTPRequestHandler):\n    def log_message(self, *a): pass\n'
       'S(("127.0.0.1", int(sys.argv[1])), Q).serve_forever()')
srv = subprocess.Popen([sys.executable, '-c', SRV, str(port)], cwd=st, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(0.8)
from playwright.sync_api import sync_playwright
try:
    with sync_playwright() as p:
        try: b = p.chromium.launch(channel='chrome', args=['--use-angle=metal', '--enable-gpu', '--ignore-gpu-blocklist'])
        except Exception: b = p.chromium.launch(args=['--ignore-gpu-blocklist', '--enable-unsafe-swiftshader'])
        pg = b.new_page(viewport={'width': 1920, 'height': 1080}, device_scale_factor=1)
        logs = []
        pg.on('console', lambda m: logs.append(m.text)); pg.on('pageerror', lambda e: logs.append('ERR ' + str(e)))
        pg.goto(f'http://127.0.0.1:{port}/index.html')
        pg.wait_for_function('window.ready !== undefined'); pg.evaluate('window.ready')
        t0 = time.time()
        for i, f in enumerate(frames):
            pg.evaluate(f'window.renderFrame({f})')
            pg.screenshot(path=f'{out}/{f:05d}.png', omit_background=True)
            if i % 100 == 99: print(f'{i + 1}/{len(frames)}  {(time.time() - t0) / (i + 1):.3f} s/f', flush=True)
        errs = [l for l in logs if 'ERR' in l or 'rror' in l]
        for l in errs[:10]: print('console:', l)
        b.close()
finally:
    srv.terminate()
print(f'gfx: {len(frames)} frames → {os.path.relpath(out, proj)}\nnext: python3 render.py {proj}')
