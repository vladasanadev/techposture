"""Background + matte helpers: the clean sky that replaces her room on "clear everything", and matte clean-ups.
clean_alpha always runs; despill_gaps / kill_bright_hair_gaps only with edit.json matte.cleanup = "window"
(tuned for a bright window / city behind her: they remove sky and buildings that the matte keeps in arm gaps and hair)."""
import numpy as np
from scipy import ndimage
W, H = 1920, 1080
def sky_bg(seed=1, w=W, h=H):
    y = np.linspace(0, 1, h)[:, None, None]; x = np.linspace(0, 1, w)[None, :, None]
    top = np.array([150, 189, 228.]); mid = np.array([196, 220, 242.]); bot = np.array([233, 241, 249.])
    t = y ** 0.9
    c = np.where(t < 0.55, top + (mid - top) * (t / 0.55), mid + (bot - mid) * ((t - 0.55) / 0.45))
    c = c * np.ones((1, w, 1))
    # soft sun-glow upper right + gentle vignette
    g = np.exp(-(((x - 0.78) / 0.35) ** 2 + ((y - 0.05) / 0.45) ** 2))
    c = c + g * np.array([18, 14, 8.])
    v = np.sqrt((x - 0.5) ** 2 + ((y - 0.45) * 1.2) ** 2)
    c = c * (1 - 0.08 * np.clip(v - 0.3, 0, 1))
    c = c + np.random.default_rng(seed).normal(0, 1.4, (h, w, 1))
    return np.clip(c, 0, 255).astype(np.float32)
def clean_alpha(a):
    """a float 0..1 → keep largest blob(s), fill holes in the core, keep soft edges."""
    core = a > 0.5
    lab, n = ndimage.label(core)
    if n > 1:
        sizes = ndimage.sum(core, lab, range(1, n + 1))
        keep = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s > 0.02 * sizes.max()])
    else:
        keep = core
    filled = ndimage.binary_fill_holes(keep)
    inner = ndimage.binary_erosion(filled, iterations=3)
    region = ndimage.binary_dilation(filled, iterations=25)
    out = np.where(region, a, 0)
    out = np.maximum(out, inner.astype(np.float32))
    return out

def despill_gaps(a, src):
    """Zero alpha on bluish/greenish background remnants that RVM kept (arm gaps). src = original frame float RGB."""
    r, g, b = src[..., 0], src[..., 1], src[..., 2]
    lum = 0.299 * r + 0.587 * g + 0.114 * b
    cold = ((g > r + 10) | (b > r + 18)) & (lum > 58) & (lum < 170)      # city remnants (hair: g<=r; shaded white top ~185)
    cold |= (b > r + 8) & (lum >= 232)                                  # bright blue-white sky in arm gaps
    cold = ndimage.binary_opening(cold, iterations=2)
    # only gaps: cold pixels that are not deep inside a big warm region (keep tattoos: they're surrounded by skin and small)
    lab, n = ndimage.label(cold)
    if n:
        sizes = ndimage.sum(cold, lab, range(1, n + 1))
        cold = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s > 400])
    soft = ndimage.gaussian_filter(cold.astype(np.float32), 1.5)
    return a * (1 - np.clip(soft * 1.6, 0, 1))


def kill_bright_hair_gaps(a, src, band=170):
    """Near the head top, bright neutral pixels (window frame / glare seen through flyaway hair) are background."""
    rows = np.where(a.max(1) > 0.5)[0]
    if not len(rows): return a
    top = max(0, rows[0] - 70)
    y1 = min(a.shape[0], rows[0] + band)
    r, g, b = src[top:y1, :, 0], src[top:y1, :, 1], src[top:y1, :, 2]
    mx = np.maximum(np.maximum(r, g), b); mn = np.minimum(np.minimum(r, g), b)
    sat = (mx - mn) / (mx + 1e-3)
    lum = 0.299 * r + 0.587 * g + 0.114 * b
    bright = (lum > 185) & (sat < 0.2)
    soft = ndimage.gaussian_filter(bright.astype(np.float32), 1.2)
    out = a.copy()
    out[top:y1] = a[top:y1] * (1 - np.clip(soft * 1.5, 0, 0.95))
    return out
