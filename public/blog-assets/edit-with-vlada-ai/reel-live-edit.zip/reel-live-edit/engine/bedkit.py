"""bedkit — code-synth music beds + a small style SFX kit for the reel edits (numpy + scipy only, no samples).

usage:
  python bedkit.py bed <preset> <seconds> <out.wav>    one bed, any length (build.py calls this and caches the result)
  python bedkit.py sfx [name ...] [--out dir]          → <dir or engine/sfx>/<name>.wav (build.py synthesises on demand)
  python bedkit.py list
Beds: 48 kHz stereo float32 continuous music of the requested length (build.py fades the end itself),
mastered like lofi.wav (≈ −14 LUFS, true peak ≤ −2 dBTP). Energy sits in ~80 Hz–3 kHz, nothing harsh above 7 kHz,
every note has a smooth attack/release (no clicks), only a short fade-in at the top. lofi.wav comes from engine/lofi.py.
SFX: 48 kHz mono float32, the sound starts at sample 0, peak −3 dBFS, short tails.
Deterministic: every preset / sound has a fixed seed.
"""
import os, sys, json, re, subprocess, time
import numpy as np
from scipy.signal import butter, sosfilt, lfilter, fftconvolve, resample_poly
from scipy.io import wavfile

SR = 48000
DUR = 31.5
TAU = 2 * np.pi
HERE = os.path.dirname(os.path.abspath(__file__))
BEDS_DIR, SFX_DIR = os.path.join(HERE, 'beds'), os.path.join(HERE, 'sfx')
QA_DIR = os.path.join(BEDS_DIR, 'qa')
sys.path.insert(0, HERE)
from common import FF


# ═══════════════════════════════ DSP basics ═══════════════════════════════
def _sos(kind, f, o):
    return butter(o, f, btype=kind, fs=SR, output='sos')


def lp(x, f, o=2):
    return sosfilt(_sos('low', f, o), x, axis=0)


def hp(x, f, o=2):
    return sosfilt(_sos('high', f, o), x, axis=0)


def bp(x, lo, hi, o=2):
    return sosfilt(_sos('band', [lo, hi], o), x, axis=0)


def _biquad(x, b, a):
    return sosfilt(np.array([[b[0] / a[0], b[1] / a[0], b[2] / a[0], 1.0, a[1] / a[0], a[2] / a[0]]]), x, axis=0)


def peq(x, f0, db, q=1.0):
    """RBJ peaking EQ."""
    A, w = 10 ** (db / 40), TAU * f0 / SR
    al, c = np.sin(w) / (2 * q), np.cos(w)
    return _biquad(x, [1 + al * A, -2 * c, 1 - al * A], [1 + al / A, -2 * c, 1 - al / A])


def rlp(x, f0, q=0.707):
    """RBJ resonant low-pass."""
    w = TAU * f0 / SR
    al, c = np.sin(w) / (2 * q), np.cos(w)
    return _biquad(x, [(1 - c) / 2, 1 - c, (1 - c) / 2], [1 + al, -2 * c, 1 - al])


def mtof(m):
    return 440.0 * 2.0 ** ((np.asarray(m, dtype=float) - 69) / 12)


def cents(c):
    return 2.0 ** (np.asarray(c, dtype=float) / 1200)


def secs(n):
    return np.arange(n) / SR


def rcos(u):
    """Raised-cosine ramp 0→1 over u ∈ [0, 1] (clipped outside)."""
    return 0.5 - 0.5 * np.cos(np.pi * np.clip(u, 0, 1))


def env(n, att=0.004, dec=None, sus=0.0, gate=None, rel=0.05):
    """Click-free note envelope: raised-cosine attack (att s), optional exponential decay (time constant dec s)
    toward `sus`, and from `gate` s a raised-cosine release of `rel` s down to exactly zero."""
    t = secs(n)
    e = rcos(t / att) if att > 0 else np.ones(n)
    if dec:
        e = e * (sus + (1 - sus) * np.exp(-np.maximum(t - att, 0) / dec))
    if gate is not None:
        e = e * (1 - rcos((t - gate) / max(rel, 1e-4)))
    return e


def fade(x, a=0.0, r=0.004):
    """Copy of x with a raised-cosine fade-in of a s and fade-out of r s (mono or stereo)."""
    x = np.array(x, dtype=float, copy=True)
    ka, kr = int(a * SR), int(r * SR)
    if ka > 1:
        x[:ka] = (x[:ka].T * rcos(np.arange(ka) / (ka - 1))).T
    if kr > 1:
        x[-kr:] = (x[-kr:].T * rcos(np.arange(kr) / (kr - 1))[::-1]).T
    return x


def sat(x, d=1.5):
    return np.tanh(d * x) / np.tanh(d)


# ═══════════════════════════════ oscillators ═══════════════════════════════
def phase(f, n, ph0=0.0):
    """Running phase (cycles) of a constant or per-sample frequency (Hz)."""
    if np.ndim(f) == 0:
        return ph0 + f * np.arange(n) / SR
    f = np.asarray(f, dtype=float)[:n]
    return ph0 + np.concatenate(([0.0], np.cumsum(f[:-1]))) / SR


def _blep(p, dt):
    r = np.zeros_like(p)
    dt = np.broadcast_to(dt, p.shape)
    m = p < dt
    u = p[m] / dt[m]
    r[m] = u + u - u * u - 1
    m = p > 1 - dt
    u = (p[m] - 1) / dt[m]
    r[m] = u * u + u + u + 1
    return r


def saw(f, n, ph0=0.0):
    """PolyBLEP sawtooth in −1..1 (cheap, for long pads that get low-passed anyway)."""
    p = phase(f, n, ph0) % 1.0
    dt = (np.asarray(f, dtype=float)[:n] if np.ndim(f) else f) / SR
    return 2 * p - 1 - _blep(p, dt)


WAVES = {
    'sine': lambda k: 1.0 if k == 1 else 0.0,
    'saw': lambda k: 1.0 / k,
    'square': lambda k: (k % 2) / k,
    'tri': lambda k: (k % 2) * (-1.0) ** ((k - 1) // 2) / (k * k),
    'sqsaw': lambda k: (1.0 if k % 2 else 0.45) / k,          # square/saw blend (Y2K stabs)
}


def pulse_amps(duty):
    """Harmonic amplitudes of a pulse wave with the given duty cycle (NES: 0.125 / 0.25 / 0.5)."""
    return lambda k: np.sin(np.pi * k * duty) / k


def harm(f, n, amps='saw', dec=0.0, kdec=0.0, flim=7000.0, fc=None, order=2, ph0=0.0, kmax=64):
    """Band-limited additive tone Σ a_k·sin(k·φ). Harmonic k decays at dec + kdec·(k−1) 1/s (a pluck whose filter
    closes), an optional virtual low-pass (cutoff fc: scalar or per-sample array) shapes the spectrum, and the top
    quarter below `flim` is tapered, so nothing aliases or pops in when the pitch moves. f: Hz, scalar or array."""
    a_of = WAVES[amps] if isinstance(amps, str) else amps
    fm, fmean = float(np.max(f)), float(np.mean(f))
    K = int(min(kmax, max(1, flim // fm)))
    t = secs(n)
    z1 = np.exp(1j * TAU * phase(f, n, ph0))
    z = z1.copy()
    e = np.exp(-t * dec) if (dec or kdec) else None
    E = np.exp(-t * kdec) if kdec else None
    fcm = None if fc is None else float(np.max(fc))
    out = np.zeros(n)
    for k in range(1, K + 1):
        if fc is not None and k * fmean > 14 * fcm:
            break
        a = a_of(k) * min(1.0, (flim - k * fm) / (0.25 * flim))
        if a != 0:
            term = a * z.imag
            if e is not None:
                term *= e
            if fc is not None:
                term /= np.sqrt(1 + (k * fmean / fc) ** (2 * order))
            out += term
        if E is not None:
            e = e * E
        z *= z1
    return out


def partials(n, f, ratios, amps, decays, flim=7000.0, ph=None):
    """Inharmonic additive (bars, bells, glass): Σ a_i·e^(−d_i·t)·sin(2π·f·r_i·t); partials ≥ flim are dropped."""
    t = secs(n)
    out = np.zeros(n)
    for i, (r, a, d) in enumerate(zip(ratios, amps, decays)):
        if f * r < flim:
            out += a * np.exp(-d * t) * np.sin(TAU * f * r * t + (0.0 if ph is None else ph[i]))
    return out


# ═══════════════════════════════ mixing + effects ═══════════════════════════════
def bus(seconds=None):
    if seconds is None:
        seconds = DUR + 3.0
    return np.zeros((int(seconds * SR), 2))


def put(b, x, at, gain=1.0, pan=0.0):
    """Mix mono x (constant-power pan, unity at centre) or stereo x into bus b at `at` seconds."""
    if x.ndim == 1:
        th = (np.clip(pan, -1, 1) + 1) * np.pi / 4
        x = np.stack([x * np.cos(th), x * np.sin(th)], 1) * np.sqrt(2)
    i = int(round(at * SR))
    if i < 0:
        x, i = x[-i:], 0
    e = min(len(b), i + len(x))
    if e > i:
        b[i:e] += gain * x[:e - i]


def reverb_ir(rt60=1.8, pre=0.012, lo=180.0, hi=5000.0, damp=2.2, seed=0, length=None):
    """Stereo IR: decorrelated decaying noise, highs die `damp`× faster, soft onset, band-limited, unit energy."""
    n = int((length or min(rt60 * 1.15, 6.0)) * SR)
    t = secs(n)[:, None]
    w = np.random.default_rng(1000 + seed).standard_normal((n, 2))
    low = lp(w, 1100)
    ir = low * 10 ** (-3 * t / rt60) + (w - low) * 10 ** (-3 * damp * t / rt60)
    ir = bp(ir * (1 - np.exp(-t / 0.006)), lo, hi)
    ir /= np.sqrt((ir ** 2).sum(0))
    return np.concatenate([np.zeros((int(pre * SR), 2)), ir])


def reverb(x, ir):
    if x.ndim == 1:
        x = np.stack([x, x], 1)
    return np.stack([fftconvolve(x[:, c], ir[:, c])[:len(x)] for c in range(2)], 1)


def echo(x, dt, fb=0.35, taps=6, pingpong=True, lo=250.0, hi=3500.0):
    """Feedback delay as a tap series (each repeat darker); ping-pong leans repeats left/right."""
    m = x.mean(1) if x.ndim == 2 else x
    n, d = len(m), int(round(dt * SR))
    out = np.zeros((n, 2))
    y = bp(m, lo, hi)
    for k in range(1, taps + 1):
        if k * d >= n:
            break
        g = fb ** (k - 1)
        if pingpong:
            c = (k - 1) % 2
            out[k * d:, c] += 0.85 * g * y[:n - k * d]
            out[k * d:, 1 - c] += 0.25 * g * y[:n - k * d]
        else:
            out[k * d:] += g * y[:n - k * d, None]
        y = lp(y, hi * 0.85)
    return out


def mod_delay(x, base_ms, depth_ms, rate, ph=0.0):
    n = len(x)
    idx = np.arange(n, dtype=float)
    d = (base_ms + depth_ms * np.sin(TAU * rate * idx / SR + ph)) * SR / 1000
    return np.interp(idx - d, idx, x, left=0.0)


def chorus(x, mix=0.5, base=13.0, depth=3.0, rate=0.5):
    """Stereo chorus: two modulated delay taps in quadrature."""
    st = np.stack([x, x], 1) if x.ndim == 1 else x
    m = st.mean(1)
    wet = np.stack([mod_delay(m, base, depth, rate, 0.0), mod_delay(m, base * 1.15, depth, rate * 1.09, np.pi / 2)], 1)
    return st * (1 - 0.5 * mix) + wet * mix


def wow(st, wow_c=10.0, wow_hz=0.42, flut_c=3.0, flut_hz=6.3, seed=0):
    """Tape wow & flutter: time-varying read position (pitch wobble in cents), identical on both channels."""
    rng = np.random.default_rng(2000 + seed)
    n = len(st)
    t = secs(n)
    dev = (wow_c * np.sin(TAU * wow_hz * t + rng.uniform(0, TAU))
           + 0.6 * wow_c * np.sin(TAU * wow_hz * 0.43 * t + rng.uniform(0, TAU))
           + flut_c * np.sin(TAU * flut_hz * t + rng.uniform(0, TAU)))
    r = cents(dev)
    pos = np.cumsum(r) - r[0]
    idx = np.arange(n, dtype=float)
    return np.stack([np.interp(pos, idx, st[:, c], left=0.0, right=0.0) for c in range(st.shape[1])], 1)


def crush(x, bits=7, hold=4):
    """Sample-rate reduction (hold every `hold` samples, deliberately no anti-alias: the crunch) + `bits` quantising."""
    pk = np.max(np.abs(x)) + 1e-12
    y = x[(np.arange(len(x)) // hold) * hold]
    q = 2 ** (bits - 1)
    return np.round(y / pk * q) / q * pk


def stutter(b, t0, length, slice_s, g_end=0.6, f_ms=1.5):
    """Deterministic glitch: replace b[t0:t0+length] with repeats of its first `slice_s` seconds (each repeat faded
    in/out), and fade the original around the region so nothing jumps."""
    i0, L, S, k = int(t0 * SR), int(length * SR), int(slice_s * SR), int(f_ms / 1000 * SR)
    seg = fade(b[i0:i0 + S], f_ms / 1000, f_ms / 1000)
    reps = max(1, L // S)
    b[i0 - k:i0] = (b[i0 - k:i0].T * rcos(np.arange(k) / (k - 1))[::-1]).T
    for r in range(reps):
        b[i0 + r * S:i0 + (r + 1) * S] = seg * (1 + (g_end - 1) * r / max(1, reps - 1))
    j = i0 + reps * S
    b[j:j + k] = (b[j:j + k].T * rcos(np.arange(k) / (k - 1))).T


# ═══════════════════════════════ loudness + output ═══════════════════════════════
_K1 = ([1.53512485958697, -2.69169618940638, 1.19839281085285], [1.0, -1.69065929318241, 0.73248077421585])
_K2 = ([1.0, -2.0, 1.0], [1.0, -1.99004745483398, 0.99007225036621])


def lufs(x):
    """BS.1770-4 integrated loudness at 48 kHz (gated)."""
    x = x[:, None] if x.ndim == 1 else x
    y = lfilter(*_K2, lfilter(*_K1, x, axis=0), axis=0)
    p = np.concatenate(([0.0], np.cumsum((y ** 2).sum(1))))
    blk, hop = int(0.4 * SR), int(0.1 * SR)
    s = np.arange(0, len(y) - blk + 1, hop)
    if not len(s):
        return -99.0
    ms = (p[s + blk] - p[s]) / blk
    lk = -0.691 + 10 * np.log10(ms + 1e-30)
    g = ms[lk > -70]
    if not len(g):
        return -99.0
    g = ms[(lk > -70) & (lk > -0.691 + 10 * np.log10(g.mean()) - 10)]
    return float(-0.691 + 10 * np.log10(g.mean()))


def true_peak_db(x):
    return float(20 * np.log10(np.max(np.abs(resample_poly(x, 4, 1, axis=0))) + 1e-12))


def write(path, x):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wavfile.write(path, SR, np.ascontiguousarray(x, dtype=np.float32))


def master_bed(st, name, target=-14.0, tp=-2.0, fade_in=0.2, lp_hz=None, out=None):
    """High-pass 28 Hz (+ optional low-pass), cut to exactly DUR, de-DC, short fade-in, tiny anti-click fade-out,
    normalise to `target` LUFS with true peak ≤ `tp` dBTP, write beds/<name>.wav."""
    st = hp(st, 28.0, 2)
    if lp_hz:
        st = lp(st, lp_hz, 2)
    st = st[:int(round(DUR * SR))]
    st = fade(st - st.mean(0), fade_in, 0.012)
    st *= 10 ** ((target - lufs(st)) / 20)
    pk = true_peak_db(st)
    if pk > tp:
        st *= 10 ** ((tp - pk) / 20)
    write(out or os.path.join(BEDS_DIR, name + '.wav'), st)
    return st


def stems_report(name, **stems):
    """Print each stem's RMS (dB, full length) so the balance can be checked without ears."""
    rms = {k: 20 * np.log10(np.sqrt(np.mean(np.asarray(v) ** 2)) + 1e-12) for k, v in stems.items()}
    top = max(rms.values())
    print(f'  {name} stems (dB rel. loudest): ' + '  '.join(f'{k} {v - top:+.1f}' for k, v in rms.items()), flush=True)


# ═══════════════════════════════ drums ═══════════════════════════════
# Noise sources are always enveloped first and band-limited after, so no envelope edge can splatter into the highs.
def kick(rng, f_hi=110.0, f_lo=48.0, pdec=30.0, adec=9.0, beater=0.06, length=0.45):
    """Soft sine kick: pitch falls f_hi→f_lo, 1.5 ms attack, a low-passed beater puff instead of a click."""
    n = int(length * SR)
    t = secs(n)
    f = f_lo + (f_hi - f_lo) * np.exp(-t * pdec)
    x = np.sin(TAU * phase(f, n)) * np.exp(-t * adec)
    if beater:
        x += lp(rng.standard_normal(n) * np.exp(-t * 110) * rcos(t / 0.001), 900) * beater
    return x * env(n, 0.0015, gate=length - 0.03, rel=0.03)


def snare(rng, tone=185.0, tdec=26.0, ndec=20.0, lo=900.0, hi=5200.0, body=0.55, noise=0.55, length=0.38):
    n = int(length * SR)
    t = secs(n)
    b = (np.sin(TAU * phase(tone * (1 + 0.25 * np.exp(-t * 60)), n)) + 0.45 * np.sin(TAU * tone * 1.74 * t)) * np.exp(-t * tdec)
    z = bp(rng.standard_normal(n) * np.exp(-t * ndec) * rcos(t / 0.0012), lo, hi)
    return (body * b + noise * z) * env(n, 0.0012, gate=length - 0.03, rel=0.03)


def hat(rng, dec=65.0, lo=4800.0, hi=7200.0, length=0.08, att=0.0006):
    n = int(length * SR)
    t = secs(n)
    return bp(rng.standard_normal(n) * np.exp(-t * dec) * rcos(t / att), lo, hi) * env(n, 0, gate=length - 0.012, rel=0.012)


def rim(rng, f=1700.0, dec=75.0, body=480.0, nz=0.2, length=0.08):
    n = int(length * SR)
    t = secs(n)
    x = np.sin(TAU * f * t) * np.exp(-t * dec) + 0.6 * np.sin(TAU * body * t) * np.exp(-t * dec * 0.7)
    x += nz * bp(rng.standard_normal(n) * np.exp(-t * 140) * rcos(t / 0.0005), 1500, 5000)
    return x * env(n, 0.0006, gate=length - 0.012, rel=0.012)


def clap(rng, lo=850.0, hi=3600.0, tail=17.0, length=0.32, spread=(0.0, 0.0085, 0.0175, 0.026)):
    n = int(length * SR)
    t = secs(n)
    e = np.zeros(n)
    for i, s0 in enumerate(spread):
        u = t - s0
        last = i == len(spread) - 1
        e += np.where(u > 0, rcos(u / 0.0007) * np.exp(-np.maximum(u, 0) * (tail if last else 260.0)), 0.0) * (1.0 if last else 0.75)
    return bp(rng.standard_normal(n) * e, lo, hi) * env(n, 0, gate=length - 0.02, rel=0.02)


def snap(rng, length=0.11):
    """Finger snap: a band-limited crack plus a small skin pop."""
    n = int(length * SR)
    t = secs(n)
    crack = bp(rng.standard_normal(n) * np.exp(-t * 150) * rcos(t / 0.0005), 1700, 5200)
    pop = np.sin(TAU * 1250 * t) * np.exp(-t * 95) * rcos(t / 0.0008) * 0.3
    return (crack + pop) * env(n, 0, gate=length - 0.012, rel=0.012)


def shaker(rng, length=0.11, dec=40.0, att=0.010, lo=3000.0, hi=6600.0):
    n = int(length * SR)
    t = secs(n)
    x = bp(rng.standard_normal(n) * rcos(t / att) * np.exp(-np.maximum(t - att, 0) * dec), lo, hi)
    return x * env(n, 0, gate=length - 0.015, rel=0.015)


def chip_noise(rng, n, rate):
    """NES-ish noise channel: random ±1 held at `rate` Hz (filtered afterwards)."""
    v = rng.choice([-1.0, 1.0], int(n * rate / SR) + 2)
    return v[(np.arange(n) * rate / SR).astype(int)]


def chip_kick(rng):
    n = int(0.16 * SR)
    t = secs(n)
    x = harm(55 + 150 * np.exp(-t * 45), n, 'tri', flim=3000) * np.exp(-t * 18)
    x += lp(chip_noise(rng, n, 2200) * np.exp(-t * 90) * rcos(t / 0.001), 2500) * 0.25
    return x * env(n, 0.001, gate=0.14, rel=0.02)


def chip_snare(rng):
    n = int(0.2 * SR)
    t = secs(n)
    x = lp(chip_noise(rng, n, 9000) * np.exp(-t * 24) * rcos(t / 0.001), 5500)
    x += harm(210 * (1 + 0.6 * np.exp(-t * 50)), n, 'tri', flim=3000) * np.exp(-t * 35) * 0.4
    return x * env(n, 0.001, gate=0.18, rel=0.02)


def chip_hat(rng, dec=70.0):
    n = int(0.06 * SR)
    t = secs(n)
    return bp(chip_noise(rng, n, 40000) * np.exp(-t * dec) * rcos(t / 0.0005), 3500, 6200) * env(n, 0, gate=0.048, rel=0.012)


def gated_snare(rng, hold=0.17, close=0.09):
    """80s gated-reverb snare (stereo): dense short room, cut by a smooth gate at ~0.26 s."""
    s = snare(rng, tone=190, tdec=22, ndec=16, lo=800, hi=5500, body=0.5, noise=0.6, length=0.5)
    n = int(0.6 * SR)
    x = np.zeros(n)
    x[:len(s)] = s
    wet = reverb(x, reverb_ir(1.4, pre=0.004, lo=250, hi=6000, damp=1.6, seed=7))
    gate = 1 - rcos((secs(n) - hold) / close)
    return 0.55 * np.stack([x, x], 1) + 0.9 * wet * gate[:, None]


# ═══════════════════════════════ tonal voices ═══════════════════════════════
def ep(midi, dur, vel, rng, bright=1.0, rel=0.35, trem=0.10, ping=0.10):
    """Rhodes-ish tine (from engine/lofi.py) with a brightness control."""
    f = float(mtof(midi)) * (1 + rng.uniform(-0.0012, 0.0012))
    n = int((dur + rel + 0.02) * SR)
    t = secs(n)
    x = np.zeros(n)
    for k, a in enumerate((1.0, 0.42, 0.16, 0.08, 0.04), start=1):
        if f * k < 7000:
            x += a * (bright if k > 1 else 1.0) * np.exp(-t * (0.9 + 0.7 * k)) * np.sin(TAU * f * k * t + rng.uniform(0, TAU))
    if f * 7.02 < 6500:
        x += ping * bright * np.exp(-t * 22) * np.sin(TAU * f * 7.02 * t)
    return x * (1 + trem * np.sin(TAU * 4.6 * t)) * env(n, 0.006, gate=dur, rel=rel) * vel


def bell(midi, vel, length=2.4, ratios=(1.0, 2.0, 2.76, 5.40, 8.93), amps=(1.0, 0.08, 0.20, 0.07, 0.025),
         decays=(1.2, 2.4, 4.5, 9.0, 16.0), att=0.002, flim=6500.0):
    """Celesta / glockenspiel-like struck bar (free-bar partials), soft 2 ms attack."""
    n = int(length * SR)
    return partials(n, float(mtof(midi)), ratios, amps, decays, flim) * env(n, att, gate=length - 0.06, rel=0.06) * vel


def marimba(midi, vel, rng, length=0.9, att=0.0015):
    """Tuned bar: 1 : 4 : 10 partials, upper ones die fast, a felt-mallet puff (low-passed)."""
    f = float(mtof(midi))
    n = int(length * SR)
    t = secs(n)
    d0 = 2.4 + f / 240.0
    x = partials(n, f, (1.0, 3.98, 9.85), (1.0, 0.20 * vel + 0.05, 0.05 * vel), (d0, 3.5 * d0 + 6, 45.0), 6500)
    x += lp(rng.standard_normal(n) * np.exp(-t * 420) * rcos(t / 0.0004), 1600) * 0.05 * vel
    return x * env(n, att, gate=length - 0.06, rel=0.06) * vel


def kalimba(midi, vel, length=1.1):
    """Thumb-piano tine: fundamental + inharmonic tine partial (~5.9×) that dies quickly."""
    f = float(mtof(midi))
    n = int(length * SR)
    d0 = 2.0 + f / 420.0
    x = partials(n, f, (1.0, 2.0, 5.93, 8.7), (1.0, 0.05, 0.16 * vel + 0.04, 0.04), (d0, 2 * d0, 12.0, 24.0), 6500)
    return x * env(n, 0.0012, gate=length - 0.06, rel=0.06) * vel


def pluck(midi, dur, vel, amps='saw', dec=6.0, kdec=1.5, flim=5500.0, att=0.003, rel=0.08, ph0=0.0, detune=0.0):
    """Additive synth pluck (harmonics decay faster the higher they are)."""
    f = float(mtof(midi)) * float(cents(detune))
    n = int((dur + rel + 0.01) * SR)
    return harm(f, n, amps, dec=dec, kdec=kdec, flim=flim, ph0=ph0) * env(n, att, gate=dur, rel=rel) * vel


def round_bass(midi, dur, vel, h2=0.18, att=0.012, dec=1.1, drive=1.4, rel=0.10):
    """lofi.py's round bass: sine + a little 2nd harmonic, gently saturated."""
    f = float(mtof(midi))
    n = int((dur + rel + 0.01) * SR)
    t = secs(n)
    x = np.sin(TAU * f * t) + h2 * np.sin(2 * TAU * f * t)
    return np.tanh(drive * x * env(n, att, gate=dur, rel=rel) * np.exp(-t * dec)) * vel / np.tanh(drive)


def synth_bass(midi, dur, vel, fc=900.0):
    """Analog-ish bass: saw through a plucky virtual low-pass + sine body."""
    f = float(mtof(midi))
    rel = 0.04
    n = int((dur + rel + 0.01) * SR)
    t = secs(n)
    x = harm(f, n, 'saw', fc=fc * (0.6 + 0.4 * np.exp(-t / 0.08)), flim=4000) + 0.5 * np.sin(TAU * f * t)
    return x * env(n, 0.003, dec=0.25, sus=0.65, gate=dur, rel=rel) * vel


def pizz(midi, vel, length=0.45):
    """Pizzicato-ish plucked bass: round, quick decay."""
    n = int(length * SR)
    x = harm(float(mtof(midi)), n, lambda k: 1.0 / k ** 1.4, dec=6.5, kdec=5.0, flim=3500)
    return x * env(n, 0.003, gate=length - 0.05, rel=0.05) * vel


def upright(midi, dur, vel, rng):
    """Upright-ish bass: warm harmonics that die fast + a soft finger thump."""
    rel = 0.08
    n = int((dur + rel + 0.01) * SR)
    t = secs(n)
    amps = (1.0, 0.45, 0.18, 0.09, 0.05, 0.03)
    x = harm(float(mtof(midi)), n, lambda k: amps[k - 1] if k <= 6 else 0.0, dec=2.2, kdec=4.0, flim=2500)
    x += lp(rng.standard_normal(n) * np.exp(-t * 160) * rcos(t / 0.001), 500) * 0.12
    return sat(1.0 * x, 1.3) * env(n, 0.004, gate=dur, rel=rel) * vel


def slap(midi, dur, vel, pop=False):
    """Synth slap bass: thumb (round, fast-closing brightness) or pop (brighter, snappier)."""
    rel = 0.05
    n = int((dur + rel + 0.01) * SR)
    if pop:
        x = harm(float(mtof(midi)), n, lambda k: 1.0 / k ** 0.8, dec=6.0, kdec=6.0, flim=4500)
    else:
        x = harm(float(mtof(midi)), n, lambda k: 1.0 / k ** 1.15, dec=4.5, kdec=3.5, flim=3200)
    return sat(x, 1.5) * env(n, 0.0025, gate=dur, rel=rel) * vel


def clav(midi, dur, vel, pick=0.13):
    """Clavinet-ish muted stab: pickup comb (|sin πk·pick|) + fast-decaying highs."""
    rel = 0.03
    n = int((dur + rel + 0.01) * SR)
    x = harm(float(mtof(midi)), n, lambda k: abs(np.sin(np.pi * k * pick)) / k ** 0.8, dec=10.0, kdec=2.4, flim=5000)
    return x * env(n, 0.0015, gate=dur, rel=rel) * vel


def brass(midi, dur, vel, rng, det=7.0):
    """Brassy synth stab: 3 detuned saws, a filter that blooms open then settles, a 30-cent scoop up."""
    f0 = float(mtof(midi))
    rel = 0.12
    n = int((dur + rel + 0.01) * SR)
    t = secs(n)
    scoop = cents(-30 * np.exp(-t / 0.03))
    fc = 650 + 2400 * (1 - np.exp(-t / 0.02)) * (0.45 + 0.55 * np.exp(-t / 0.16))
    x = sum(harm(f0 * float(cents(c)) * scoop, n, 'saw', fc=fc, flim=6000, ph0=rng.uniform()) for c in (-det, 0.0, det)) / 3
    return x * env(n, 0.010, gate=dur, rel=rel) * vel


def chip(midi, dur, vel, duty=0.25, vib=0.0, dec=0.0, rel=0.015, flim=6000.0):
    """Band-limited NES pulse (additive, so no aliasing hiss); optional delayed vibrato in cents."""
    f0 = float(mtof(midi))
    n = int((dur + rel + 0.005) * SR)
    t = secs(n)
    f = f0 * cents(vib * np.sin(TAU * 5.8 * t) * np.clip((t - 0.11) / 0.08, 0, 1)) if vib else f0
    return harm(f, n, pulse_amps(duty), dec=dec, flim=flim) * env(n, 0.002, gate=dur, rel=rel) * vel


def chip_tri(midi, dur, vel, rel=0.012):
    n = int((dur + rel + 0.005) * SR)
    return harm(float(mtof(midi)), n, 'tri', flim=5000) * env(n, 0.003, gate=dur, rel=rel) * vel


def saw_pad(notes, dur, rng, att=0.3, rel=0.5, det=(-9.0, 4.0), vel=1.0):
    """Stereo detuned-saw chord; each side gets mirrored detunes (width). Low-pass it on the bus."""
    n = int((dur + rel + 0.01) * SR)
    out = np.zeros((n, 2))
    for m in notes:
        f = float(mtof(m))
        for c, sgn in ((0, 1), (1, -1)):
            for d in det:
                out[:, c] += saw(f * float(cents(sgn * d)), n, rng.uniform())
    return out * (env(n, att, gate=dur, rel=rel) * vel / (len(notes) * len(det)))[:, None]


def sine_pad(notes, dur, att=0.5, rel=0.8, vel=1.0, h=(1.0, 0.22, 0.08), det=4.0):
    """Soft sine-ish chord (fundamental + two weak harmonics), two voices a few cents apart, L/R mirrored."""
    n = int((dur + rel + 0.01) * SR)
    out = np.zeros((n, 2))
    for m in notes:
        f = float(mtof(m))
        for c, sgn in ((0, 1), (1, -1)):
            out[:, c] += harm(f * float(cents(sgn * det)), n, lambda k: h[k - 1] if k <= len(h) else 0.0, flim=6000, kmax=len(h))
    return out * (env(n, att, gate=dur, rel=rel) * vel / len(notes))[:, None]


def mono_line(notes, n, glide=0.03, att=0.01, rel=0.06):
    """notes [(t_on, dur, midi, vel)] → per-sample (freq, amp) for a gliding monophonic voice."""
    target = np.full(n, np.nan)
    amp = np.zeros(n)
    for t0, d, m, v in notes:
        i0 = int(t0 * SR)
        k = min(n, i0 + int((d + rel) * SR) + 1) - i0
        if k <= 0:
            continue
        target[i0:i0 + k] = m
        amp[i0:i0 + k] = np.maximum(amp[i0:i0 + k], env(k, att, gate=d, rel=rel) * v)
    ok = ~np.isnan(target)
    idx = np.where(ok, np.arange(n), 0)
    np.maximum.accumulate(idx, out=idx)
    mid = target[idx]
    mid[np.isnan(mid)] = target[ok][0]
    a = np.exp(-1.0 / (glide * SR))
    mid = lfilter([1 - a], [1, -a], mid, zi=[mid[0] * a])[0]
    return mtof(mid), amp


def mono_synth(notes, n, h=(1.0, 0.12), glide=0.03, att=0.01, rel=0.06):
    f, a = mono_line(notes, n, glide, att, rel)
    return harm(f, n, lambda k: h[k - 1] if k <= len(h) else 0.0, flim=4000, kmax=len(h)) * a


class Grid:
    """16th-note grid with swing (0.5 = straight) applied to the off 16ths."""

    def __init__(self, bpm, swing=0.5):
        self.beat = 60.0 / bpm
        self.step, self.bar, self.swing = self.beat / 4, 4 * self.beat, swing
        self.bars = int(np.ceil((DUR + 1.0) / self.bar))

    def t(self, bar, step):
        j, r = divmod(float(step), 2.0)
        off = r * 2 * self.swing if r <= 1 else 2 * self.swing + (r - 1) * 2 * (1 - self.swing)
        return bar * self.bar + (2 * j + off) * self.step


def norm(x, pk=1.0):
    return x * (pk / (np.max(np.abs(x)) + 1e-12))


# ═══════════════════════════════ beds ═══════════════════════════════
MIN_PLUCK = lambda k: (1.0, 0.25, 0.12, 0.06, 0.035, 0.02)[k - 1] if k <= 6 else 0.0


def bed_minimal(rng):
    """Swiss / Bauhaus / kinetic type — 120 BPM, A minor. An E5-pedal ostinato of soft triangle plucks over a moving
    low voice (Am(add9) – Fmaj7 – C(add9) – G6) with a dotted-8th echo, a short clean sub on a 3-3-2, soft kick on 1 & 3,
    very quiet 16th hats, a tiny rim on 2 & 4 and a faint sine pad. From bar 5 a high answer note joins."""
    G = Grid(120)
    keys, bass, drums, pad = bus(), bus(), bus(), bus()
    figs = [[69, 76, 72, 76, 69, 76, 71, 76], [65, 76, 72, 76, 65, 76, 69, 76],
            [67, 76, 72, 76, 67, 76, 74, 76], [67, 76, 74, 76, 67, 76, 71, 76]]
    tops = [81, 81, 79, 83]
    roots = [45, 41, 48, 43]
    pads = [[57, 60, 64, 71], [53, 57, 60, 64], [55, 60, 64, 67], [55, 59, 62, 64]]
    acc = [1.0, 0.72, 0.86, 0.72, 0.95, 0.72, 0.86, 0.78]
    for b in range(G.bars):
        c = b % 4
        for j, m in enumerate(figs[c]):
            put(keys, pluck(m, 0.19, acc[j] * rng.uniform(0.92, 1.0), MIN_PLUCK, dec=4.0, kdec=3.0, flim=5000, rel=0.07),
                G.t(b, 2 * j), pan=0.18 if j % 2 else -0.12)
        if b >= 4:
            put(keys, pluck(tops[c], 0.3, 0.5, MIN_PLUCK, dec=3.0, kdec=3.0, flim=5000), G.t(b, 14), pan=0.3)
        put(pad, sine_pad(pads[c], G.bar, att=0.6, rel=0.9), b * G.bar)
        for s, r in ((0, 0), (3, 0), (6, 0), (8, 0), (11, 0), (14, 7)):
            put(bass, round_bass(roots[c] + r, 0.10, 0.9 if s in (0, 8) else 0.7, h2=0.12, att=0.006, dec=2.0, drive=1.2, rel=0.05), G.t(b, s))
        for s in (0, 8):
            put(drums, kick(rng, 95, 50, 34, 11, 0.04), G.t(b, s), 0.9 if s == 0 else 0.8)
        for s in (4, 12):
            put(drums, rim(rng, 1900, 90, 520, 0.15), G.t(b, s), 0.16, pan=-0.2)
        for s in range(16):
            put(drums, hat(rng, dec=75, lo=4800, hi=7000), G.t(b, s), 0.07 * (1.0, 0.5, 1.7, 0.6)[s % 4], pan=0.25)
    keys = lp(keys, 4500)
    wet = echo(keys, 3 * G.step, fb=0.38, taps=6, lo=300, hi=4000)
    pad = lp(pad, 1500)
    stems_report('minimal', keys=0.5 * keys, echo=0.17 * wet, bass=0.46 * bass, drums=0.68 * drums, pad=0.135 * pad)
    mix = 0.5 * keys + 0.17 * wet + 0.46 * bass + 0.68 * drums + 0.135 * pad
    return mix + 0.08 * reverb(keys + 0.5 * pad + 0.3 * drums, reverb_ir(1.3, seed=1, hi=5000))


def bed_synthwave(rng):
    """Synthwave — 100 BPM, Am – F – C – G. Warm detuned-saw pad (LP 2.5 kHz + chorus), 16th pluck arpeggio with a
    dotted-8th ping-pong, rolling 8th-note octave bass, soft four-on-the-floor kick, soft gated-reverb snare on 2 & 4."""
    G = Grid(100)
    pad, arp, bass, drums = bus(), bus(), bus(), bus()
    chords = [[57, 60, 64, 69], [57, 60, 65, 69], [55, 60, 64, 67], [55, 59, 62, 67]]
    roots = [45, 41, 48, 43]
    arps = [[69, 72, 76, 81, 84, 88], [65, 69, 72, 77, 81, 84], [67, 72, 76, 79, 84, 88], [67, 71, 74, 79, 83, 86]]
    shape = [0, 1, 2, 3, 1, 2, 3, 4, 2, 3, 4, 5, 4, 3, 2, 1]
    sn = gated_snare(rng)
    for b in range(G.bars):
        c = b % 4
        put(pad, saw_pad(chords[c], G.bar, rng, att=0.25, rel=0.45), b * G.bar)
        for s in range(16):
            put(arp, pluck(arps[c][shape[s]], 0.10, (1.0 if s % 4 == 0 else 0.78) * rng.uniform(0.9, 1.0), 'sqsaw',
                           dec=7.0, kdec=1.6, flim=5000), G.t(b, s))
        for j in range(8):
            put(bass, synth_bass(roots[c] + (12 if j % 2 else 0), 0.22, 1.0 if j % 2 == 0 else 0.8), G.t(b, 2 * j))
        for s in (0, 4, 8, 12):
            put(drums, kick(rng, 120, 48, 32, 10, 0.05), G.t(b, s), 0.9)
        for s in (4, 12):
            put(drums, sn, G.t(b, s), 0.5)
        for s in (2, 6, 10, 14):
            put(drums, hat(rng, dec=55), G.t(b, s), 0.12, pan=0.3)
    pad = chorus(lp(hp(pad, 140), 2500, 4), mix=0.45, depth=2.5, rate=0.35)
    arp = lp(arp, 3400)
    wet = echo(arp, 3 * G.step, fb=0.35, lo=300, hi=3500)
    bass, drums = lp(bass, 1800), lp(drums, 7000)
    stems_report('synthwave', pad=1.8 * pad, arp=0.54 * arp, echo=0.3 * wet, bass=0.5 * bass, drums=1.35 * drums)
    mix = 1.8 * pad + 0.54 * arp + 0.3 * wet + 0.5 * bass + 1.35 * drums
    return mix + 0.6 * reverb(1.6 * pad + arp, reverb_ir(2.4, seed=2, hi=5000))


def bed_vaporwave(rng):
    """Vaporwave mall-jazz — 72 BPM, Fmaj9 – Em7 – Dm9 – Cmaj9. Soft Rhodes + airy saw pad, round gliding bass, slow
    muffled kick/snare, long dark reverb, tape wow/flutter on the whole mix, heavy low-pass (~2.7 kHz, 4-pole)."""
    G = Grid(72)
    keys, pad, drums = bus(), bus(), bus()
    chords = [[53, 64, 67, 69, 72], [52, 62, 67, 71, 74], [50, 60, 64, 65, 69], [48, 59, 62, 64, 67]]
    roots = [41, 40, 38, 36]
    notes = []
    for b in range(G.bars):
        c = b % 4
        t0 = b * G.bar
        for j, m in enumerate(chords[c]):
            put(keys, ep(m, 2.6 * G.beat, 0.5 * rng.uniform(0.85, 1.0), rng, bright=0.7, trem=0.14),
                t0 + 0.02 * j + rng.uniform(0, 0.006), pan=-0.3 + 0.15 * j)
        for j, m in enumerate(chords[c][2:]):
            put(keys, ep(m, 1.3 * G.beat, 0.3 * rng.uniform(0.85, 1.0), rng, bright=0.6, trem=0.14),
                t0 + 2 * G.beat + 0.015 * j + 0.01, pan=-0.1 + 0.2 * j)
        if b % 2 == 1:
            put(keys, ep(chords[c][-2] + 12, 0.8 * G.beat, 0.22, rng, bright=0.6), t0 + 3.5 * G.beat + 0.02, pan=0.35)
        put(pad, saw_pad(chords[c][1:], G.bar, rng, att=0.8, rel=1.2, det=(-6.0, 3.0)), t0)
        r = roots[c]
        notes += [(t0, 1.9 * G.beat, r, 1.0), (t0 + 2 * G.beat, 0.9 * G.beat, r + 7, 0.8), (t0 + 3 * G.beat, 0.9 * G.beat, r + 12, 0.7)]
        hits = [(0, 'k'), (1, 's'), (2, 'k'), (3, 's')] + ([(1.5, 'k')] if b % 2 else [])
        for beat, kind in hits:
            if kind == 'k':
                put(drums, kick(rng, 85, 46, 26, 7.5, 0.05), t0 + beat * G.beat, 0.9 if beat == 0 else 0.7)
            else:
                put(drums, snare(rng, tone=175, tdec=20, ndec=12, lo=600, hi=3000), t0 + beat * G.beat + 0.012, 0.6)
        for e in range(8):
            put(drums, hat(rng, dec=50, lo=3000, hi=5000), t0 + e * G.beat / 2, 0.05 if e % 2 else 0.08, pan=0.3)
    b1 = mono_synth(notes, len(keys), h=(1.0, 0.25, 0.08), glide=0.025, att=0.015, rel=0.08)
    bass = np.stack([b1, b1], 1)
    keys = chorus(keys, mix=0.35, base=16, depth=4, rate=0.6)
    pad, drums = lp(pad, 1300), lp(drums, 1800)
    stems_report('vaporwave', keys=0.42 * keys, pad=0.21 * pad, bass=0.12 * bass, drums=0.33 * drums)
    mix = 0.42 * keys + 0.21 * pad + 0.12 * bass + 0.33 * drums
    mix += 0.38 * reverb(0.9 * keys + 0.5 * pad + 0.4 * drums, reverb_ir(3.6, pre=0.03, lo=200, hi=3500, damp=2.5, seed=3))
    mix = wow(mix, 11, 0.38, 3.5, 6.1, seed=3)
    return sat(norm(rlp(rlp(mix, 2700, 0.85), 2700, 0.6), 0.9), 1.3)


CHIP_LEAD = [[(0, 72, 2), (2, 76, 2), (4, 79, 2), (6, 84, 2), (8, 88, 4), (12, 86, 2), (14, 84, 2)],    # C
             [(0, 83, 2), (2, 79, 2), (4, 74, 2), (6, 79, 2), (8, 83, 4), (12, 81, 2), (14, 79, 2)],    # G
             [(0, 81, 2), (2, 76, 2), (4, 72, 2), (6, 76, 2), (8, 81, 4), (12, 83, 2), (14, 84, 2)],    # Am
             [(0, 81, 2), (2, 77, 2), (4, 72, 2), (6, 77, 2), (8, 81, 2), (10, 84, 2), (12, 79, 4)],    # F
             None, None,                                                                                # = bars 1, 2
             [(0, 81, 2), (2, 76, 2), (4, 72, 2), (6, 76, 2), (8, 81, 4), (12, 79, 2), (14, 76, 2)],    # Am
             [(0, 77, 2), (2, 81, 2), (4, 84, 2), (6, 81, 2), (8, 79, 6)]]                              # F (breath)


def bed_chiptune(rng):
    """NES chiptune — 140 BPM, C – G – Am – F. Pulse 1 (25 %) plays an arpeggiated 8-bar lead (NES-style echo the
    second time round), pulse 2 (12.5 %) a quiet 16th chord arpeggio, triangle octave bass, noise-channel drums.
    Pulses are additive / band-limited (no aliasing hiss); everything low-passed ~6 kHz."""
    G = Grid(140)
    lead, arp, tri, drums = bus(), bus(), bus(), bus()
    roots = [48, 43, 45, 41]
    arps = [[64, 67, 72, 67], [59, 62, 67, 62], [60, 64, 69, 64], [57, 60, 65, 60]]
    for b in range(G.bars):
        c, ph = b % 4, b % 8
        for s, m, L in (CHIP_LEAD[ph] or CHIP_LEAD[ph - 4]):
            x = chip(m, L * G.step * 0.82, 1.0, duty=0.25, vib=14 if L >= 4 else 0, dec=1.2)
            put(lead, x, G.t(b, s), pan=-0.05)
            if b >= 8:
                put(lead, x, G.t(b, s) + 3 * G.step, 0.28, pan=0.35)
        for s in range(16):
            put(arp, chip(arps[c][s % 4], G.step * 0.55, 0.9 if s % 4 == 0 else 0.7, duty=0.125, dec=6.0), G.t(b, s), pan=0.2)
        for j in range(8):
            put(tri, chip_tri(roots[c] + (12 if j % 2 else 0), G.step * 1.6, 1.0), G.t(b, 2 * j))
        for s in (0, 8) + ((10,) if b % 2 else ()):
            put(drums, chip_kick(rng), G.t(b, s), 0.9)
        for s in (4, 12):
            put(drums, chip_snare(rng), G.t(b, s), 0.55)
        for s in range(0, 16, 2):
            put(drums, chip_hat(rng), G.t(b, s), 0.10 if s % 4 == 0 else 0.16, pan=-0.2)
    stems_report('chiptune', lead=0.48 * lead, arp=0.45 * arp, tri=0.5 * tri, drums=0.95 * drums)
    mix = 0.48 * lead + 0.45 * arp + 0.5 * tri + 0.95 * drums
    mix += 0.10 * reverb(lead + arp, reverb_ir(0.7, seed=4, hi=5000))
    return lp(mix, 6000, 2)


def glitch_stab(chord, dur, rng, bits=6, hold=4):
    """Bit-crushed chord stab: a bright additive chord, held at 12 kHz with no anti-alias (crunch) and quantised to
    `bits`, THEN enveloped (so the grit dies with the note), blended with a clean low-passed copy, LP 5 kHz."""
    rel = 0.04
    n = int((dur + rel + 0.01) * SR)
    raw = sum(harm(float(mtof(m)), n, lambda k: 1.0 / k ** 1.2, flim=9000, ph0=rng.uniform()) for m in chord) / len(chord)
    e = env(n, 0.002, dec=0.09, sus=0.25, gate=dur, rel=rel)
    return lp((0.6 * crush(raw, bits, hold) + 0.5 * lp(raw, 2500)) * e, 5000)


def micro_click(f, dec, gain):
    """Tiny pitched tick: a damped sine (narrow-band, so it never reads as a broadband click)."""
    T = min(0.25, 7.0 / dec)
    n = int(T * SR)
    t = secs(n)
    return np.sin(TAU * f * t) * np.exp(-t * dec) * rcos(t / 0.0003) * (1 - rcos((t - 0.8 * T) / (0.2 * T))) * gain


def bed_glitch(rng):
    """IDM / glitch-hop — 110 BPM (light swing), Dm9 – Bbmaj9 – Gm9 – A7sus4. Bit-crushed chord stabs on a
    syncopated 2-bar pattern, clicky narrow-band micro-percussion, soft kick/snare+clap, 16th hats with 32nd rolls,
    deterministic stutter repeats at the end of every 4th bar, deep soft gliding sub."""
    G = Grid(110, swing=0.56)
    stab, drums, perc = bus(), bus(), bus()
    chords = [[65, 69, 72, 76], [62, 65, 69, 72], [65, 69, 70, 74], [62, 64, 67, 69]]
    roots = [38, 34, 43, 45]
    pats = [[(0, 2), (3, 1), (7, 2), (10, 1), (12, 2)], [(0, 2), (3, 1), (6, 1), (9, 2), (14, 1)]]
    notes = []
    for b in range(G.bars):
        c = b % 4
        for s, L in pats[b % 2]:
            put(stab, glitch_stab(chords[c], L * G.step * 0.9, rng), G.t(b, s), pan=rng.uniform(-0.3, 0.3))
        r = roots[c]
        notes += [(G.t(b, 0), 7 * G.step, r, 1.0), (G.t(b, 7), 2 * G.step, r, 0.8),
                  (G.t(b, 10), 5 * G.step, r + (7 if b % 2 else 12), 0.85)]
        for s in ((0, 7, 10) if b % 2 == 0 else (0, 10, 13)):
            put(drums, kick(rng, 100, 45, 28, 7, 0.05), G.t(b, s), 1.0 if s == 0 else 0.8)
        for s in (4, 12):
            put(drums, snare(rng, tone=200, tdec=30, ndec=28, lo=1000, hi=5500), G.t(b, s), 0.55)
            put(drums, clap(rng, tail=24), G.t(b, s) + 0.004, 0.25)
        for s in range(16):
            put(drums, hat(rng, dec=95, lo=4500, hi=7000, length=0.05), G.t(b, s), 0.05 + 0.07 * rng.random(), pan=0.3)
        if b % 2:
            for k in range(3):
                put(drums, hat(rng, dec=110, lo=4500, hi=7000, length=0.04), G.t(b, 14) + k * G.step / 2, 0.08, pan=0.3)
        for k in rng.choice([x for x in range(32) if x not in (8, 24)], 6, replace=False):
            put(perc, micro_click(rng.choice([1900.0, 2500.0, 3200.0, 3900.0]), rng.uniform(300, 700), rng.uniform(0.08, 0.2)),
                b * G.bar + k * G.step / 2, pan=rng.uniform(-0.7, 0.7))
        for k in rng.choice([2, 5, 11, 13, 15], 2, replace=False):
            put(perc, micro_click(float(mtof(chords[c][rng.integers(4)] + 12)), 35.0, 0.12), G.t(b, k), pan=rng.uniform(-0.5, 0.5))
    n = len(stab)
    s1 = lp(mono_synth(notes, n, h=(1.0, 0.35), glide=0.04, att=0.012, rel=0.07), 300)
    sub = np.stack([s1, s1], 1)
    stab = lp(stab, 5000)
    gb = 0.72 * stab + 0.45 * drums + 1.0 * perc
    for b in range(3, G.bars, 4):
        stutter(gb, G.t(b, 12), 4 * G.step, G.step / 2, g_end=0.55)
    stutter(gb, G.t(9, 6), 2 * G.step, G.step / 2, g_end=0.7)
    stems_report('glitch', stab=0.72 * stab, drums=0.45 * drums, perc=1.0 * perc, sub=0.2 * sub)
    mix = gb + 0.2 * sub + 0.25 * echo(stab, 3 * G.step, fb=0.3, lo=300, hi=3500)
    return sat(norm(mix + 0.2 * reverb(0.72 * stab + 1.0 * perc, reverb_ir(1.2, seed=5, hi=5000)), 0.9), 1.5)


def bed_ambient(rng):
    """Ambient — slow 75 BPM pulse, D major pentatonic. Evolving warm pads Dmaj9 – Bm9 – Gmaj9 – A6sus2 (6.4 s each,
    long cross-fades, a slow filter swell), a soft celesta arpeggio with ping-pong echo, a quiet shimmer of high
    partials into a long reverb, and a faint felt pulse on beats 1 & 3."""
    G = Grid(75)
    seg = 2 * G.bar
    chords = [[50, 57, 64, 66, 73], [47, 54, 61, 62, 69], [43, 50, 57, 59, 66], [45, 52, 59, 64, 66]]
    pulse_notes = [50, 47, 43, 45]
    pad, bells, shim, pulse = bus(), bus(), bus(), bus()
    for i in range(int(np.ceil((DUR + 1) / seg)) + 1):
        c, t0 = i % 4, i * seg
        lead = 1.6 if i == 0 else 1.0
        put(pad, saw_pad(chords[c], seg, rng, att=2.0, rel=3.0, det=(-6.0, 2.5)), t0 - lead)
        put(pad, sine_pad(chords[c], seg, att=2.0, rel=3.0), t0 - lead, 0.5)
        for m in chords[c][-2:]:
            for mult in (4, 6):
                f = float(mtof(m)) * mult
                if f > 4000:
                    continue
                k = int((seg + 3.2) * SR)
                t = secs(k)
                am = 0.5 - 0.5 * np.cos(TAU * rng.uniform(0.12, 0.3) * t + rng.uniform(0, TAU))
                put(shim, np.sin(TAU * f * t + rng.uniform(0, TAU)) * am * env(k, 1.5, gate=seg, rel=1.5), t0 - lead, 1.0 / mult,
                    pan=rng.uniform(-0.6, 0.6))
    pool = [74, 76, 78, 81, 83, 86, 88]
    mask = [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0]
    pos, e8 = 3, G.beat / 2
    for k in range(int((DUR + 1) / e8)):
        if not mask[k % 16]:
            continue
        pos = int(np.clip(pos + rng.choice([-2, -1, 1, 2], p=[0.15, 0.35, 0.35, 0.15]), 0, len(pool) - 1))
        put(bells, bell(pool[pos], rng.uniform(0.22, 0.42), length=2.6), k * e8 + rng.normal(0, 0.004), pan=rng.uniform(-0.5, 0.5))
    for k in range(int((DUR + 1) / (2 * G.beat))):
        t0 = k * 2 * G.beat
        put(pulse, round_bass(pulse_notes[int(t0 // seg) % 4], 0.25, 0.8 if k % 2 == 0 else 0.6, h2=0.1, att=0.03, dec=3.0,
                              drive=1.0, rel=0.2), t0)
    n = len(pad)
    m = (0.5 - 0.5 * np.cos(TAU * secs(n) / 13.0))[:, None]
    pad = hp(lp(pad, 900, 4) * (1 - m) + lp(pad, 2400, 4) * m, 70)
    pulse = lp(pulse, 500)
    wet = echo(bells, 0.6, fb=0.42, lo=400, hi=4000)
    stems_report('ambient', pad=1.0 * pad, bells=0.67 * bells, echo=0.34 * wet, shim=0.125 * shim, pulse=0.35 * pulse)
    mix = 1.0 * pad + 0.67 * bells + 0.34 * wet + 0.125 * shim + 0.35 * pulse
    return mix + 0.45 * reverb(0.5 * pad + 0.67 * bells + 0.25 * shim, reverb_ir(4.2, pre=0.04, lo=200, hi=5000, damp=2.0, seed=6, length=5.0))


def bed_playful(rng):
    """Clay 3D / flat 2D / Memphis / isometric — 104 BPM (light swing), F – C – Dm – Bb (I–V–vi–IV). Bouncy marimba
    figure, a kalimba sparkle line, pizzicato bass, finger snaps on 2 & 4, light 16th shaker, soft felt kick."""
    G = Grid(104, swing=0.55)
    mar, kal, bass, drums = bus(), bus(), bus(), bus()
    chords = [[65, 69, 72, 77], [64, 67, 72, 76], [65, 69, 74, 77], [65, 70, 74, 77]]
    roots = [41, 48, 50, 46]
    mpat = [(0, 0), (3, 2), (6, 1), (8, 3), (10, 2), (12, 1), (14, 2)]
    kline = [[(2, 81), (7, 84), (11, 86)], [(2, 84), (6, 79), (10, 81), (14, 79)],
             [(2, 81), (7, 86), (11, 84)], [(2, 86), (6, 82), (10, 81), (14, 79)]]
    for b in range(G.bars):
        c = b % 4
        for s, i in mpat:
            put(mar, marimba(chords[c][i], (1.0 if s in (0, 8) else 0.75) * rng.uniform(0.9, 1.0), rng), G.t(b, s), pan=-0.25 + 0.15 * i)
        put(mar, marimba(chords[c][2], 0.6, rng), G.t(b, 0) + 0.012, pan=0.1)
        if b >= 1:
            for s, m in kline[c]:
                put(kal, kalimba(m, 0.5 * rng.uniform(0.85, 1.0)), G.t(b, s), pan=0.35)
        for s, r, v in ((0, 0, 0.9), (6, 0, 0.6), (8, 7, 0.85), (14, 12, 0.6)):
            put(bass, pizz(roots[c] + r, v), G.t(b, s))
        for s in ((0, 8) if b % 2 == 0 else (0, 8, 10)):
            put(drums, kick(rng, 90, 55, 40, 14, 0.02, 0.3), G.t(b, s), 0.8 if s == 0 else 0.6)
        for s in (4, 12):
            put(drums, snap(rng), G.t(b, s) + rng.uniform(0, 0.006), 0.35, pan=0.15)
        for s in range(16):
            put(drums, shaker(rng), G.t(b, s), 0.10 * (1.0, 0.5, 1.6, 0.6)[s % 4], pan=-0.3)
    wet = echo(kal, 3 * G.step, fb=0.3, lo=400, hi=4000)
    stems_report('playful', marimba=0.5 * mar, kalimba=0.6 * kal, echo=0.2 * wet, bass=0.5 * bass, drums=0.7 * drums)
    mix = 0.5 * mar + 0.6 * kal + 0.2 * wet + 0.5 * bass + 0.7 * drums
    return mix + 0.18 * reverb(mar + kal + 0.3 * drums, reverb_ir(1.0, seed=7, hi=5000))


def bed_funk(rng):
    """Pop art / neobrutalism — 112 BPM, Em7 – A9 – Em7 – G6|A6 (E dorian). Synth slap bass (thumbs, pops, ghost notes,
    chromatic pick-ups), clavinet-like muted 16th stabs, brassy synth stabs on the turnaround, punchy-but-soft kit."""
    G = Grid(112, swing=0.53)
    bass, clv, brs, drums, org = bus(), bus(), bus(), bus(), bus()
    organ = [([59, 62, 64, 67],) * 2, ([59, 61, 64, 67],) * 2, ([59, 62, 64, 67],) * 2, ([59, 62, 64, 67], [57, 61, 64, 66])]
    form = [(40, 50, 40, [67, 71, 74], [67, 71, 74]), (45, 55, 45, [67, 71, 73], [67, 71, 73]),
            (40, 50, 40, [67, 71, 74], [67, 71, 74]), (43, 52, 45, [67, 71, 76], [66, 69, 73])]
    for b in range(G.bars):
        r1, col, r2, cl1, cl2 = form[b % 4]
        nxt = form[(b + 1) % 4][0]
        for h, ch in enumerate(organ[b % 4]):
            put(org, sine_pad(ch, G.bar / 2 - 0.02, att=0.05, rel=0.2, h=(1.0, 0.5, 0.25), det=3.0), b * G.bar + h * G.bar / 2)
        ev = [(0, 'T', r1, 1.5), (2, 'P', r1 + 12, 1), (3, 'g', r1, 0.4), (5, 'T', r1, 1), (6, 'P', r1 + 12, 1), (7, 'T', col, 1),
              (8, 'T', r2 + 7, 1.5), (10, 'P', r2 + 12, 1), (11, 'g', r2, 0.4), (12, 'T', r2, 1), (14, 'P', r2 + 12, 1),
              (15, 'T', nxt - 1, 0.7)]
        for s, kind, m, L in ev:
            put(bass, slap(m, L * G.step * 0.85, {'T': 0.9, 'P': 0.7, 'g': 0.25}[kind], pop=kind == 'P'), G.t(b, s))
        for s in ((2, 6, 10, 13, 14) if b % 2 == 0 else (2, 5, 6, 10, 14)):
            for j, m in enumerate(cl1 if s < 8 else cl2):
                put(clv, clav(m, 0.07, 0.8 if s in (6, 14) else 0.55), G.t(b, s) + 0.003 * j, pan=0.35)
        if b % 4 == 3:
            for s, ch, d in ((6, [67, 71, 74, 76], 0.16), (14, [69, 73, 76, 78], 0.30)):
                for j, m in enumerate(ch):
                    put(brs, brass(m, d, 0.8, rng), G.t(b, s), pan=-0.3 + 0.2 * j)
        if b % 8 == 0 and b > 0:
            for j, m in enumerate([64, 67, 71, 74]):
                put(brs, brass(m, 0.12, 0.7, rng), G.t(b, 0), pan=-0.3 + 0.2 * j)
        for s in ((0, 7, 10) if b % 2 == 0 else (0, 10, 13)):
            put(drums, kick(rng, 120, 50, 35, 9, 0.08), G.t(b, s), 1.0 if s == 0 else 0.8)
        for s in (4, 12):
            put(drums, snare(rng, tone=195, tdec=24, ndec=18), G.t(b, s), 0.6)
        for s in (9, 15):
            put(drums, snare(rng, tone=195, tdec=30, ndec=30), G.t(b, s), 0.10)
        for s in range(16):
            if b % 2 and s == 14:
                put(drums, hat(rng, dec=14, length=0.22), G.t(b, s), 0.10, pan=0.25)
            else:
                put(drums, hat(rng, dec=70), G.t(b, s), 0.12 * (1.0, 0.45, 0.75, 0.45)[s % 4], pan=0.25)
    org = lp(org, 2500)
    stems_report('funk', bass=0.5 * bass, clav=0.5 * clv, brass=0.3 * brs, drums=0.55 * drums, organ=0.13 * org)
    mix = 0.5 * bass + 0.5 * clv + 0.3 * brs + 0.55 * drums + 0.13 * org
    mix += 0.12 * reverb(clv + brs + 0.3 * drums, reverb_ir(0.9, seed=8, hi=5000))
    return sat(norm(mix, 0.9), 1.2)


def bubble_note(f, vel, length=0.16):
    """Bubbly blip: a sine that glides up ~60 % into its pitch while it decays."""
    n = int(length * SR)
    t = secs(n)
    ph = phase(f * (0.62 + 0.38 * (1 - np.exp(-t / 0.018))), n)
    x = np.sin(TAU * ph) + 0.08 * np.sin(2 * TAU * ph)
    return x * np.exp(-t * 26) * env(n, 0.0015, gate=length - 0.02, rel=0.02) * vel


def bed_y2k(rng):
    """Y2K chrome — 128 BPM 2-step garage / bubbly electro-pop, A major 'royal road': Dmaj9 – E6 – C#m7 – F#m9.
    Shuffled 2-step drums (kick on 1 and the 'and' of 3, clap+rim on 2 & 4, swung hats), chorused plucky square-saw
    stabs, bubbly up-gliding blips, sparkly bell arpeggios, round bass."""
    G = Grid(128, swing=0.62)
    stab, spark, bass, drums = bus(), bus(), bus(), bus()
    chords = [[66, 69, 73, 76], [68, 71, 73, 76], [64, 68, 71, 73], [64, 68, 69, 73]]
    roots = [38, 40, 37, 42]
    pats = [[(0, 2), (3, 1), (6, 2), (10, 1), (13, 2)], [(2, 1), (5, 1), (8, 2), (11, 1), (14, 2)]]
    for b in range(G.bars):
        c = b % 4
        for s, L in pats[b % 2]:
            for j, m in enumerate(chords[c]):
                put(stab, pluck(m, L * G.step * 0.6, 0.8, 'sqsaw', dec=9.0, kdec=1.0, flim=5500, ph0=rng.uniform()), G.t(b, s),
                    pan=-0.2 + 0.13 * j)
        for s, r, L in ((0, 0, 4), (6, 12, 1), (7, 0, 2), (10, 0, 3), (14, 7, 2)):
            put(bass, round_bass(roots[c] + r, L * G.step * 0.85, 0.9, h2=0.3, att=0.006, dec=1.5, drive=1.6, rel=0.05), G.t(b, s))
        for s in ((0, 10) if b % 2 == 0 else (0, 7, 10)):
            put(drums, kick(rng, 115, 50, 34, 10, 0.05), G.t(b, s), 1.0 if s == 0 else 0.8)
        for s in (4, 12):
            put(drums, clap(rng, tail=20), G.t(b, s), 0.35)
            put(drums, rim(rng, 1800, 80, 500, 0.15), G.t(b, s), 0.12)
        for s in range(16):
            if s % 4 == 2:
                put(drums, hat(rng, dec=45, length=0.1), G.t(b, s), 0.16, pan=0.3)
            elif s % 2 == 1:
                put(drums, hat(rng, dec=90, length=0.05), G.t(b, s), 0.06, pan=0.3)
        for s in rng.choice([1, 5, 9, 11, 13, 15], 3, replace=False):
            put(spark, bubble_note(float(mtof(chords[c][rng.integers(4)] + 12)), rng.uniform(0.6, 1.0)), G.t(b, s),
                pan=rng.uniform(-0.6, 0.6))
        if b % 2 == 1:
            for k, m in enumerate(chords[c]):
                put(spark, bell(m + 12, 0.35, length=1.6), G.t(b, 8) + k * G.step / 2, pan=-0.4 + 0.25 * k)
    stab = lp(chorus(stab, mix=0.5, base=12, depth=3, rate=0.7), 4500)
    wet = echo(spark + 0.3 * stab, 3 * G.step, fb=0.35, lo=400, hi=4000)
    stems_report('y2k', stab=0.42 * stab, spark=0.4 * spark, echo=0.15 * wet, bass=0.45 * bass, drums=0.7 * drums)
    mix = 0.42 * stab + 0.4 * spark + 0.15 * wet + 0.45 * bass + 0.7 * drums
    return mix + 0.2 * reverb(stab + spark + 0.3 * drums, reverb_ir(1.6, seed=9, hi=5000))


def crackle(rng, n, rate=6.0):
    """Sparse vinyl pops: a Poisson train of signed impulses band-limited to 0.9–4.5 kHz (no continuous hiss)."""
    x = np.zeros(n)
    k = rng.poisson(rate * n / SR)
    np.add.at(x, rng.integers(0, n, k), np.clip(rng.exponential(1.0, k), 0, 4) * rng.choice([-1.0, 1.0], k))
    return bp(x, 900, 4500)


def bed_dusty(rng):
    """Risograph / paper collage — dusty boom-bap, 88 BPM swung, Ebmaj9 – Cm9 – Fm9 – Bb13 (I–vi–ii–V). Warm Rhodes comping
    (lofi.py tines), upright-ish bass with chromatic approach notes, lazy swung kit (late snare), sparse soft vinyl pops,
    low-passed ~5 kHz, gently saturated, a touch of wow."""
    G = Grid(88, swing=0.60)
    keys, bass, drums = bus(), bus(), bus()
    chords = [[55, 58, 62, 65], [55, 58, 62, 63], [56, 60, 63, 67], [56, 60, 62, 67]]
    roots = [39, 36, 41, 46]
    for b in range(G.bars):
        c = b % 4
        nxt = roots[(c + 1) % 4]
        for s, vel, ln in ((0, 0.55, 1.9), (6, 0.32, 2.2)):
            for j, m in enumerate(chords[c]):
                put(keys, ep(m, ln * G.beat, vel * rng.uniform(0.85, 1.0), rng, bright=0.8),
                    G.t(b, s) + 0.011 * j + rng.uniform(0, 0.006), pan=-0.2 + 0.13 * j)
        r = roots[c]
        for s, m, L, v in ((0, r, 5, 0.9), (6, r, 1.5, 0.55), (8, r + 7, 5.5, 0.75), (14, nxt - 1, 1.5, 0.6)):
            put(bass, upright(m, L * G.step, v, rng), G.t(b, s) + 0.008)
        for s in (0, 10) + ((7,) if b % 2 else ()):
            put(drums, kick(rng, 116, 46, 28, 9.5, 0.12), G.t(b, s), 0.5 if s == 7 else 0.85)
        for s in (4, 12):
            put(drums, snare(rng, tone=190, tdec=24, ndec=16, lo=700, hi=5000, body=0.5, noise=0.6), G.t(b, s) + 0.018, 0.55)
        for s in range(0, 16, 2):
            put(drums, hat(rng, dec=60, lo=4200, hi=6800), G.t(b, s) + rng.uniform(0, 0.008), 0.16 if s % 4 == 0 else 0.10, pan=0.25)
        put(drums, hat(rng, dec=80, lo=4200, hi=6800, length=0.05), G.t(b, 15), 0.06, pan=0.25)
    n = len(keys)
    vinyl = np.stack([crackle(rng, n), crackle(rng, n)], 1)
    stems_report('dusty', keys=0.55 * keys, bass=0.55 * bass, drums=0.6 * drums, vinyl=0.02 * vinyl)
    mix = lp(0.55 * keys + 0.55 * bass + 0.6 * drums, 5000) + 0.02 * vinyl
    return wow(sat(norm(mix, 0.9), 1.4), 4.0, 0.5, 1.5, 5.5, seed=10)


# preset → (builder, seed, final low-pass Hz or None)
PRESETS = {
    'minimal': (bed_minimal, 11, 9000), 'synthwave': (bed_synthwave, 21, 8500), 'vaporwave': (bed_vaporwave, 31, None),
    'chiptune': (bed_chiptune, 41, None), 'glitch': (bed_glitch, 51, 8000), 'ambient': (bed_ambient, 61, 8000),
    'playful': (bed_playful, 71, 8000), 'funk': (bed_funk, 81, 8500), 'y2k': (bed_y2k, 91, 9000), 'dusty': (bed_dusty, 101, None),
}


def render_beds(names):
    for nm in names:
        fn, seed, lph = PRESETS[nm]
        t = time.time()
        st = master_bed(fn(np.random.default_rng(seed)), nm, lp_hz=lph)
        print(f'bed {nm}: {len(st) / SR:.3f}s  {lufs(st):.1f} LUFS  TP {true_peak_db(st):.1f} dBTP  ({time.time() - t:.1f}s)', flush=True)


def render_bed_to(name, seconds, out):
    """Synthesise one bed preset to exactly `seconds` (any length) into `out`."""
    global DUR
    DUR = float(seconds)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    if name == 'lofi':
        import lofi
        lofi.main(out, DUR)
        return
    if name not in PRESETS:
        raise SystemExit(f'unknown bed "{name}" — presets: lofi, {", ".join(PRESETS)}')
    fn, seed, lph = PRESETS[name]
    t = time.time()
    st = master_bed(fn(np.random.default_rng(seed)), name, lp_hz=lph, out=out)
    print(f'bed {name}: {len(st) / SR:.2f}s  {lufs(st):.1f} LUFS  ({time.time() - t:.1f}s)', flush=True)


# ═══════════════════════════════ QA ═══════════════════════════════
def metrics(path, kind):
    """ebur128 (I, LRA, true peak) + DC, band-energy split, gaps, HF bursts (click finder), SFX onset/ends."""
    sr, x = wavfile.read(path)
    x = x.astype(np.float64)
    x = x[:, None] if x.ndim == 1 else x
    m = x.mean(1)
    af = 'ebur128=peak=true' if kind == 'bed' else 'apad=pad_dur=1,ebur128=peak=true'
    r = subprocess.run([FF, '-hide_banner', '-nostats', '-i', path, '-af', af, '-f', 'null', '-'], capture_output=True, text=True)
    s = r.stderr[r.stderr.rfind('Summary:'):]
    tp = re.search(r'Peak:\s+(-?[\d.]+|-inf) dBFS', s).group(1)
    P = np.abs(np.fft.rfft(m)) ** 2
    fr = np.fft.rfftfreq(len(m), 1 / sr)
    band = lambda lo, hi: float(P[(fr >= lo) & (fr < hi)].sum() / (P.sum() + 1e-30) * 100)
    h = hp(m, 9000, 4)
    w1 = int(0.002 * sr)
    k1 = len(h) // w1
    hr = 20 * np.log10(np.sqrt((h[:k1 * w1].reshape(k1, w1) ** 2).mean(1)) + 1e-12)
    out = dict(I=float(re.search(r'I:\s+(-?[\d.]+) LUFS', s).group(1)), LRA=float(re.search(r'LRA:\s+(-?[\d.]+) LU', s).group(1)),
               TP=float(tp) if tp != '-inf' else -99.0, dc=[round(float(v), 6) for v in x.mean(0)],
               peak=round(float(20 * np.log10(np.abs(x).max() + 1e-12)), 2), len=round(len(m) / sr, 4), sr=sr, ch=x.shape[1],
               lt80=round(band(0, 80), 2), b80_3k=round(band(80, 3000), 2), b3k_7k=round(band(3000, 7000), 2),
               gt7k=round(band(7000, sr / 2), 3), hf_max_db=round(float(hr.max()), 1), hf_max_t=round(float(hr.argmax() * w1 / sr), 3))
    if kind == 'bed':
        w = int(0.05 * sr)
        k = len(m) // w
        rms = 20 * np.log10(np.sqrt((m[:k * w].reshape(k, w) ** 2).mean(1)) + 1e-12)
        out['min_rms50_db'] = round(float(rms[5:-1].min()), 1)
        out['gaps'] = int((rms[5:-1] < -50).sum())
    else:
        pk = np.abs(m).max()
        out['onset_ms'] = round(float(np.argmax(np.abs(m) > 0.05 * pk) / sr * 1000), 2)
        out['first'], out['last'] = round(float(m[0]), 5), round(float(m[-1]), 5)
    return out


def _spec(m, cols, nfft, hop, fmin=40.0, fmax=16000.0, rows=170):
    """Log-frequency spectrogram (dB), frames max-pooled to `cols` so single clicks stay visible."""
    from scipy.signal import stft
    if len(m) < 2 * nfft:
        m = np.concatenate([m, np.zeros(2 * nfft - len(m))])
    f, _, Z = stft(m, SR, nperseg=nfft, noverlap=nfft - hop, boundary=None, padded=False)
    P = 20 * np.log10(np.abs(Z) + 1e-9)
    fl = np.geomspace(fmin, fmax, rows)
    lo = np.clip(np.searchsorted(f, fl) - 1, 0, len(f) - 2)
    wgt = ((fl - f[lo]) / (f[lo + 1] - f[lo]))[:, None]
    P = P[lo] * (1 - wgt) + P[lo + 1] * wgt
    e = np.linspace(0, P.shape[1], min(cols, P.shape[1]) + 1).astype(int)
    return np.stack([P[:, a:max(a + 1, b)].max(1) for a, b in zip(e[:-1], e[1:])], 1), fl


def _panel(ax, path, kind, M, title):
    sr, x = wavfile.read(path)
    m = x.astype(np.float64)
    m = m.mean(1) if m.ndim == 2 else m
    P, fl = _spec(m, 1600 if kind == 'bed' else 400, 4096 if kind == 'bed' else 512, 512 if kind == 'bed' else 24)
    ax.imshow(P - P.max(), aspect='auto', origin='lower', cmap='magma', vmin=-90, vmax=0, extent=[0, len(m) / sr, 0, len(fl)])
    row = lambda hz: float(np.interp(np.log(hz), np.log(fl), np.arange(len(fl))))
    ax.set_yticks([row(v) for v in (100, 300, 1000, 3000, 7000)])
    ax.set_yticklabels(['100', '300', '1k', '3k', '7k'], fontsize=6)
    ax.axhline(row(7000), color='cyan', lw=0.6, ls='--')
    ax.tick_params(axis='x', labelsize=6)
    ax.set_title(title, fontsize=7, loc='left')


def qa(which='all'):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    os.makedirs(QA_DIR, exist_ok=True)
    mpath = os.path.join(QA_DIR, 'metrics.json')
    res = json.load(open(mpath)) if os.path.exists(mpath) else {}
    if which in ('beds', 'all'):
        names = list(PRESETS) + ['lofi']
        fig, axes = plt.subplots(len(names), 1, figsize=(16, 1.55 * len(names)), dpi=100)
        for ax, nm in zip(axes, names):
            p = os.path.join(BEDS_DIR, nm + '.wav')
            M = res['bed:' + nm] = metrics(p, 'bed')
            _panel(ax, p, 'bed', M, f"{nm}  {M['len']}s {M['ch']}ch  I {M['I']} LUFS  LRA {M['LRA']}  TP {M['TP']}  DC {max(abs(d) for d in M['dc']):.5f}"
                   f"  <80 {M['lt80']}%  80-3k {M['b80_3k']}%  3-7k {M['b3k_7k']}%  >7k {M['gt7k']}%  minRMS50 {M['min_rms50_db']} dB"
                   f"  gaps {M['gaps']}  HFmax {M['hf_max_db']} dB @ {M['hf_max_t']}s")
            print(nm, M, flush=True)
        fig.tight_layout()
        fig.savefig(os.path.join(QA_DIR, 'beds_sheet.png'))
        plt.close(fig)
    if which in ('sfx', 'all'):
        names = list(SFX)
        cols = 3
        rows = int(np.ceil(len(names) / cols))
        fig, axes = plt.subplots(rows, cols, figsize=(15, 2.1 * rows), dpi=100)
        for ax, nm in zip(axes.flat, names):
            p = os.path.join(SFX_DIR, nm + '.wav')
            M = res['sfx:' + nm] = metrics(p, 'sfx')
            _panel(ax, p, 'sfx', M, f"{nm}  {M['len']}s  pk {M['peak']}  TP {M['TP']}  I {M['I']}  onset {M['onset_ms']}ms  >7k {M['gt7k']}%"
                   f"  HFmax {M['hf_max_db']}")
            print(nm, M, flush=True)
        for ax in list(axes.flat)[len(names):]:
            ax.axis('off')
        fig.tight_layout()
        fig.savefig(os.path.join(QA_DIR, 'sfx_sheet.png'))
        plt.close(fig)
    json.dump(res, open(mpath, 'w'), indent=1)


# ═══════════════════════════════ SFX kit ═══════════════════════════════
def glide(f, ms=2.5):
    """Smooth instantaneous pitch steps (one-pole on log-frequency) so a note change can't splatter."""
    a = np.exp(-1000.0 / (ms * SR))
    lf = np.log2(np.asarray(f, dtype=float))
    return 2.0 ** lfilter([1 - a], [1, -a], lf, zi=[lf[0] * a])[0]


def sfx_chip_blip():
    return chip(88, 0.06, 1.0, duty=0.25, dec=18.0, rel=0.02)                       # E6, 25 % pulse


def sfx_chip_coin():
    n = int(0.48 * SR)
    t = secs(n)
    f = glide(np.where(t < 0.075, mtof(83), mtof(88)))                              # B5 → E6, phase-continuous
    e = env(n, 0.002, gate=0.42, rel=0.05) * np.where(t < 0.075, 1.0, np.exp(-(t - 0.075) * 5.5))
    return harm(f, n, 'square', flim=6000) * e


def sfx_chip_jump():
    n = int(0.22 * SR)
    t = secs(n)
    f = 280 * (850 / 280) ** np.clip(t / 0.16, 0, 1)                                # exponential up-sweep
    return harm(f, n, pulse_amps(0.25), flim=6000) * env(n, 0.002, dec=0.12, gate=0.17, rel=0.04)


def sfx_chip_powerup():
    seq = [72, 76, 79, 84, 74, 78, 81, 86, 76, 80, 83, 88]                          # C, D, E major arps rising
    d = 0.036
    n = int((len(seq) * d + 0.2) * SR)
    t = secs(n)
    f = glide(mtof(np.array(seq))[np.minimum((t / d).astype(int), len(seq) - 1)])
    f = f * cents(12 * np.sin(TAU * 7 * t) * np.clip((t - len(seq) * d) / 0.05, 0, 1))
    e = env(n, 0.002, gate=n / SR - 0.08, rel=0.08) * (0.75 + 0.25 * np.clip(t / (len(seq) * d), 0, 1))
    return harm(f, n, 'square', flim=6000) * e


def sfx_chip_select():
    n = int(0.13 * SR)
    t = secs(n)
    f = glide(np.where(t < 0.045, mtof(81), mtof(88)))                              # A5 → E6, 12.5 % pulse
    return harm(f, n, pulse_amps(0.125), flim=6000) * env(n, 0.0015, dec=0.06, gate=0.10, rel=0.03)


def sfx_glass_tink():
    n = int(0.75 * SR)
    x = partials(n, 1480.0, (1.0, 1.0042, 2.0, 2.756), (0.7, 0.4, 0.12, 0.18), (5.5, 6.5, 10.0, 16.0), 6500)
    return x * env(n, 0.0015, gate=0.7, rel=0.05)


def sfx_bubble():
    n = int(0.14 * SR)
    t = secs(n)
    ph = phase(340 + 820 * (1 - np.exp(-t / 0.03)), n)                              # ~340 → 1100 Hz glide up
    return (np.sin(TAU * ph) + 0.1 * np.sin(2 * TAU * ph)) * env(n, 0.002, dec=0.035, gate=0.12, rel=0.02)


def sfx_zap():
    n = int(0.3 * SR)
    t = secs(n)
    f = 220 + 1500 * np.exp(-t / 0.06)                                              # 1.7 kHz → 220 Hz fall
    x = harm(f, n, lambda k: (1.0 if k % 2 else 0.3) / k, flim=5000)
    return lp(x * env(n, 0.002, dec=0.12, gate=0.26, rel=0.04), 4000)


def sfx_tape_stop():
    rng = np.random.default_rng(5)
    src = sum(ep(m, 0.55, 0.5, rng, bright=0.7, rel=0.05) for m in (53, 64, 67, 69, 72))   # Fmaj9 Rhodes
    T = 0.5
    n = int(T * SR)
    rate = (1 - secs(n) / T) ** 1.6                                                 # playback speed 1 → 0
    y = np.interp(np.cumsum(rate) - rate[0], np.arange(len(src)), src)
    return lp(y * env(n, 0.003, gate=T - 0.08, rel=0.08), 3500)


def sfx_stamp():
    rng = np.random.default_rng(9)
    n = int(0.35 * SR)
    t = secs(n)
    ph = phase(52 + 60 * np.exp(-t / 0.03), n)
    thud = (np.sin(TAU * ph) + 0.25 * np.sin(2 * TAU * ph)) * np.exp(-t * 13)
    slap_ = bp(rng.standard_normal(n) * np.exp(-t * 75) * rcos(t / 0.0006), 500, 3000) * 0.6
    paper = bp(rng.standard_normal(n) * np.exp(-t * 40) * rcos(t / 0.001), 1500, 4500) * 0.12
    return (0.9 * thud + lp(slap_ + paper, 5000)) * env(n, 0.001, gate=0.3, rel=0.05)


def sfx_boing():
    n = int(0.65 * SR)
    t = secs(n)
    base = 150 * (1 + 0.85 * (1 - np.exp(-t / 0.05)))                               # 150 → ~278 Hz
    f = base * (1 + 0.16 * np.exp(-t / 0.22) * np.sin(TAU * 13 * t))                # decaying spring wobble
    x = harm(f, n, lambda k: (1.0, 0.55, 0.3, 0.15, 0.08)[k - 1] if k <= 5 else 0.0, flim=3000)
    return lp(x * env(n, 0.003, dec=0.22, gate=0.58, rel=0.07), 2500)


def sfx_shimmer():
    seq = [79, 81, 84, 86, 88, 91, 93, 96]                                          # C major pentatonic, rising
    n = int(1.0 * SR)
    x = np.zeros(n)
    for i, m in enumerate(seq):
        at = int(i * 0.07 * SR)
        b = bell(m, 0.5 + 0.5 * i / len(seq), length=0.9, att=0.003)
        x[at:at + len(b)] += b[:n - at]
    wet = reverb(x, reverb_ir(0.8, pre=0.01, lo=800, hi=6000, seed=11))[:, 0]
    return (x + 0.4 * wet) * env(n, 0.002, gate=0.92, rel=0.08)


def sfx_pluck_up():
    rng = np.random.default_rng(13)
    n = int(0.55 * SR)
    x = np.zeros(n)
    a, b = marimba(72, 0.8, rng, length=0.45), marimba(79, 0.95, rng, length=0.45)  # C5 → G5
    x[:len(a)] += a
    at = int(0.085 * SR)
    x[at:at + len(b)] += b[:n - at]
    return x


def sfx_tick():
    n = int(0.03 * SR)
    t = secs(n)
    x = np.sin(TAU * 3100 * t) * np.exp(-t * 900) + 0.5 * np.sin(TAU * 1550 * t) * np.exp(-t * 600)
    return x * rcos(t / 0.0004) * env(n, 0, gate=0.025, rel=0.005)


def sfx_marimba_hit():
    return marimba(67, 0.95, np.random.default_rng(17), length=0.8)                  # G4


def sfx_bass_drop():
    n = int(0.7 * SR)
    t = secs(n)
    ph = phase(42 + 78 * np.exp(-t / 0.09), n)                                       # 120 → 42 Hz
    x = np.sin(TAU * ph) + 0.3 * np.sin(2 * TAU * ph) * np.exp(-t * 6)
    return sat(x * env(n, 0.004, dec=0.25, gate=0.62, rel=0.08), 1.2)


def sfx_paper_rustle():
    """A soft card flip: ~20 tiny band-passed crinkle grains under a quick swell, ending in a muted card tap."""
    rng = np.random.default_rng(19)
    n = int(0.2 * SR)
    t = secs(n)
    x = np.zeros(n)
    for _ in range(22):
        at, L = int(rng.uniform(0, 0.14) * SR), int(rng.uniform(0.001, 0.003) * SR)
        x[at:at + L] += (np.hanning(L) * rng.standard_normal(L) * rng.uniform(0.3, 1.0))[:n - at]
    x = lp(bp(x, 1200, 5000), 4200, 4) * rcos(t / 0.02) * np.exp(-t * 14)
    at = int(0.11 * SR)
    tt = secs(n - at)
    x[at:] += lp(rng.standard_normal(n - at) * np.exp(-tt * 180) * rcos(tt / 0.0008), 900) * 0.8 + np.sin(TAU * 240 * tt) * np.exp(-tt * 60) * 0.25
    return x * env(n, 0.001, gate=0.18, rel=0.02)


def sfx_swish_soft():
    """Very soft airy swish: noise through a band that slides up 0.5→4 kHz, gentle rise/fall, 0.26 s."""
    rng = np.random.default_rng(23)
    n = int(0.26 * SR)
    u = secs(n) / (n / SR)
    w = rng.standard_normal(n)
    e = np.where(u < 0.4, (u / 0.4) ** 1.5, ((1 - u) / 0.6) ** 1.5)
    return lp((bp(w, 500, 1500) * (1 - u) ** 2 + bp(w, 900, 2600) * 2 * u * (1 - u) + bp(w, 1600, 4000) * u ** 2) * e, 4500, 4)



# ── generic UI sounds (code-synth stand-ins for a stock UI pack; same names, levels matched to the stock files the
#    styles were tuned with, measured as the loudest 50 ms RMS window = "burst", so the dB values in scene.js still hold)
def _sq(f, n, top=3200.0):
    t = secs(n)
    return sum(np.sin(TAU * f * k * t) / k for k in range(1, 40, 2) if f * k < top)


def sfx_pop():
    """Soft bubbly pop: a sine falling 1230 → 330 Hz in ~30 ms with a tiny filtered click on top."""
    n = int(0.16 * SR)
    t = secs(n)
    ph = phase(330 + 900 * np.exp(-t / 0.012), n)
    body = (np.sin(TAU * ph) + 0.3 * np.sin(2 * TAU * ph)) * env(n, 0.0012, dec=0.03, gate=0.12, rel=0.03)
    clk = bp(np.random.default_rng(5).standard_normal(n), 1500, 4500) * np.exp(-t * 900) * 0.45
    return body + clk


def _click(rng, f1, f2, lo, hi, nz, length=0.05):
    n = int(length * SR)
    t = secs(n)
    x = np.sin(TAU * f1 * t) * np.exp(-t * 520) * 0.6 + np.sin(TAU * f2 * t) * np.exp(-t * 380) * 0.45
    x += bp(rng.standard_normal(n), lo, hi) * np.exp(-t * 1400) * nz
    return x * rcos(t / 0.0004)


def sfx_click():
    """Crisp UI click: two damped modes (3.4 / 1.7 kHz) + a 2 ms noise tick."""
    return _click(np.random.default_rng(41), 3400, 1700, 2500, 7500, 0.8)


def sfx_click_soft():
    """Rounder, quieter-sounding click: modes at 2.2 / 1.1 kHz, gentle tick, low-passed."""
    return lp(_click(np.random.default_rng(43), 2200, 1100, 1500, 5000, 0.5, 0.055), 5200)


def _key(rng, vel=1.0, thock=None, bright=1.0, release=True):
    """One keystroke: plastic click (band-passed noise + 2 damped modes) over a low thock, softer release ~70 ms later."""
    n = int(0.16 * SR)
    t = secs(n)
    x = np.sin(TAU * (thock or rng.uniform(170, 240)) * t) * np.exp(-t * 90) * 0.55
    x += bp(rng.standard_normal(n), 1800, 6500) * np.exp(-t * 420) * 0.9 * bright
    for f, d, a in ((rng.uniform(2600, 3400), 380, 0.35), (rng.uniform(1100, 1500), 260, 0.3)):
        x += np.sin(TAU * f * t) * np.exp(-t * d) * a
    x *= rcos(t / 0.0006)
    if release:
        at = int(rng.uniform(0.055, 0.085) * SR)
        tt = secs(n - at)
        r = bp(rng.standard_normal(n - at), 2000, 6000) * np.exp(-tt * 600) * 0.35 + np.sin(TAU * 2900 * tt) * np.exp(-tt * 500) * 0.12
        x[at:] += r * rcos(tt / 0.0005)
    return x * vel


def sfx_key_press():
    return _key(np.random.default_rng(31))[:int(0.14 * SR)]


def sfx_typing():
    """~1.4 s of natural typing: 13 keystrokes at ~9–11 per second, uneven rhythm and force, one space bar."""
    rng = np.random.default_rng(37)
    n = int(1.55 * SR)
    x = np.zeros(n)
    t = 0.0
    for k in range(13):
        sp = k == 6
        s = _key(rng, rng.uniform(0.7, 1.0), thock=120 if sp else None, bright=0.7 if sp else 1.0)
        i = int(t * SR)
        e = min(n, i + len(s))
        x[i:e] += s[:e - i]
        t += rng.uniform(0.075, 0.125) + (0.05 if k in (3, 9) else 0.0)
    return x


def sfx_error():
    """Gentle 'nope': two soft square-ish notes stepping down G4 → E♭4, low-passed."""
    n = int(0.45 * SR)
    x = np.zeros(n)
    for at, m, L in ((0.0, 67, 0.13), (0.15, 63, 0.24)):
        k = int((L + 0.05) * SR)
        y = _sq(float(mtof(m)), k) * env(k, 0.004, dec=0.12, gate=L, rel=0.05)
        i = int(at * SR)
        x[i:i + k] += y[:n - i]
    return lp(x, 2600, 2)


def sfx_notification():
    """Bright message 'ding-ding': two bell notes E6 → B6, 90 ms apart."""
    n = int(0.9 * SR)
    x = np.zeros(n)
    for at, m, v in ((0.0, 88, 0.85), (0.09, 95, 1.0)):
        b = bell(m, v, length=0.8, amps=(1.0, 0.1, 0.25, 0.06, 0.02), decays=(4.5, 7.0, 9.0, 14.0, 20.0), flim=7000.0)
        i = int(at * SR)
        x[i:i + len(b)] += b[:n - i]
    return x


def sfx_ping():
    """Single bright struck-bell ping on A6 with a quick, clean decay."""
    return bell(93, 1.0, length=0.7, amps=(1.0, 0.06, 0.22, 0.05, 0.0), decays=(6.0, 9.0, 12.0, 20.0, 30.0), flim=7000.0)


def sfx_chime():
    """Soft positive chime: C6–E6–G6–C7 struck 70 ms apart, ringing out."""
    n = int(1.7 * SR)
    x = np.zeros(n)
    for i, m in enumerate((84, 88, 91, 96)):
        b = bell(m, 0.7 + 0.1 * i, length=1.5, decays=(2.2, 3.5, 5.0, 9.0, 16.0), flim=7000.0)
        a = int(i * 0.07 * SR)
        x[a:a + len(b)] += b[:n - a]
    return x


def sfx_sparkle():
    """Quick glittery run: 10 high bell notes up a pentatonic, 28 ms apart, short decays + a small reverb."""
    seq = [91, 93, 96, 98, 100, 103, 105, 108, 110, 112]
    n = int(0.8 * SR)
    x = np.zeros(n)
    for i, m in enumerate(seq):
        b = bell(m, 0.55 + 0.45 * i / len(seq), length=0.35, decays=(9.0, 14.0, 20.0, 30.0, 40.0), att=0.0015, flim=7000.0)
        a = int(i * 0.028 * SR)
        x[a:a + len(b)] += b[:n - a]
    wet = reverb(x, reverb_ir(0.6, pre=0.008, lo=1500, hi=6800, seed=12))[:, 0]
    return (x + 0.35 * wet[:n]) * env(n, 0.001, gate=0.74, rel=0.06)


def sfx_magic():
    """Whimsical 'magic wand': a celesta run up a pentatonic (8 notes, 50 ms apart — one per emoji as a frame pops in),
    a soft high cluster at the top, seeded fairy-dust twinkles, an airy shimmer swell and a warm sine bloom, all in a
    bright 1.2 s reverb. Fixed seeds: identical every time."""
    n = int(1.6 * SR)
    t = secs(n)
    x = np.zeros(n)
    run = [79, 81, 84, 86, 88, 91, 93, 96]                                        # G5 → C7, G major pentatonic
    for i, m in enumerate(run):
        b = bell(m, 0.42 + 0.4 * i / len(run), length=0.7, decays=(5.5, 9.0, 14.0, 24.0, 34.0), att=0.0015, flim=8000.0)
        a = int(i * 0.05 * SR)
        x[a:a + len(b)] += b[:n - a]
    for j, (m, at, v) in enumerate([(100, 0.42, 0.34), (103, 0.47, 0.28), (98, 0.53, 0.24), (105, 0.6, 0.18)]):   # top cluster
        b = bell(m, v, length=0.9, decays=(3.2, 6.0, 11.0, 20.0, 30.0), att=0.002, flim=9000.0)
        a = int(at * SR)
        x[a:a + len(b)] += b[:n - a]
    rng = np.random.default_rng(77)
    for k in range(14):                                                           # fairy dust: tiny high pings
        at, f = 0.12 + rng.random() * 0.85, 3600 + rng.random() * 3600
        m = int(0.05 * SR)
        a = int(at * SR)
        tt = secs(m)
        ping = np.sin(TAU * f * tt) * np.exp(-tt * 85) * (0.05 + 0.05 * rng.random())
        x[a:a + m] += ping[:n - a]
    air = bp(rng.standard_normal(n), 3500, 9500)                                  # shimmer swell
    air *= np.clip(t / 0.35, 0, 1) ** 1.5 * np.exp(-np.clip(t - 0.35, 0, None) * 4.5) * 0.035
    bloom = (np.sin(TAU * 392.0 * t) + 0.6 * np.sin(TAU * 587.3 * t) + 0.35 * np.sin(TAU * 987.8 * t))   # G4 D5 B5
    bloom *= (1 - np.exp(-t / 0.08)) * np.exp(-t * 3.2) * 0.05
    x = x + air + bloom
    wet = reverb(x, reverb_ir(1.2, pre=0.01, lo=700, hi=7500, seed=21))[:, 0]
    return (x + 0.5 * wet[:n]) * env(n, 0.001, gate=1.5, rel=0.1)


def sfx_impact_bass_1():
    """Deep soft impact: sine 95 → 36 Hz with a felt transient and a little saturation (headline slam, not EDM)."""
    n = int(1.4 * SR)
    t = secs(n)
    x = np.sin(TAU * phase(36 + 59 * np.exp(-t / 0.07), n)) * env(n, 0.003, dec=0.42, gate=1.3, rel=0.1)
    x += lp(np.random.default_rng(47).standard_normal(n) * np.exp(-t * 160), 700) * 0.35
    return sat(x, 1.3)


GEN = {'pop': (sfx_pop, -11.6), 'click': (sfx_click, -21.0), 'click-soft': (sfx_click_soft, -21.0), 'typing': (sfx_typing, -24.3),
       'key-press': (sfx_key_press, -30.3), 'error': (sfx_error, -24.9), 'notification': (sfx_notification, -14.9),
       'ping': (sfx_ping, -22.4), 'chime': (sfx_chime, -25.8), 'sparkle': (sfx_sparkle, -7.8), 'impact-bass-1': (sfx_impact_bass_1, -0.6),
       'magic': (sfx_magic, -11.0)}


def burst_db(x):
    w = int(0.05 * SR)
    k = max(1, len(x) // w)
    xx = np.pad(x, (0, max(0, k * w - len(x))))[:k * w]
    return float(20 * np.log10(np.sqrt((xx.reshape(k, w) ** 2).mean(1)).max() + 1e-12))


def gen_finish(x, burst, hp_hz=40.0):
    """Like sfx_finish, but level = the target burst (loudest 50 ms RMS) instead of a peak (float32 may exceed 0 dBFS)."""
    x = sfx_finish(x, hp_hz, -3.0)
    return x * 10 ** ((burst - burst_db(x)) / 20)


def typing_cut(seconds, burst, seed_skip=0.0):
    """A shorter typing take (first `seconds` of sfx_typing) at a given burst level."""
    x = sfx_finish(sfx_typing(), 40.0, -3.0)
    x = fade(x[int(seed_skip * SR):int((seed_skip + seconds) * SR)], 0.0002, 0.02)
    return x * 10 ** ((burst - burst_db(x)) / 20)


SFX = {'chip-blip': sfx_chip_blip, 'chip-coin': sfx_chip_coin, 'chip-jump': sfx_chip_jump, 'chip-powerup': sfx_chip_powerup,
       'chip-select': sfx_chip_select, 'glass-tink': sfx_glass_tink, 'bubble': sfx_bubble, 'zap': sfx_zap,
       'tape-stop': sfx_tape_stop, 'stamp': sfx_stamp, 'boing': sfx_boing, 'shimmer': sfx_shimmer, 'pluck-up': sfx_pluck_up,
       'tick': sfx_tick, 'marimba-hit': sfx_marimba_hit, 'bass-drop': sfx_bass_drop, 'paper-rustle': sfx_paper_rustle,
       'swish-soft': sfx_swish_soft}
SFX_PEAK = {'swish-soft': -8.0}          # the brief asked for a low-level swish; everything else peaks at −3 dBFS
SFX_HP = {'bass-drop': 25.0, 'stamp': 30.0}


def sfx_finish(x, hp_hz=40.0, pk_db=-3.0):
    """HP (DC/rumble), drop any lead-in below −60 dB of peak (sound starts at sample 0), trim the tail at −60 dB,
    4 ms end fade, peak-normalise."""
    x = hp(np.asarray(x, dtype=float), hp_hz, 2)
    a = np.abs(x)
    pk = a.max()
    x = x[int(np.argmax(a > pk * 1e-3)):]
    a = np.abs(x)
    end = len(x) - int(np.argmax(a[::-1] > pk * 1e-3))
    x = fade(x[:min(len(x), end + int(0.005 * SR))], 0.0002, 0.004)
    return x * (10 ** (pk_db / 20) / np.max(np.abs(x)))


def render_sfx(names, out_dir=None):
    for nm in names:
        if nm not in SFX and nm not in GEN:
            raise SystemExit(f'unknown sfx "{nm}" — known: {", ".join(list(SFX) + list(GEN))}')
        if nm in GEN:
            fn, b = GEN[nm]
            x = gen_finish(fn(), b)
        else:
            x = sfx_finish(SFX[nm](), SFX_HP.get(nm, 40.0), SFX_PEAK.get(nm, -3.0))
        write(os.path.join(out_dir or SFX_DIR, nm + '.wav'), x)
        print(f'sfx {nm}: {len(x) / SR:.3f}s  peak {20 * np.log10(np.max(np.abs(x))):.1f} dBFS', flush=True)


def main():
    a = sys.argv[1:]
    cmd = a[0] if a else 'list'
    if cmd == 'beds':
        render_beds(a[1:] or list(PRESETS))
    elif cmd == 'sfx':                                   # sfx [name ...] [--out dir]
        out = a[a.index('--out') + 1] if '--out' in a else None
        names = [x for x in a[1:] if not x.startswith('--') and x != out]
        render_sfx(names or list(SFX) + list(GEN), out)
    elif cmd == 'bed':                                   # bed <preset> <seconds> <out.wav>
        render_bed_to(a[1], float(a[2]), a[3])
    elif cmd == 'qa':
        qa(a[1] if len(a) > 1 else 'all')
    else:
        print('beds:', 'lofi', ' '.join(PRESETS), '\nsfx: ', ' '.join(list(SFX) + list(GEN)))


if __name__ == '__main__':
    main()
