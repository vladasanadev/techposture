"""Head-to-head 9:16: two edits of the same take stacked on an off-white page, each in a rounded window with its
AI's label — the layout of the viral "who edited it better" reels (1080×1920).

usage:  python3 stack.py --top claude.mp4 --bottom chatgpt.mp4 --out head_to_head.mp4
          [--top-label "CLAUDE"] [--top-brand claude] [--bottom-label "CHATGPT"] [--bottom-brand chatgpt]
          [--title1 "EDITING"] [--title1-script "with|AI"] [--title2 "WHO’S|better?"] [--switch 3.9]
          [--audio take.mov | top | bottom]
--switch  when the title cuts from title1 to title2 (the reference cuts when her first sentence ends — use the
          edit's first cut, e.g. edit.json beats.editor.in)
--audio   default: the top edit's audio. Pass the original take for neutral audio (no edit's sound effects),
          which is the fairest for a comparison.
Both edits must be the same length and in sync with the take (the engine's edits always are).
"""
import os, shutil, socket, subprocess, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, FF, FP, HERE
ensure_venv()


def arg(name, default=None):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default


top, bottom, out = arg('--top'), arg('--bottom'), arg('--out', 'head_to_head.mp4')
if not (top and bottom): raise SystemExit(__doc__)
sw = float(arg('--switch', 3.9))
t2 = arg('--title2', 'WHO’S|better?').split('|')
params = {'t1': arg('--title1', 'EDITING'), 't1s': arg('--title1-script', ''), 't2a': t2[0], 't2b': t2[1] if len(t2) > 1 else '',
          'lt': arg('--top-label', 'CLAUDE'), 'bt': arg('--top-brand', 'claude'), 'lb': arg('--bottom-label', 'CHATGPT'), 'bb': arg('--bottom-brand', 'chatgpt')}
from urllib.parse import urlencode
work = tempfile.mkdtemp(prefix='stack_')
for n in ('frame.html', 'fonts'):
    s = os.path.join(HERE, 'stack', n)
    (shutil.copytree if os.path.isdir(s) else shutil.copy2)(s, os.path.join(work, n))
shutil.copy2(os.path.join(HERE, 'stage', 'brands.js'), work); shutil.copytree(os.path.join(HERE, 'stage', 'logos'), os.path.join(work, 'logos'))
s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
SRV = ('import http.server, socketserver, sys\n'
       'class S(socketserver.ThreadingMixIn, socketserver.TCPServer): allow_reuse_address = True; daemon_threads = True\n'
       'class Q(http.server.SimpleHTTPRequestHandler):\n    def log_message(self, *a): pass\n'
       'S(("127.0.0.1", int(sys.argv[1])), Q).serve_forever()')
srv = subprocess.Popen([sys.executable, '-c', SRV, str(port)], cwd=work, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(0.6)
from playwright.sync_api import sync_playwright
try:
    with sync_playwright() as p:
        try: b = p.chromium.launch(channel='chrome')
        except Exception: b = p.chromium.launch()
        pg = b.new_page(viewport={'width': 1080, 'height': 1920}, device_scale_factor=1)
        for st in ('A', 'B'):
            pg.goto(f'http://127.0.0.1:{port}/frame.html?' + urlencode({**params, 's': st}))
            pg.wait_for_function('document.title === "done"', timeout=20000)
            pg.screenshot(path=os.path.join(work, f'frame_{st}.png'), omit_background=True)
        b.close()
finally:
    srv.terminate()
au = arg('--audio', 'top')
inputs = ['-i', top, '-i', bottom, '-loop', '1', '-framerate', '30', '-i', os.path.join(work, 'frame_A.png'),
          '-loop', '1', '-framerate', '30', '-i', os.path.join(work, 'frame_B.png')]
if au not in ('top', 'bottom'):
    inputs += ['-i', au]; amap = ['-map', '4:a', '-af', 'highpass=f=70,loudnorm=I=-14:TP=-1.5:LRA=11']
else:
    amap = ['-map', '0:a' if au == 'top' else '1:a']
dur = subprocess.run([FP, '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', top], capture_output=True, text=True).stdout.strip()
fc = (f"color=c=0xFBF9FC:s=1080x1920:r=30:d={dur},format=gbrp[base];"
      "[0:v]scale=930:523:flags=lanczos:in_color_matrix=bt709:in_range=tv,crop=928:523:1:0,format=gbrp,setsar=1[t];"
      "[1:v]scale=930:523:flags=lanczos:in_color_matrix=bt709:in_range=tv,crop=928:523:1:0,format=gbrp,setsar=1[b];"
      "[2:v]format=rgba[fa];[3:v]format=rgba[fb];"
      "[base][t]overlay=76:395:format=gbrp:shortest=1[b1];[b1][b]overlay=76:1160:format=gbrp:shortest=1[b2];"
      f"[b2][fa]overlay=0:0:format=gbrp:enable='lt(t,{sw})'[b3];[b3][fb]overlay=0:0:format=gbrp:enable='gte(t,{sw})',"
      "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p[v]")
subprocess.run([FF, '-v', 'error', '-y', *inputs, '-filter_complex', fc, '-map', '[v]', *amap, '-t', dur, '-r', '30',
                '-c:v', 'libx264', '-preset', 'slow', '-crf', '16', '-tune', 'film', '-colorspace', 'bt709', '-color_primaries', 'bt709',
                '-color_trc', 'bt709', '-color_range', 'tv', '-movflags', '+faststart', '-c:a', 'aac', '-b:a', '256k', out], check=True)
shutil.rmtree(work, ignore_errors=True)
print('✓', out)
