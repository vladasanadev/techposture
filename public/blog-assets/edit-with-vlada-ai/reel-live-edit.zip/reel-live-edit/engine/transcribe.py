"""Word timestamps + a cleaned voice track.

usage:  python3 transcribe.py <project_dir> [--lang en] [--backend mlx|faster|openai]
→ <project>/words.json  [[word, start, end], …]      (also printed as a readable transcript)
→ <project>/audio/voice.wav  (high-pass, gentle compression, de-ess, −16 LUFS)
"""
import json, os, platform, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, P, FF
ensure_venv()

def arg(name, default=None):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default

proj = project_dir(); cfg = load(proj)
src = os.path.join(proj, cfg['source'])
wav16 = P(proj, 'audio', 'voice16k.wav')
subprocess.run([FF, '-v', 'error', '-y', '-i', src, '-vn', '-ac', '1', '-ar', '16000', wav16], check=True)
raw = P(proj, 'audio', 'voice_raw.wav')
subprocess.run([FF, '-v', 'error', '-y', '-i', src, '-vn', '-ac', '1', '-ar', '48000', raw], check=True)
chain = 'highpass=f=75,acompressor=threshold=-20dB:ratio=2.5:attack=8:release=120:makeup=2,deesser=i=0.35'
r = subprocess.run([FF, '-hide_banner', '-nostats', '-i', raw, '-af', chain + ',loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json', '-f', 'null', '-'],
                   capture_output=True, text=True)
j = json.loads(r.stderr[r.stderr.rindex('{'):r.stderr.rindex('}') + 1])
ln = (f"loudnorm=I=-16:TP=-1.5:LRA=7:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:"
      f"measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
subprocess.run([FF, '-v', 'error', '-y', '-i', raw, '-af', f'{chain},{ln},aresample=48000', '-c:a', 'pcm_s24le', P(proj, 'audio', 'voice.wav')], check=True)

lang, backend = arg('--lang', 'en'), arg('--backend')
order = [backend] if backend else (['mlx', 'faster', 'openai'] if platform.system() == 'Darwin' and platform.machine() == 'arm64' else ['faster', 'openai'])
words = None
for b in order:
    try:
        if b == 'mlx':
            import mlx_whisper
            res = mlx_whisper.transcribe(wav16, path_or_hf_repo='mlx-community/whisper-large-v3-turbo', word_timestamps=True,
                                         language=lang, condition_on_previous_text=False)
            words = [[w['word'].strip(), round(w['start'], 3), round(w['end'], 3)] for s in res['segments'] for w in s.get('words', [])]
        elif b == 'faster':
            from faster_whisper import WhisperModel
            segs, _ = WhisperModel('large-v3-turbo', device='auto', compute_type='int8').transcribe(wav16, language=lang, word_timestamps=True,
                                                                                              condition_on_previous_text=False)
            words = [[w.word.strip(), round(w.start, 3), round(w.end, 3)] for s in segs for w in (s.words or [])]
        elif b == 'openai':
            import whisper
            res = whisper.load_model('turbo').transcribe(wav16, language=lang, word_timestamps=True, condition_on_previous_text=False)
            words = [[w['word'].strip(), round(w['start'], 3), round(w['end'], 3)] for s in res['segments'] for w in s.get('words', [])]
        break
    except ImportError:
        continue
if words is None: raise SystemExit('no whisper backend — run python3 setup.py --install')
json.dump(words, open(P(proj, 'words.json'), 'w'), indent=0, ensure_ascii=False)
line = []
for w, s, e in words:
    line.append(f'{w}@{s:.2f}')
    if w.endswith(('.', '?', '!')): print(' '.join(line)); line = []
if line: print(' '.join(line))
print(f'\n{len(words)} words → words.json · voice.wav ready\nnext: python3 cuts.py {proj}')
