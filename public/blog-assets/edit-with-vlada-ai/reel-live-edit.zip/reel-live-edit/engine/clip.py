"""The movie-clip insert: a frameless 3D card that slides out from BEHIND her head on the clip word, floats beside
her (her hair stays in front of it), pulses on each "movie" and whips out before the next beat.
Composited by composite.py; clip_layer(t) → (premultiplied rgb, alpha, shadow) in 1920×1080, or None.
edit.json: beats.clip {in, out, src_start, pulses}, clip_file, layout.clip_side {side, head_x, head_top}.
"""
import math, os, subprocess
import numpy as np, cv2
from common import FF, FP, W, H

PD = 2600.0                                   # perspective distance (card size: beats.clip.width, default 900 px)
SRC_W, SRC_H = 1280, 720


def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def lerp(a, b, u): return a + (b - a) * u
def out_expo(x): x = clamp(x); return 1 if x >= 1 else 1 - 2 ** (-10 * x)
def out_cubic(x): x = clamp(x); return 1 - (1 - x) ** 3
def in_cubic(x): x = clamp(x); return x ** 3
def io_sine(x): x = clamp(x); return -(math.cos(math.pi * x) - 1) / 2
def out_back(x, s=1.4): x = clamp(x); return 1 + (s + 1) * (x - 1) ** 3 + s * (x - 1) ** 2


class Clip:
    def __init__(self, proj, cfg):
        c = cfg['beats']['clip']
        self.t_in, self.t_end = c['in'], c['out']
        self.t_land = self.t_in + 0.53
        self.t_out = self.t_end - 0.195
        self.pulses = c.get('pulses', [])
        L = cfg.get('layout', {}).get('clip_side', {})
        self.sgn = -1 if c.get('side', L.get('side', 'left')) == 'left' else 1      # −1: card on the viewer's left
        self.cw = float(c.get('width', 900)); self.ch = self.cw * 9 / 16             # card size at scale 1
        hx, ht = L.get('head_x', W / 2), L.get('head_top', 130)
        self.start = (hx + 60 * self.sgn, ht + 212)                  # tucked behind her head
        self.home = (W / 2 + self.sgn * (self.cw / 2 - 10), 372 + (self.cw - 900) * 0.08)   # beside her, overlapping her hair a little
        # decode the clip window once (1280×720, its own frame rate)
        path = os.path.join(proj, cfg['clip_file'])
        fps = subprocess.run([FP, '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=r_frame_rate', '-of', 'csv=p=0', path],
                             capture_output=True, text=True).stdout.strip().split('/')
        self.fps = float(fps[0]) / float(fps[1] if len(fps) > 1 else 1)
        self.src0 = c.get('src_start', 0.0)
        dur = self.t_end - self.t_in + 0.4
        raw = subprocess.run([FF, '-v', 'error', '-ss', f'{self.src0:.3f}', '-i', path, '-t', f'{dur:.3f}',
                              '-vf', f'scale={SRC_W}:{SRC_H}:force_original_aspect_ratio=increase,crop={SRC_W}:{SRC_H}',
                              '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], capture_output=True).stdout
        n = len(raw) // (SRC_W * SRC_H * 3)
        self.frames = np.frombuffer(raw[:n * SRC_W * SRC_H * 3], np.uint8).reshape(n, SRC_H, SRC_W, 3)
        m = np.zeros((SRC_H, SRC_W), np.float32); r = 20
        cv2.rectangle(m, (r, 0), (SRC_W - 1 - r, SRC_H - 1), 1, -1); cv2.rectangle(m, (0, r), (SRC_W - 1, SRC_H - 1 - r), 1, -1)
        for x, y in ((r, r), (SRC_W - 1 - r, r), (r, SRC_H - 1 - r), (SRC_W - 1 - r, SRC_H - 1 - r)): cv2.circle(m, (x, y), r, 1, -1, cv2.LINE_AA)
        self.mask = m

    def pose(self, t):
        u = out_expo((t - self.t_in) / (self.t_land - self.t_in + 0.25))
        ub = out_back((t - self.t_in) / (self.t_land - self.t_in + 0.12), 1.15)
        s = self.sgn
        cx = lerp(self.start[0], self.home[0], u); cy = lerp(self.start[1], self.home[1], u)
        sc = lerp(0.50, 1.0, ub)
        ry = -s * lerp(62, -13, ub); rx = lerp(-6, 4, u); rz = -s * lerp(5, -1.6, u)
        d = io_sine((t - self.t_land) / max(0.2, self.t_out - self.t_land))
        cx += s * 34 * d; cy -= 10 * d; sc *= 1 + 0.035 * d; ry += -s * 6 * d; rx -= 2 * d; rz += -s * 1.0 * d
        ry += 1.6 * math.sin(2 * math.pi * (t - self.t_in) / 2.6); rx += 0.8 * math.sin(2 * math.pi * (t - self.t_in) / 3.1 + 1)
        for b in self.pulses:
            k = t - (b - 0.03)
            if 0 <= k < 0.5: sc *= 1 + 0.045 * math.exp(-k * 9) * min(1, k / 0.04)
        w = in_cubic((t - self.t_out) / (self.t_end - self.t_out))
        cx += s * 1500 * w; ry += s * 38 * w; rz += s * 4 * w; sc *= 1 + 0.08 * w
        zoom = 1.03 + 0.06 * clamp((t - self.t_in) / (self.t_end - self.t_in))
        return cx, cy, sc, ry, rx, rz, zoom

    def corners(self, t):
        cx, cy, sc, ry, rx, rz, zoom = self.pose(t)
        CW, CH = self.cw, self.ch
        pts = np.array([[-CW / 2, -CH / 2, 0], [CW / 2, -CH / 2, 0], [CW / 2, CH / 2, 0], [-CW / 2, CH / 2, 0]]) * sc
        a, b, c = math.radians(ry), math.radians(rx), math.radians(rz)
        Ry = np.array([[math.cos(a), 0, math.sin(a)], [0, 1, 0], [-math.sin(a), 0, math.cos(a)]])
        Rx = np.array([[1, 0, 0], [0, math.cos(b), -math.sin(b)], [0, math.sin(b), math.cos(b)]])
        Rz = np.array([[math.cos(c), -math.sin(c), 0], [math.sin(c), math.cos(c), 0], [0, 0, 1]])
        q = pts @ (Rz @ Rx @ Ry).T
        k = PD / (PD + q[:, 2])
        return np.float32(np.stack([cx + q[:, 0] * k, cy + q[:, 1] * k], 1)), zoom

    def frame_at(self, t):
        i = int(round((t - self.t_in) * self.fps))
        im = self.frames[max(0, min(len(self.frames) - 1, i))].astype(np.float32)
        return np.clip((im - 128) * 1.06 + 128 + np.array([4, 1, -3], np.float32), 0, 255)

    def _render(self, t):
        dst, zoom = self.corners(t)
        cw, ch = SRC_W / zoom, SRC_H / zoom
        x0, y0 = (SRC_W - cw) / 2, (SRC_H - ch) / 2
        Mc = cv2.getPerspectiveTransform(np.float32([[x0, y0], [x0 + cw, y0], [x0 + cw, y0 + ch], [x0, y0 + ch]]), dst)
        Mm = cv2.getPerspectiveTransform(np.float32([[0, 0], [SRC_W, 0], [SRC_W, SRC_H], [0, SRC_H]]), dst)
        rgb = cv2.warpPerspective(self.frame_at(t), Mc, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        a = cv2.warpPerspective(self.mask, Mm, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        g = clamp((t - (self.t_in + 0.16)) / 0.55)                 # glint sweeping across on the way in
        if 0 < g < 1:
            xs = np.arange(W, dtype=np.float32)[None, :]; ys = np.arange(H, dtype=np.float32)[:, None]
            cxp = dst[:, 0].min() - 200 + (dst[:, 0].max() - dst[:, 0].min() + 400) * out_cubic(g)
            rgb = rgb + (np.exp(-(((xs + 0.45 * (ys - 380)) - cxp) / 70.0) ** 2) * math.sin(math.pi * g))[..., None] * 70
        return rgb * a[..., None], a

    def layer(self, t, fps):
        if t < self.t_in or t >= self.t_end: return None
        fast = t < self.t_land + 0.05 or t > self.t_out - 0.02
        n = 9 if fast else 1
        shutter = 0.9 if t > self.t_out - 0.02 else 0.7
        acc = np.zeros((H, W, 3), np.float32); aa = np.zeros((H, W), np.float32)
        for i in range(n):
            ts = max(self.t_in, t + (shutter * ((i + 0.5) / n - 0.5) / fps if n > 1 else 0))
            c, a = self._render(ts); acc += c; aa += a
        acc /= n; aa /= n
        op = clamp((t - self.t_in) / 0.08); acc *= op; aa *= op
        sh = np.roll(cv2.GaussianBlur(aa, (0, 0), 26), (26, 10), (0, 1)) * 0.42
        return acc, aa, sh
