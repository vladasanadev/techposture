"""Find the jump cuts already in the take (a talking-head take is usually trimmed between sentences).

usage:  python3 cuts.py <project_dir> [--thresh 3.5]
Compares every frame with the previous one on a small grey thumbnail; a cut is a spike far above the take's normal
frame-to-frame motion. Writes edit.json "cuts" (seconds, the first frame of each new shot). Check them in the printed
list — a hand flying across the lens can look like a cut; delete those by hand.
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, save, FF, P, src_frames
ensure_venv()
import numpy as np
from PIL import Image, ImageDraw

proj = project_dir(); cfg = load(proj)
k = float(sys.argv[sys.argv.index('--thresh') + 1]) if '--thresh' in sys.argv else 3.5
w, h = 96, 54
p = subprocess.Popen([FF, '-v', 'error', '-i', os.path.join(proj, cfg['source']), '-vf', f'scale={w}:{h}', '-f', 'rawvideo', '-pix_fmt', 'gray', '-'],
                     stdout=subprocess.PIPE)
prev, d = None, []
while True:
    b = p.stdout.read(w * h)
    if len(b) < w * h: break
    f = np.frombuffer(b, np.uint8).astype(np.float32)
    d.append(0.0 if prev is None else float(np.abs(f - prev).mean())); prev = f
d = np.array(d)
base = np.median(d[1:]) + 1e-3
fps = cfg['fps']
cuts = []
for i in range(1, len(d)):
    lo, hi = max(1, i - 6), min(len(d), i + 7)
    neigh = np.delete(d[lo:hi], i - lo)
    if d[i] > max(k * base * 2.5, 4.0) and d[i] > 2.2 * np.median(neigh) and d[i] == d[max(1, i - 2):i + 3].max():
        cuts.append(round(i / fps, 3))
cfg['cuts'] = cuts
save(proj, cfg)
rows = []
for c in cuts:
    f = round(c * fps); pair = []
    for ff in (f - 1, f):
        for _, img in src_frames(proj, cfg, ff, (320, 180)): pair.append(Image.fromarray(img.astype(np.uint8))); break
    row = Image.new('RGB', (644, 204), 'black'); row.paste(pair[0], (0, 0)); row.paste(pair[1], (324, 0))
    ImageDraw.Draw(row).text((6, 186), f'cut at {c:.3f}s   before | after', fill=(255, 255, 255)); rows.append(row)
if rows:
    S = Image.new('RGB', (644 * 2, 204 * ((len(rows) + 1) // 2)), 'black')
    for i, r in enumerate(rows): S.paste(r, ((i % 2) * 644, (i // 2) * 204))
    S.save(P(proj, 'out', 'cuts.jpg'), quality=85)
print('cuts:', cuts, f'(median motion {base:.2f})  → out/cuts.jpg (look at it)')
print('next: python3 plan.py', proj)
