"""Matte her out of every frame (RobustVideoMatting, Apple GPU / CUDA / CPU).

usage:  python3 matte.py <project_dir>
→ work/alpha/%05d.png for every frame (1920×1080), work/fgr/%05d.png (clean foreground colour) only where it's needed:
  the movie-clip window and everything from the background clear on. The recurrent state is reset at every cut.
Speed: ~0.06 s/frame on an M-series Mac, ~0.03 on a CUDA GPU, ~1 s on CPU.
"""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ensure_venv, project_dir, load, P, src_frames, beat, MODELS, W, H, nframes
ensure_venv()
import numpy as np, torch
from PIL import Image
sys.path.insert(0, os.path.join(MODELS, 'RVM'))
from model import MattingNetwork

proj = project_dir(); cfg = load(proj); fps = cfg['fps']
dev = 'mps' if torch.backends.mps.is_available() else ('cuda' if torch.cuda.is_available() else 'cpu')
m = MattingNetwork('resnet50').eval().to(dev)
m.load_state_dict(torch.load(os.path.join(MODELS, 'rvm_resnet50.pth'), map_location='cpu'))
cut_f = {round(c * fps) for c in cfg.get('cuts', [])}
need = []
if beat(cfg, 'clip', 'in') is not None: need.append((beat(cfg, 'clip', 'in') - 0.4, beat(cfg, 'clip', 'out') + 0.2))
if beat(cfg, 'clear', 't') is not None: need.append((beat(cfg, 'clear', 't') - 0.4, 1e9))
want_fgr = lambda t: any(a <= t <= b for a, b in need)
adir, fdir = P(proj, 'work', 'alpha'), P(proj, 'work', 'fgr')
rec = [None] * 4; t0 = time.time(); n = nframes(cfg)
with torch.no_grad():
    for f, img in src_frames(proj, cfg, 0, (W, H)):
        if f in cut_f: rec = [None] * 4
        x = torch.from_numpy(img / 255.0).float().to(dev).permute(2, 0, 1)[None]
        fgr, pha, *rec = m(x, *rec, downsample_ratio=0.25)
        Image.fromarray((pha[0, 0].clamp(0, 1) * 255 + 0.5).byte().cpu().numpy(), 'L').save(f'{adir}/{f:05d}.png', compress_level=1)
        if want_fgr(f / fps):
            Image.fromarray((fgr[0].permute(1, 2, 0).clamp(0, 1) * 255 + 0.5).byte().cpu().numpy(), 'RGB').save(f'{fdir}/{f:05d}.png', compress_level=1)
        if f % 90 == 0: print(f'{f}/{n}  {(time.time() - t0) / (f + 1):.3f} s/f', flush=True)
print(f'matte done ({dev}) → work/alpha, work/fgr\nnext: python3 track.py {proj}')
