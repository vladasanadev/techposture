"""Check — and with --install, set up — everything the live-edit engine needs.

usage:  python3 setup.py             check only (prints what is missing)
        python3 setup.py --install   create the engine venv at ~/.liveedit (or $LIVEEDIT_VENV, Python 3.12) with torch,
                                     mediapipe, opencv, scipy, pillow, playwright and a whisper backend; download the
                                     matting model (RobustVideoMatting, GPL-3.0, fetched from its GitHub, not bundled) and
                                     MediaPipe's hand + pose models into ~/.liveedit/models.
After setup every engine script re-launches itself inside the venv, so `python3 engine/<script>.py …` just works.
System tools you install yourself: ffmpeg (brew install ffmpeg · winget install Gyan.FFmpeg · apt install ffmpeg) and
Google Chrome (GPU rendering of the 3D layer; Playwright's Chromium is the fallback).
"""
import importlib, os, platform, shutil, subprocess, sys, urllib.request, zipfile, io

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import FF, FP, VENV, MODELS, venv_python

APPLE = platform.system() == 'Darwin' and platform.machine() == 'arm64'
PKGS = ['numpy', 'scipy', 'pillow', 'opencv-python-headless', 'torch', 'torchvision', 'mediapipe', 'playwright',
        'mlx-whisper' if APPLE else 'faster-whisper']
RVM_ZIP = 'https://github.com/PeterL1n/RobustVideoMatting/archive/refs/heads/master.zip'
RVM_W = 'https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_resnet50.pth'
MP = {'hand_landmarker.task': 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task',
      'pose_landmarker_heavy.task': 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/latest/pose_landmarker_heavy.task'}


def has_chrome():
    return any(os.path.exists(p) for p in ('/Applications/Google Chrome.app', os.path.expanduser('~/Applications/Google Chrome.app'),
                                           r'C:\Program Files\Google\Chrome\Application\chrome.exe')) or bool(
        shutil.which('google-chrome') or shutil.which('google-chrome-stable'))


def check():
    ok = True
    print(f'ffmpeg   {FF or "✗ missing"}\nffprobe  {FP or "✗ missing"}')
    if not (FF and FP):
        ok = False; print('  → macOS: brew install ffmpeg · Windows: winget install Gyan.FFmpeg · Linux: sudo apt install ffmpeg')
    py = venv_python()
    print(f'venv     {py if os.path.exists(py) else "✗ missing (run setup.py --install)"}')
    if os.path.exists(py):
        code = ('import importlib\nfor m in ["numpy","scipy","PIL","cv2","torch","mediapipe","playwright"]:\n'
                '  try: x=importlib.import_module(m); print(f"  {m:<11}", getattr(x,"__version__","ok"))\n'
                '  except Exception as e: print(f"  {m:<11} ✗", e)\n'
                'w=None\nfor m in ["mlx_whisper","faster_whisper","whisper"]:\n'
                '  try: importlib.import_module(m); w=m; break\n  except Exception: pass\nprint("  whisper    ", w or "✗ missing")\n'
                'import torch\nprint("  device     ", "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu (matting will be slow)"))')
        r = subprocess.run([py, '-c', code], capture_output=True, text=True)
        print(r.stdout.rstrip()); ok = ok and '✗' not in r.stdout
    for n in ['rvm_resnet50.pth', 'RVM/model/model.py'] + list(MP):
        e = os.path.exists(os.path.join(MODELS, n))
        print(f'model    {n:<28} {"ok" if e else "✗ missing"}'); ok = ok and e
    print(f'chrome   {"found (GPU path)" if has_chrome() else "not found → Playwright Chromium (slower 3D)"}')
    print('\nREADY' if ok else '\nNOT READY — run: python3 setup.py --install')
    return ok


def fetch(url, dst):
    print('  ↓', os.path.basename(dst))
    tmp = dst + '.part'
    with urllib.request.urlopen(url) as r, open(tmp, 'wb') as f: shutil.copyfileobj(r, f)
    os.replace(tmp, dst)


def install():
    py = venv_python()
    if not os.path.exists(py):
        uv = shutil.which('uv')
        if uv: subprocess.run([uv, 'venv', '--python', '3.12', VENV], check=True)
        else:
            base = shutil.which('python3.12') or sys.executable
            subprocess.run([base, '-m', 'venv', VENV], check=True)
    uv = shutil.which('uv')
    if uv: subprocess.run([uv, 'pip', 'install', '--python', py, *PKGS], check=True)
    else: subprocess.run([py, '-m', 'pip', 'install', '-U', 'pip', *PKGS], check=True)
    if not has_chrome(): subprocess.run([py, '-m', 'playwright', 'install', 'chromium'], check=True)
    os.makedirs(MODELS, exist_ok=True)
    if not os.path.exists(os.path.join(MODELS, 'RVM/model/model.py')):
        print('  ↓ RobustVideoMatting code (GPL-3.0)')
        z = zipfile.ZipFile(io.BytesIO(urllib.request.urlopen(RVM_ZIP).read()))
        root = z.namelist()[0].split('/')[0]
        for n in z.namelist():
            if n.startswith(f'{root}/model/') or n == f'{root}/LICENSE':
                out = os.path.join(MODELS, 'RVM', n[len(root) + 1:])
                if n.endswith('/'): os.makedirs(out, exist_ok=True); continue
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with open(out, 'wb') as f: f.write(z.read(n))
    if not os.path.exists(os.path.join(MODELS, 'rvm_resnet50.pth')): fetch(RVM_W, os.path.join(MODELS, 'rvm_resnet50.pth'))
    for n, u in MP.items():
        if not os.path.exists(os.path.join(MODELS, n)): fetch(u, os.path.join(MODELS, n))
    check()


if __name__ == '__main__':
    install() if '--install' in sys.argv else check()
