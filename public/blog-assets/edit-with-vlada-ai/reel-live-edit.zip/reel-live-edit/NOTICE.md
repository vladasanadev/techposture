# Third-party components

| component | licence | how it's used |
|---|---|---|
| three.js r169 (`engine/stage/vendor`) | MIT | 3D glass logo cubes |
| Anton, Instrument Serif, Yeseva One, Cormorant Garamond, Marck Script, Pinyon Script | SIL OFL 1.1 (texts next to the fonts) | captions, head-to-head titles |
| simple-icons logos (`engine/stage/logos`) | CC0 1.0 | brand marks naming the compared products (trademarks belong to their owners) |
| RobustVideoMatting | GPL-3.0 | **downloaded** from its GitHub by `setup.py`, not included here |
| MediaPipe hand / pose landmarker models | Apache-2.0 | **downloaded** from Google by `setup.py`, not included here |
| Whisper (mlx-whisper / faster-whisper) | MIT | installed by `setup.py` |

All sound effects are synthesised in code (`engine/bedkit.py`, `engine/sfx.py`). No samples, no stock audio.
No movie clips are included: bring your own and make sure you may use them.
