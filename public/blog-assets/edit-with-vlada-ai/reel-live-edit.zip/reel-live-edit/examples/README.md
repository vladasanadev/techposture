`edit.example.json` is the real plan of the example edit (Vlada's 35 s take, 2560×1440, 30 fps): every beat, the
caption chunks and the measured layout. Use it to see what a complete, working edit.json looks like.
