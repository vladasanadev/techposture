# Copy-paste prompts

Paste these into **Claude Code** (terminal, or the Code tab in the Claude desktop app) with the skill installed.
Replace the `<…>` parts.

## 1 · Set up (once)

```
Use the reel-live-edit skill. Run its setup and tell me when it prints READY.
If anything is missing (ffmpeg, Chrome, Python 3.12), tell me the exact command to install it.
```

## 2 · Make the edit

```
Use the reel-live-edit skill to edit my take: <path/to/take.mov>
The two AIs are ChatGPT (my right hand) and Claude (my left hand).
For the "movie" command use <path/to/clip.mp4>, starting at <m:ss> in that file.
Work in <~/live-edit/my-take>.
Before the long steps, show me the plan: every command, the word it lands on and the time.
Then render it, open the QA sheet, check every beat yourself, and give me the MP4 path.
No music, no AI-generated footage. Keep the ending clean (my footage + captions only).
```

## 3 · Fix things (one at a time works best)

```
The ChatGPT cube appears a bit late. Move its click 3 frames earlier, show me a still, then re-render.
```
```
Captions: split "AND I'LL SEND YOU" into "AND I'LL" / "send you". Re-render only after showing me a still.
```
```
Make the movie card bigger (about 1000 px wide) and start the clip on the moment he raises his hands.
```
```
My background isn't a window; turn off the window matte cleanup and check the hair edges over the clip card.
```
```
Add a soft music bed under it at -14 dB — here's the track: <path/to/bed.wav>
```

## 4 · The head-to-head (after the other AI made its edit of the same take)

```
Use the reel-live-edit skill to stack two edits of the same take into the 9:16 head-to-head:
top = <claude_edit.mp4> labelled "CLAUDE" (brand claude),
bottom = <other_edit.mp4> labelled "CHATGPT" (brand chatgpt).
Title "EDITING" until the end of my first sentence, then "WHO'S better?". Use my original take's audio.
Show me a frame before you send the file.
```

## 5 · The fair brief (give the SAME brief to every AI you pit against each other)

```
Here is my talking-head take: <file>. I speak editing commands in it. Edit the video so every command visibly happens
on the word I say it: logos on the hands I name, they float and fly off, it gets "harder", subtitles in two fonts
start when I say "subtitles", a clip from a Tarantino movie appears when I say "Tarantino", the background clears,
a clone of me appears next to me, and the ending is clean with captions. Every second should look edited.
Deliver a 1920×1080 MP4, same length, in sync with my audio.
```

## 6 · The post caption

```
Write my Instagram caption for the head-to-head: lowercase, my voice, one hook line, one line saying top is Claude
and bottom is ChatGPT, ask "who edited it better?", CTA "comment EDIT and i'll send you my instructions", no hashtags.
```
