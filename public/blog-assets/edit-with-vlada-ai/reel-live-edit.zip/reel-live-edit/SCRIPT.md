# The script + how to film it

## Read this (≈ 35 s)

> Who's better at video editing, **ChatGPT or Claude**?
> Let's make them edit this video **in real time**.
> Put **ChatGPT logo on my right hand**. *(raise your right palm, hold it)*
> Now put **Claude logo on my left hand**. *(raise your left palm, hold both)*
> Now make them **float** and **fly off** to the sides.
> Let's make it **harder**.
> Put **subtitles** using these two fonts.
> Overlay a clip from any **Tarantino** movie when I say "**movie**".
> Let's try **even harder**.
> **Clear** everything on the background and put a **clone** of me next to me.
> So… who **won**?
> **Want** to edit videos like this too? Comment EDIT and I'll send you my instructions.

The bold words are what the engine listens for. Swap freely:
- **Other AIs**: "Gemini or Grok", "Claude or DeepSeek"… (chatgpt, claude, gemini, grok, perplexity, meta, mistral, deepseek, copilot).
- **Other movie**: "a clip from any Wes Anderson movie" → tell Claude the clip word (`plan.py --clip-word anderson`).
- **Your CTA**: anything after "who won?" becomes the clean ending.
- **Drop a command**: skip a line and that effect is skipped. Keep the order, it's what makes the escalation work.

## Film it

- **Landscape 16:9**, 4K or 1080p, **30 fps**, phone on a tripod at eye level. (The 9:16 version comes later from the head-to-head stack.)
- Frame **mid-chest up**, centred, with room on both sides for raised palms and a little headroom.
- **Palms**: when you say "on my right hand", raise that hand **open, palm up, beside your shoulder**, and keep it there.
  Raise the second one on its line and hold **both** until "fly off". The cubes sit on your palms — no palm, no cube.
- **Background**: anything works; plain walls matte cleanest. A bright window is fine (the edit has a cleanup for it).
- **Light** on your face, no flicker. Don't wear the same colour as the wall.
- Keep hands off your face on "clear everything" and "clone" (the clone is a copy of you).
- **Jump-cut your best takes together** before you hand it over, or do it in one take. Cuts are detected automatically.
- Say it with energy — every command is a beat.

## Hand it over

One file (`.mov`/`.mp4`). Optionally the movie clip file (you need the rights to use it) and the time in that file
where the moment you want starts.
