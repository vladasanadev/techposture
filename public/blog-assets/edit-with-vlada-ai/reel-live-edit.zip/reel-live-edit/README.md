# Live Edit — make Claude edit your video on command

By [@vlada.asana](https://www.instagram.com/vlada.asana/). A Claude skill that turns one talking-head take into the
"ChatGPT vs Claude: who edits better?" reel: you speak the commands, Claude makes each one happen on the word.

- Home of this kit, with both example videos: https://editwithvladaai.vercel.app

## What's in the folder

| file | for |
|---|---|
| `SKILL.md` | Claude's instructions (the workflow it follows) |
| `SCRIPT.md` | the script you read on camera + how to film it |
| `PROMPTS.md` | copy-paste prompts: setup, the edit, fixes, the head-to-head, the fair brief, the caption |
| `REFERENCE.md` | every setting in `edit.json`, where each effect lives, troubleshooting |
| `engine/` | the editing engine (Python + a three.js graphics layer) |

## Quick start

1. **Film** the script in SCRIPT.md (landscape, 30 fps, palms up when you name a hand).
2. **Install the skill** in Claude Code: copy this `reel-live-edit` folder to `~/.claude/skills/` (all projects) or to
   `<your project>/.claude/skills/`. Claude Code = the terminal app or the **Code** tab in the Claude desktop app.
3. You need `ffmpeg` (`brew install ffmpeg` / `winget install Gyan.FFmpeg`), Google Chrome, and Python 3.12
   (or [uv](https://docs.astral.sh/uv/)). Best on an Apple Silicon Mac or a PC with an NVIDIA GPU.
4. Paste prompt **1** then prompt **2** from PROMPTS.md. Claude sets everything up (~5 min, once), shows you the plan,
   renders (~10–15 min for 35 s) and checks every beat on a contact sheet.
5. Optional: give another AI the "fair brief" (prompt **5**) and stack both edits with prompt **4**.

Nothing is AI-generated in the video: every pixel is your footage, code-drawn graphics and synthesised sound.
