# Reference — edit.json, the engine, troubleshooting

## Pipeline

```
take.mov ─ new_project ─ transcribe ─ cuts ─ plan ─┬─ matte ─ track ─ layout ─ camera ─┬─ render_gfx ─┐
                                                   │   (RVM)  (MediaPipe)               │  (Chrome +   │
                                                   └── edit.json (you can edit it) ─────┘   three.js)  ├─ composite ─ MP4 ─ qa
                                                                    mix (voice + synth SFX) ───────────┘
two finished edits ─ stack ─ 9:16 head-to-head
```

| script | reads | writes |
|---|---|---|
| setup.py | — | ~/.liveedit venv, models |
| new_project.py | take | edit.json skeleton (source, fps, duration, src_size, brands) |
| transcribe.py | take | words.json, audio/voice.wav (cleaned, −16 LUFS) |
| cuts.py | take | edit.json `cuts` |
| plan.py | words, cuts | edit.json `beats`, `captions` |
| matte.py | take, cuts | work/alpha (all frames), work/fgr (clip window + clear onward) |
| track.py | take, beats | work/stage/data/anchors.json |
| layout.py | alpha, beats | edit.json `layout` |
| camera.py | beats, layout | work/stage/data/camera.json |
| render_gfx.py | everything above | work/gfx/%05d.png (transparent) |
| mix.py | voice, beats | audio/mix.wav (−14 LUFS) |
| composite.py | take, alpha/fgr, camera, gfx, clip | frames → render.py |
| render.py | — | out/<name>.mp4 |
| qa.py | the MP4 | out/qa.jpg |
| stack.py | two MP4s | 9:16 head-to-head |

## edit.json

All times are seconds on the take's timeline. Delete a beat to skip that effect.

```jsonc
{
  "source": "take.mov", "fps": 30, "duration": 35.1667, "src_size": [2560, 1440],
  "brands": { "left": "chatgpt", "right": "claude" },        // viewer-left hand, viewer-right hand
  "cuts": [3.867, 6.367, …],                                  // first frame of each new shot
  "clip_file": "clip.mp4",                                     // optional
  "clip_start": 196.8,                                        // from new_project --clip-start (seconds into the clip file)
  "matte": { "cleanup": "auto" },                             // auto → layout.py picks "window" (bright window/city) or "none"
  "mirrored": false,                                          // true if the take is a mirrored selfie
  "clone_side": "left",                                       // where the clone stands in the two-shot
  "beats": {
    "hook":   { "text": ["WHO EDITS", "BETTER?"], "out": 1.42 },   // title leaves just before the first name
    "tags":   { "left": 1.50, "vs": 2.36, "right": 3.26 },         // name pills on the palms, VS on "or"
    "editor": { "in": 3.867, "live": 5.72, "out": 6.367, "filename": "my_take_01.mov" },
    "logos":  { "left": 7.18, "left_settle": 8.17, "right": 10.28, "right_settle": 11.15, "float": 12.70, "fly": 13.50 },
    "difficulty": [ { "t": 15.10, "out": 16.22, "label": "HARDER", "level": 2 },
                    { "t": 22.567, "out": 23.52, "label": "EVEN HARDER", "level": 3 } ],
    "captions": { "from": 16.38 },
    "clip":   { "in": 20.17, "out": 22.555, "src_start": 196.8, "pulses": [20.92, 22.08], "width": 900, "side": "left" },
    "clear":  { "t": 23.66 },
    "clone":  { "t": 26.40 },
    "recall": { "in": 29.00, "out": 29.84 },
    "end":    { "t": 30.133 }
  },
  "captions": [ { "t0": 16.38, "t1": 17.0, "pos": "side", "A": [["SUBTITLES", 16.44]] },
                { "t0": 17.0, "t1": 18.46, "pos": "side", "A": [["USING", 17.06], ["THESE", 17.42], ["TWO", 17.76]], "B": [["fonts", 18.02]] }, … ],
  "layout": { … written by layout.py … }
}
```

**Timing rules plan.py uses** (and you should keep when hand-tuning): most graphics land 2 frames (≈0.06 s) *before*
the word (the background wipe starts 0.04 s after "clear" so the sweep reads as the result of the word); a cube clicks in 0.12 s before "logo"; punch-ins snap to the jump cut at the start of "let's make it harder";
the clip enters 0.07 s before its word and exits 0.012 s before the next punch; the ending starts on the cut before "want".

**captions[]**: `A` = words in Anton caps, `B` = accent words in Instrument Serif italic (each `[text, onset]`; each
word animates in on its onset). `pos`: `side` (beside her), `top` (in the two-shot), `left`/`right` (forced),
`end` (ending section). layout.py writes `side` (left/right) into every side/end chunk: the section default unless her
arm or a lean (or a punch-in) reaches into it during that chunk, never the clip card's side while the card is up — and
`maxw`, the width the chunk may use there (it shrinks instead of touching her). Override either by hand; re-running
plan.py regenerates captions unless you pass `--keep`.
Ink is white on the original background, navy/orange on the cleared sky.

## Look of each effect (where to change it)

- **Hook / tags / VS / editor / cursors / meter** — stage/editor.js + index.html CSS. Editor window framing: camera.py `EDIT` (scale 0.70).
- **Glass cubes** — stage/main.js `buildCube` (squircle extrude + bevel, clearcoat glass, inner glow, fresnel rim, inlaid
  logo) and `logoState` (pop-in turn, hover, float, fly). Colours per brand in stage/brands.js.
- **Captions** — main.js `layoutCaps/renderCaps`, CSS `.cap`. Max width beside her 590 px (shrinks instead of touching her hair).
- **Clip card** — clip.py: size `beats.clip.width`, path in `pose()`, glint, shadow; composited *behind her* with her matte + fgr.
- **Wipe / sky** — composite.py `frame()` + bg.py `sky_bg()`.
- **Two-shot** — composite.py `TW` (head width both copies are scaled to), `CLONE_X/HER_X`, `SLIDE` (0.52 s slide-out with motion blur).
- **Sound** — mix.py cue list (all synthesised by sfx.py/bedkit.py; nothing sampled).

## Troubleshooting

| symptom | fix |
|---|---|
| `setup.py` NOT READY | read which line has ✗. No Python 3.12 → install `uv` (`curl -LsSf https://astral.sh/uv/install.sh \| sh`) and re-run. |
| a beat is missing in plan.py | whisper misheard the keyword — find the word in words.json and add the beat by hand |
| cubes on the wrong hands | swap `brands.left/right` (left = viewer's left). Mirrored selfie take → `"mirrored": true` and re-run plan |
| cube floats in the air / jumps | the palm wasn't visible: track.py prints frame counts per hand. Re-film with palms held up, or delay the click |
| black bars at the edges | camera.py must print `uncovered-edge frames: 0`; if not, reduce the punch-in amp in camera.py |
| bits of the room in her arm gaps / hair after the wipe | `matte.cleanup: "window"` (for bright windows); otherwise re-run matte with a cleaner background |
| holes in dark hair or a white top after the wipe | `matte.cleanup: "none"` — the window clean-up is too aggressive for this background |
| clip card covers her face | `beats.clip.side` to the other side, or smaller `width` |
| captions overlap her | layout.py picks the emptier side; force with captions[].pos `top`, or shorten the chunk |
| graphics render is slow / blank | install Google Chrome (GPU path); render_gfx falls back to Chromium + SwiftShader |
| no whisper backend | `setup.py --install` again; on Intel Macs/Windows/Linux it uses faster-whisper |
| `render_gfx` hangs at start | a local DNS issue — it uses a plain TCP server already; check nothing else is on 127.0.0.1 |

## Rights & honesty

- The movie clip: you need the rights (or a fair-use judgement) — the kit ships no clips.
- Brand logos (simple-icons, CC0 SVG) are used to name the products being compared; don't imply endorsement.
- RobustVideoMatting (GPL-3.0) and MediaPipe models are downloaded from their official sources at setup, not bundled.
- Fonts: Anton, Instrument Serif, Yeseva One, Cormorant Garamond, Marck Script, Pinyon Script — SIL OFL (licences included).
